"""Prepare Google's exact cpp-btree 1.0.1 comparator dependency in isolation."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import urllib.request

HERE = Path(__file__).resolve().parent
VERSION = "1.0.1"
URL = "https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/cpp-btree/cpp-btree-1.0.1.tar.gz"
ARCHIVE_SHA256 = "5653b0f1b7997627a16c402bf1e633ac3e01dff73ff1eaf0ce39935bb0d4e03d"
PREFIX = "cpp-btree-1.0.1/"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def prepare(archive=None, offline=False, target=None):
    target = Path(target) if target is not None else HERE / "vendor" / "google_btree"
    manifest_path = target / "manifest.json"
    if offline and archive is None:
        if not manifest_path.is_file():
            raise FileNotFoundError("Pinned Google B-tree source missing; prepare once with network or --archive")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("archive_sha256") != ARCHIVE_SHA256 or manifest.get("version") != VERSION:
            raise ValueError("Google B-tree provenance differs from the pinned archive")
        hashes = manifest.get("source_sha256", {})
        if not hashes or "btree.h" not in hashes or "COPYING" not in hashes:
            raise ValueError("Google B-tree manifest is incomplete")
        for name, expected in hashes.items():
            relative = PurePosixPath(name)
            if relative.is_absolute() or ".." in relative.parts or "\\" in name:
                raise ValueError("Unsafe Google B-tree manifest path")
            path = target.joinpath(*relative.parts)
            if not path.is_file() or sha256(path.read_bytes()) != expected:
                raise ValueError("Google B-tree source failed verification: " + name)
        return manifest
    if archive is not None:
        data = Path(archive).read_bytes()
    else:
        request = urllib.request.Request(URL, headers={"User-Agent": "isolated-multi-index-benchmark"})
        with urllib.request.urlopen(request, timeout=120) as response:
            data = response.read()
    if sha256(data) != ARCHIVE_SHA256:
        raise ValueError("Google B-tree archive differs from pinned SHA-256")
    files = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as source:
        for member in source.getmembers():
            if member.name == PREFIX.rstrip("/") and member.isdir():
                continue
            if not member.name.startswith(PREFIX):
                raise ValueError("Unexpected Google B-tree archive prefix")
            name = member.name[len(PREFIX):]
            if not name:
                continue
            relative = PurePosixPath(name)
            if relative.is_absolute() or ".." in relative.parts or "\\" in name:
                raise ValueError("Unsafe Google B-tree archive path")
            if member.issym() or member.islnk():
                raise ValueError("Google B-tree archive links are not supported")
            if not member.isfile():
                continue
            # Headers, original licensing and project documentation suffice.
            if len(relative.parts) != 1 or (relative.suffix != ".h" and name not in ("COPYING", "LICENSE", "README")):
                continue
            extracted = source.extractfile(member)
            if extracted is None:
                raise ValueError("Cannot read Google B-tree archive member")
            files[name] = extracted.read()
    if "btree.h" not in files or "btree_map.h" not in files:
        raise ValueError("Google B-tree archive is missing required map headers")
    if "COPYING" not in files and "LICENSE" in files:
        files["COPYING"] = files["LICENSE"]
    if "COPYING" not in files:
        raise ValueError("Google B-tree archive license is missing")
    target.mkdir(parents=True, exist_ok=True)
    for name, content in files.items():
        (target / name).write_bytes(content)
    manifest = {
        "project": "Google cpp-btree", "version": VERSION, "source_url": URL,
        "archive_sha256": ARCHIVE_SHA256, "license": "Apache-2.0",
        "selection_provenance": "NFL author scripts/bootstrap.sh downloads this exact release",
        "source_sha256": {name: sha256(content) for name, content in sorted(files.items())},
        "local_patches": [],
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    result = prepare(args.archive, args.offline)
    print(json.dumps({"prepared": True, "version": result["version"], "archive_sha256": result["archive_sha256"]}))
