#pragma once
#include <cstdint>

// Native structural builds activate these only for a single real lookup.
// Timing builds compile all bookkeeping away. No comparison outcome changes.
namespace mi_cost {
struct Metrics {
    uint64_t node_visits=0, model_evals=0, level_probes=0;
    uint64_t route_key_comparisons=0, correction_comparisons=0;
    uint64_t bucket_comparisons=0, final_comparisons=0;
    double route_ops=0, local_ops=0;
    double cost() const { return route_ops+local_ops; }
    uint64_t comparisons() const {
        return route_key_comparisons+correction_comparisons+bucket_comparisons+final_comparisons;
    }
};
#ifdef MI_TRACE
inline bool active=false;
inline Metrics current{};
inline void reset() { current=Metrics{};active=true; }
inline Metrics finish() { active=false;return current; }
inline void node() { if(active) { ++current.node_visits;++current.route_ops; } }
inline void model() { if(active) { ++current.model_evals;++current.route_ops; } }
inline void level() { if(active) { ++current.level_probes;++current.route_ops; } }
inline bool route_compare(bool result) {
    if(active) { ++current.route_key_comparisons;++current.route_ops; } return result;
}
inline bool correction_compare(bool result) {
    if(active) { ++current.correction_comparisons;++current.local_ops; } return result;
}
inline bool bucket_compare(bool result) {
    if(active) { ++current.bucket_comparisons;++current.local_ops; } return result;
}
inline bool final_compare(bool result) {
    if(active) { ++current.final_comparisons;++current.local_ops; } return result;
}
#else
inline void reset() {}
inline Metrics finish() { return {}; }
inline void node() {} inline void model() {} inline void level() {}
inline bool route_compare(bool result) { return result; }
inline bool correction_compare(bool result) { return result; }
inline bool bucket_compare(bool result) { return result; }
inline bool final_compare(bool result) { return result; }
#endif
}
