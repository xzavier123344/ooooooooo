#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
nohup bash run.sh run "$@" > experiment.log 2>&1 < /dev/null &
echo "Process ID: $!"
echo "Log: experiment.log"
