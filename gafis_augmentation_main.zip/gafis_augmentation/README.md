# GaFiS-guided Adaptive Key Augmentation

This artifact implements shared-weight adaptive augmentation for ALEX, LIPP, and
PGM. Each candidate is constructed using the target index's native builder.
The global objective combines frozen estimates from native lookup-operation
counts, retained index allocation, and the unnormalized GaFiS sum.

## Build and verify

Use Python with the packages in `requirements.txt` and a C++17 compiler.
The default native compilation flags are `-O3 -DNDEBUG -march=native -pthread`.
Pinned third-party sources are included; building does not download dependencies.

```bash
python3 -m pip install -r requirements.txt
bash build.sh --indices alex,lipp,pgm
python3 -m unittest discover -s tests -t . -v
bash run.sh check
```

Set `CXX` or pass `python3 build.py --compiler /path/to/g++` to choose a compiler.
Native binaries must be rebuilt on the evaluation machine. `verify.py` optionally
checks the complete execution path on a small generated fixture; those checks are
software validation, not real-dataset performance results.

## Inputs

Datasets are intentionally not included. Populate `datasets.csv`:

```csv
dataset,path
books,/data/books_uint64
```

An input consists of a little-endian unsigned 64-bit count followed by that many
unsigned 64-bit keys. All declared keys are sorted and deduplicated. The complete
canonical population is indexed, without key thinning. Auxiliary keys are unique
integers strictly inside the original domain and do not coincide with original
keys. Unsupported reserved key values produce errors; no keys are silently
removed or transformed.

## Search and measurement

```bash
bash run.sh plan --out outputs/experiment --datasets-file datasets.csv
bash run.sh search --out outputs/experiment --datasets-file datasets.csv
bash run.sh measure --out outputs/experiment
bash run.sh report --out outputs/experiment
bash run.sh bundle --out outputs/experiment
```

Alternatively, run search and measurement sequentially:

```bash
bash run.sh run --out outputs/experiment --datasets-file datasets.csv
```

For background execution:

```bash
bash run_background.sh --out outputs/experiment --datasets-file datasets.csv
tail -f experiment.log
```

The `plan`, `search`, and `run` commands must use the same arguments for an output
directory. To resume an interrupted search, repeat the original command. Frozen
settings and source hashes reject accidental changes. `measure` restores the
recorded arguments and verifies sources and native binary hashes.

`--indices alex,lipp,pgm` selects architectures; `--datasets books,covid` selects
CSV entries. All selected cases run sequentially. Use a fresh output for changed
settings. `--cpu auto` pins native work to one available CPU on Linux; an explicit
allowed CPU can be supplied. Search and final lookup measurements are single
threaded.

## Release scope

This submission version runs only the main augmentation experiment. Search
retains all 45 weight pairs per index and the shared candidate pool. Final
measurement times only the original index and the endpoint chosen by the
index's designated pair; if they are identical, it measures the original once.
Extra weight endpoints, sensitivity runs, structural-predictor experiments,
and refinement ablations are not run. Gap and SSE remain proposal generators;
this package does not separately run placement-control benchmarks.
Changed grids require a fresh output directory.

## Objective and weights

For a candidate V, with n original keys and U the adjacent absolute log-gap sum:

    J(V) = log(C(V)/C0) + gamma_s log(S(V)/S0)
           + gamma_g log((n-2+U(D union V))/(n-2+U(D))).

The denominator n-2 always refers to the original population. `S` is the requested
allocation retained by the native index, including auxiliary records and excluding
input arrays and temporary construction memory.

| Index | Space grid | GaFiS grid | Pairs | Designated pair |
|---|---|---|---:|---|
| ALEX | 0, .025, .05, .1, .5 | 0, .005, .025, .05, .1, .2, .4, 1, 1.5 | 45 | (.1, .2) |
| LIPP | 0, .025, .05, .1, .5 | 0, .005, .025, .05, .1, .2, .4, 1, 1.5 | 45 | (.025, .2) |
| PGM | 0, .025, .05, .1, .5 | 0, .005, .025, .05, .1, .2, .4, 1, 1.5 | 45 | (.025, .025) |

The designated pair determines the first weight in the fixed priority order. It
is followed by the same space weight with zero GaFiS weight, the zero-weight pair,
and remaining Cartesian-grid pairs in configuration order. Each pair selects its
champion over the entire evaluated pool. Expanded or duplicate champions are
skipped; runners-up are not substituted. Up to `--parents` distinct parents are
fixed at the start of a round. Objective values are never compared across weights.

## Native operation-count model

The eight counters are `root_steps`, `other_steps`, `leaf_models`,
`exponential_comparisons`, `binary_comparisons`, `route_comparisons`,
`correction_comparisons`, and `final_comparisons`. Counters not exercised by an
architecture remain zero. Independent operation microbenchmarks initialize
positive costs. Only original-index lookup blocks fit effective prices, with a
fixed penalty of .01 toward the independently measured costs and block-based
held-out validation. PGM ties correlated counters into three price groups while
retaining the eight-counter representation. With fewer than five calibration
blocks, the measured operation priors are retained and the fallback is recorded.

The same original-rank stratified query sample is reused for every candidate:
2,097,152 queries for ALEX and 1,048,576 for LIPP/PGM, capped by the population.
Each stratum's mean is weighted by its population share. Coefficients freeze before
seed candidates are evaluated. Candidate lookup timings never refit them. Regional
sample means provide allocation profiles; empty sampled regions use global C.

## Candidates and feedback

Native routing prefixes partition original-key ranks into consecutive regions of
at most 1,000,000 original keys. The anchor is the last allowed key. At each level,
the right prefix boundary is eligible only when it equals the anchor; otherwise
the left boundary must leave at least max(1, floor(M/4)) keys. The anchor is the
fallback. LIPP terminal routing slots and all PGM recursive routing levels are
included. Each gap belongs to its left original endpoint's region.

Regional marginal allocation uses weights `s_r * (.1 + mean_cost_r)`, the bounded
continuous solution of `sum(weight_r * s_r/(s_r+z_r))`, bisection, and
capacity-constrained largest-remainder rounding. Gap placement subdivides large
gaps. The SSE alternative adjusts coordinates toward a fitted key-to-rank line
and accepts a local coordinate update only when its SSE decreases. These are
proposal generators, not reproductions of a complete published smoothing system.

Initialization evaluates the original state and feasible Gap/SSE seeds at .01,
.1, and the insertion ceiling (distinct counts only). Default ceiling is .5n.
Each selected parent uses this bounded recipe order:

1. **Relocate:** switch Gap/SSE coordinates while preserving every regional count.
2. **Reallocate:** keep the coordinate generator and use equal per-gap allocation.
3. **Add:** try total counts min(ceiling, k + max(1, floor(.05n))) and
   min(ceiling, max(1, 2k)); preserve existing auxiliary keys.
4. **Remove:** retain floor(k/2) auxiliary keys at evenly spaced auxiliary ranks.

Same-count moves apply only to nonempty states. Unchanged or duplicate recipes
are omitted. Remove-to-zero reuses the original state. Every generated feasible
candidate proceeds in recipe order unless its coordinates have already been
evaluated or resources are exhausted. There is no proposal ranking, shortlist,
GaFiS redistribution, or structural lookup-cost predictor. Physical identity is
checked before a native build. All valid evaluated states remain available,
including candidates that do not improve their parent.

Search stops at exhausted weight champions, a completed round with no new valid
state, or round/resource limits. There is no objective-improvement tolerance.
Parents are marked completed only after their bounded recipe batches finish;
checkpoints preserve an interrupted parent's next recipe and the frozen round
parent list. Every weight returns its own minimum-J evaluated state.

Default resource settings are 3 rounds, 3 parents per round, 64 attempted native
evaluations per case (including original/seeds), 21,600 active search seconds,
7,200 seconds per native evaluation, and 1,800 seconds per proposal.

## Reported outputs

- `all_weight_selections.csv`: selected state, count, and objective components for
  every weight pair, including choices not timed.
- `lookup_results.csv`: frozen endpoint lookup measurements, independent of search.
- `search_overhead.csv`: search duration, proposal and feasibility costs, and
  successful native construction/profile costs. Failed work is included in total
  search duration and retained in event/failure logs.
- Per-case `state_pool`, candidate records, recipes, profiles, calibration, query
  hashes, parent-selection traces, stop reasons, and physical cache aliases.

Final validation checks all original and auxiliary keys by default. Measurement
rebuilds frozen endpoints independently 3 times with 6 timed repeats per build.
The original-key query pools contain 10 million keys for ALEX and 4 million for
LIPP/PGM, capped by the population. A Google cpp-btree reference is used only for
paired timing normalization; it does not enter J or parent selection. The
designated endpoint and original index are timed. All 45 objective selections
are recorded for search transparency, without running extra weight-endpoint
measurements. The main-experiment entry point fixes `--policy-timing-limit 1`.

This artifact contains no real-dataset performance claims. Fresh results must be
obtained by running the supplied method on the declared inputs and machine.

## Licenses

See `THIRD_PARTY_NOTICE.md`. Original upstream copyright and license notices are
preserved. The artifact's own source and documentation contain no author identity,
machine-specific absolute path, or experiment-date label.
