// Exact UInt64 coordinates. Bounded-region generation; streaming merge/PLAFI.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using U=uint64_t;
using Wide=unsigned __int128;
struct Reader {
  std::ifstream f; std::vector<U> b; size_t p=0,n=0;
  explicit Reader(const std::string& s):f(s,std::ios::binary),b(65536) {if(!f)throw std::runtime_error("read open: "+s);}
  bool next(U& x) {if(p==n){f.read((char*)b.data(),b.size()*8);auto z=f.gcount();if(z%8)throw std::runtime_error("partial UInt64");n=z/8;p=0;if(!n)return false;}x=b[p++];return true;}
};
struct Writer {
  std::ofstream f;std::vector<U>b;
  explicit Writer(const std::string&s):f(s,std::ios::binary){if(!f)throw std::runtime_error("write open: "+s);b.reserve(65536);}
  void add(U x){b.push_back(x);if(b.size()==65536)flush();}
  void flush(){if(!b.empty()){f.write((char*)b.data(),b.size()*8);b.clear();}if(!f)throw std::runtime_error("write failed (disk full?)");}
  void finish(){flush();f.close();if(!f)throw std::runtime_error("close failed");}
};
struct Variation {
  bool have=false,gap=false;U prev=0,count=0;long double last=0,raw=0,trunc=0;
  void add(U x){if(x==std::numeric_limits<U>::max())throw std::runtime_error("reserved sentinel");
    if(have){if(x<=prev)throw std::runtime_error("keys not strictly increasing");long double l=std::log((long double)(x-prev));
      if(gap){auto d=std::abs(l-last);raw+=d;trunc+=std::min(d,std::sqrt((long double)10));}last=l;gap=true;}
    have=true;prev=x;++count;}
};
U countfile(const std::string&s){auto z=std::filesystem::file_size(s);if(z%8)throw std::runtime_error("not UInt64 file");return z/8;}
void stats(const std::string& source,U width,const std::string& out){
  U n=countfile(source);if(n<3||!width)throw std::runtime_error("invalid population/region width");
  Reader r(source);std::ofstream f(out);if(!f)throw std::runtime_error("stats output");
  f<<"begin,end,original_count,gap_begin,gap_end,capacity,roughness_sum\n";
  U x=0,y=0,idx=0,begin=0,capacity=0;long double rough=0,oldlog=0;bool hadgap=false;
  if(!r.next(x))throw std::runtime_error("empty source");
  while(r.next(y)){
    if(y<=x||y==std::numeric_limits<U>::max())throw std::runtime_error("source order/sentinel");
    auto g=y-x;capacity+=g-1;auto lg=std::log((long double)g);
    if(hadgap)rough+=std::abs(lg-oldlog);oldlog=lg;hadgap=true;x=y;++idx;
    if(idx%width==0){U end=std::min(n,idx);f<<begin<<','<<end<<','<<end-begin<<','<<begin<<','<<idx<<','<<capacity<<','<<std::setprecision(19)<<rough<<'\n';begin=idx;capacity=0;rough=0;}
  }
  // Last region includes final original key even though it owns one fewer gap.
  if(begin<n)f<<begin<<','<<n<<','<<n-begin<<','<<begin<<','<<n-1<<','<<capacity<<','<<std::setprecision(19)<<rough<<'\n';
  if(!f)throw std::runtime_error("stats write");
}
void generate(const std::string& source,const std::string& plan,const std::string& out){
  U n=countfile(source);std::ifstream input(source,std::ios::binary),p(plan);if(!p)throw std::runtime_error("allocation plan missing");
  Writer w(out);U lo,hi,k,last=0,total=0;
  while(p>>lo>>hi>>k){
    if(lo!=last||hi<lo||hi>n-1)throw std::runtime_error("gap partition has hole/overlap");last=hi;
    U size=hi-lo;if(!k)continue;if(!size)throw std::runtime_error("empty gap region");
    std::vector<U>x(size+1),m(size,0),order;
    input.clear();input.seekg(lo*8);input.read((char*)x.data(),(size+1)*8);
    if((U)input.gcount()!=(size+1)*8)throw std::runtime_error("source short read");
    Wide cap=0;for(U i=0;i<size;++i){if(x[i+1]<=x[i])throw std::runtime_error("source ordering");auto g=x[i+1]-x[i];cap+=g-1;if(g>1)order.push_back(i);}
    if((Wide)k>cap)throw std::runtime_error("requested points exceed legal integer capacity");
    auto g=[&](U i){return x[i+1]-x[i];};
    std::sort(order.begin(),order.end(),[&](U a,U b){return g(a)!=g(b)?g(a)>g(b):a<b;});
    long double sum=0,h=1;size_t active=0;
    for(size_t z=0;z<order.size();++z){sum+=(long double)g(order[z]);active=z+1;h=sum/((long double)k+active);
      if(z+1==order.size()||(long double)g(order[z+1])<=h)break;}
    h=std::max((long double)1,h);U used=0;
    for(size_t z=0;z<active;++z){auto i=order[z];auto v=std::max((long double)0,std::floor((long double)g(i)/h-1));
      m[i]=std::min<U>(g(i)-1,(U)v);used+=m[i];}
    // Rounding leaves fewer than active gaps in the ordinary case. Exact
    // correction keeps cardinality even on extreme UInt64 spacings.
    if(used>k){for(auto i:order){auto d=std::min(m[i],used-k);m[i]-=d;used-=d;if(used==k)break;}}
    while(used<k){
      std::sort(order.begin(),order.end(),[&](U a,U b){auto aa=(long double)g(a)/(m[a]+1),bb=(long double)g(b)/(m[b]+1);return aa!=bb?aa>bb:a<b;});
      U before=used;for(auto i:order){if(m[i]<g(i)-1){++m[i];++used;if(used==k)break;}}
      if(used==before)throw std::runtime_error("coordinate capacity exhausted");
    }
    for(U i=0;i<size;++i)for(U j=1;j<=m[i];++j){U offset=(U)((Wide)j*g(i)/(m[i]+1));w.add(x[i]+offset);}
    total+=k;std::cerr<<"[REGION GENERATED] gap_begin="<<lo<<" gap_end="<<hi<<" k="<<k<<" cumulative="<<total<<'\n';
  }
  if(!p.eof()||last!=n-1)throw std::runtime_error("allocation does not cover every original gap");
  w.finish();if(countfile(out)!=total)throw std::runtime_error("generated count mismatch");
}
void merge(const std::string& real,const std::string& shadows,const std::string& out,const std::string& report){
  Reader a(real),b(shadows);Writer w(out);U x=0,y=0;bool ax=a.next(x),by=b.next(y);Variation v;U rcount=0,scount=0;
  U first=0,last=0;{Reader check(real);U t;bool any=false;while(check.next(t)){if(!any)first=t;last=t;any=true;}}
  while(ax||by){if(ax&&by&&x==y)throw std::runtime_error("shadow collides with real key");
    U z;if(ax&&(!by||x<y)){z=x;ax=a.next(x);++rcount;}else{z=y;if(z<=first||z>=last)throw std::runtime_error("shadow outside original domain");by=b.next(y);++scount;}
    v.add(z);w.add(z);}
  if(rcount<3)throw std::runtime_error("too few original keys");w.finish();
  std::ofstream f(report);f<<std::setprecision(19)<<"{\"n0\":"<<rcount<<",\"k\":"<<scount<<",\"physical_count\":"<<v.count
    <<",\"plafi_raw_fixed\":"<<v.raw/(rcount-2)<<",\"plafi_trunc_fixed\":"<<v.trunc/(rcount-2)
    <<",\"plafi_raw_total\":"<<v.raw<<",\"plafi_trunc_total\":"<<v.trunc<<"}\n";
  if(!f)throw std::runtime_error("metric write");
}
int main(int argc,char**argv){try{
  if(argc==5&&std::string(argv[1])=="stats")stats(argv[2],std::stoull(argv[3]),argv[4]);
  else if(argc==5&&std::string(argv[1])=="generate")generate(argv[2],argv[3],argv[4]);
  else if(argc==6&&std::string(argv[1])=="merge")merge(argv[2],argv[3],argv[4],argv[5]);
  else throw std::runtime_error("usage: stats real width out.csv | generate real allocations.txt shadow.bin | merge real shadow physical metrics.json");
  return 0;
}catch(const std::exception&e){std::cerr<<"[POPULATION ERROR] "<<e.what()<<'\n';return 2;}}
