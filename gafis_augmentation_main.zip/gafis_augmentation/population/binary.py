"""Streaming merge and verified temporary population materialization."""
from contextlib import contextmanager
import os
from pathlib import Path
import subprocess
import tempfile
from multi_sse_v5 import driver as d, storage
ROOT=Path(__file__).resolve().parent.parent


def tool():
    path = ROOT / 'population' / 'bin' / 'population_stream'
    if not path.is_file():
        path = path.with_suffix('.exe')
    if not path.is_file():
        raise FileNotFoundError('Run population.sh build first: ' + str(path))
    return str(path)

def invoke(*args, timeout=3600):
    subprocess.run([tool()] + list(map(str, args)), check=True, timeout=timeout)

def validate_plan(plan, row, artifacts=None):
    if plan.get('format') != 'uint64_binary_v1' or plan.get('k') != row['k']:
        raise ValueError('Binary point plan declaration mismatch')
    path = Path(plan['binary_path'])
    if path.stat().st_size != row['k'] * 8 or d.digest(path) != plan['binary_sha256']:
        raise ValueError('Frozen binary shadows changed')
    if artifacts is not None and artifacts.get(str(path)) != plan['binary_sha256']:
        raise ValueError('Missing frozen shadow artifact binding')

@contextmanager
def materialized(row, a):
    plan = d.read(row['points_path'])
    validate_plan(plan, row)
    directory = storage.scratch_directory(a)
    storage.ensure_space(directory, (row['n0'] + row['k']) * 8)
    (fd, name) = tempfile.mkstemp(prefix='population_', suffix='.bin', dir=str(directory))
    os.close(fd)
    path = Path(name)
    metrics = path.with_suffix('.metrics.json')
    try:
        invoke('merge', row['real_path'], plan['binary_path'], path, metrics, timeout=getattr(a, 'timeout', 3600))
        if d.digest(path) != row['physical_sha256']:
            raise ValueError('Streaming physical hash differs from frozen state')
        yield path
    finally:
        path.unlink(missing_ok=True)
        metrics.unlink(missing_ok=True)
