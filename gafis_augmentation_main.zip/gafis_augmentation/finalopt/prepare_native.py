"""Generate isolated passive native accessors used by finalopt/native.cpp."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def prepare():
    from multi_sse_v5.prepare_native import prepare as base_prepare
    base_prepare()
    target = ROOT / 'multi_sse_v5/vendor/lipp/lipp.h'
    text = target.read_text(encoding='utf-8')
    marker = '    int op_root_slot(T key) const { return PREDICT_POS(root,key); }'
    if text.count(marker) != 1:
        raise RuntimeError('Unsupported pinned LIPP partition accessor anchor')
    accessor = '''
    // Read-only routing path INCLUDING terminal data slots. Root-direct keys
    // must participate in the same covering partition as collision children.
    std::vector<uint64_t> finalopt_partition_path(T key) const {
        std::vector<uint64_t> path; Node* node=root;
        while (true) {
            const int pos=PREDICT_POS(node,key);
            path.push_back(static_cast<uint64_t>(pos)+1);
            if (BITMAP_GET(node->none_bitmap,pos) ||
                !BITMAP_GET(node->child_bitmap,pos)) break;
            node=node->items[pos].comp.child;
        }
        return path;
    }
'''
    target.write_text(text.replace(marker, accessor + marker), encoding='utf-8')
    target = ROOT / 'multi_sse_v5/vendor/pgm/pgm_index.hpp'
    text = target.read_text(encoding='utf-8')
    marker = '    static constexpr size_t epsilon_value = Epsilon;'
    if text.count(marker) != 1:
        raise RuntimeError('Unsupported pinned PGM partition accessor anchor')
    accessor = '''
    // Read-only path of selected segments, ordered from root to bottom level.
    // Reproduce native recursive routing without modifying the lookup routine.
    std::vector<uint64_t> finalopt_partition_path(const K& key) const {
        std::vector<uint64_t> path;
        if (segments.empty()) return path;
        const auto k = std::max(first_key, key);
        if constexpr (EpsilonRecursive == 0) {
            const auto it = std::prev(std::upper_bound(
                segments.begin(), segments.begin() + segments_count(), k));
            path.push_back(static_cast<uint64_t>(it - segments.begin()) + 1);
            return path;
        }
        auto it = segments.begin() + *(levels_offsets.end() - 2);
        path.push_back(1);
        for (auto level = int(height()) - 2; level >= 0; --level) {
            const auto level_begin = segments.begin() + levels_offsets[level];
            const auto pos = std::min<size_t>((*it)(k), std::next(it)->intercept);
            auto lo = level_begin + PGM_SUB_EPS(pos, EpsilonRecursive + 1);
            static constexpr size_t linear_search_threshold = 8 * 64 / sizeof(Segment);
            if constexpr (EpsilonRecursive <= linear_search_threshold) {
                for (; std::next(lo)->key <= k; ++lo) continue;
                it = lo;
            } else {
                const auto level_size = levels_offsets[level + 1] - levels_offsets[level] - 1;
                const auto hi = level_begin + PGM_ADD_EPS(pos, EpsilonRecursive, level_size);
                it = std::prev(std::upper_bound(lo, hi, k));
            }
            path.push_back(static_cast<uint64_t>(it - level_begin) + 1);
        }
        return path;
    }
'''
    target.write_text(text.replace(marker, accessor + marker), encoding='utf-8')
    # Strictly read-only structural accessors. These do not change build or
    # lookup code and allocate no per-key structures in the stored index.
    additions = (
        ('lipp/lipp.h', 'lipp_structural_accessors.inc', '    size_t hhh_nodes() const {'),
        ('pgm/pgm_index.hpp', 'pgm_accessors.inc',
         '    static constexpr size_t epsilon_value = Epsilon;'),
    )
    for relative, include_name, anchor in additions:
        target = ROOT / 'multi_sse_v5/vendor' / relative
        text = target.read_text(encoding='utf-8')
        if text.count(anchor) != 1:
            raise RuntimeError('Unsupported structural accessor anchor: ' + relative)
        addition = (ROOT / 'finalopt' / include_name).read_text(encoding='utf-8')
        target.write_text(text.replace(anchor, addition + anchor), encoding='utf-8')
    print('[FINALOPT NATIVE PREPARED] native build/search unchanged; LIPP terminal-slot coverage enabled', flush=True)


if __name__ == '__main__':
    prepare()
