#pragma once
#include <array>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

struct StructuralProfile {
    std::map<std::string,double> f;
    // Optional calibration features indexed by original payload - 1.
    // ALEX: [storage depth, log2(1+physical-slot error), 0, 0].
    // LIPP: [storage depth, 0, 0, 0].
    // PGM:  [model evaluations, analytic routing comparisons,
    //        analytic final lower_bound comparisons, 0].
    std::vector<std::array<double,4>> per_key;
};
