"""Binary batch proposals on a complete, refreshed native rank partition.

The generator builds a *total replacement candidate* from the original keys.
The caller may accept it as an Add/Reallocate/Relocate step.  No Python object is
created per virtual point.  SSE means a fitted-rank, batch coordinate update;
it does not mean the published CSV subtree algorithm.
"""
import json
import math
import os
import subprocess
from pathlib import Path

import numpy as np


def _cost(region):
    n = int(region['end']) - int(region['begin'])
    if 'mean_cost' in region:
        return max(0.0, float(region['mean_cost']))
    for key in ('cost_mass', 'work_mass'):
        if key in region:
            return max(0.0, float(region[key]) / max(n, 1))
    return max(0.0, float(region.get('work', 1.0)))


def segments(real_path, regions, scope='hybrid', boundary_fraction=.125):
    """Return a complete disjoint gap partition, including zero-budget pieces.

Gap i lies between original keys i and i+1.  A boundary gap belongs to the
preceding native region.  Edge neighborhoods are defined in original rank,
and never silently overlap or lose directly stored LIPP keys.
"""
    if scope not in ('boundary', 'interior', 'hybrid'):
        raise ValueError('unknown proposal scope')
    if not 0 < boundary_fraction <= .5:
        raise ValueError('boundary_fraction must be in (0,.5]')
    path = Path(real_path)
    if path.stat().st_size % 8:
        raise ValueError('partial original UInt64 file')
    keys = np.memmap(path, dtype='<u8', mode='r')
    n = len(keys)
    if n < 3:
        raise ValueError('at least three original keys required')
    result, expected = [], 0
    for rid, region in enumerate(regions):
        begin, end = int(region['begin']), int(region['end'])
        if begin != expected or end <= begin or end > n:
            raise ValueError('native rank regions must cover all original keys without overlap')
        expected = end
        lo, hi = begin, min(end, n - 1)
        if lo == hi:
            continue
        width = max(1, int(math.ceil((end - begin) * boundary_fraction)))
        cuts = ([lo, hi] if scope == 'hybrid' else
                sorted(set((lo, min(hi, lo + width), max(lo, hi - width), hi))))
        for a, b in zip(cuts, cuts[1:]):
            if a == b:
                continue
            # First/last population edges are not artificial native boundaries.
            edge = ((begin > 0 and a < lo + width) or
                    (end < n and b > hi - width))
            eligible = scope == 'hybrid' or (edge if scope == 'boundary' else not edge)
            capacity = int(keys[b]) - int(keys[a]) - (b - a)
            if capacity < 0:
                raise ValueError('original keys are not strictly increasing')
            result.append({'gap_begin': a, 'gap_end': b,
                           'original_count': b - a, 'region_id': rid,
                           'capacity': capacity if eligible else 0,
                           'legal_capacity': capacity, 'eligible': eligible,
                           'boundary': bool(edge), 'mean_cost': _cost(region)})
    if expected != n or not result or result[0]['gap_begin'] != 0 or result[-1]['gap_end'] != n - 1:
        raise ValueError('native partition misses original keys or gaps')
    del keys
    return result


def allocate(parts, k, mode='marginal'):
    """Concave allocation with exact integer cardinality and legal capacities.

The score is a search heuristic, not a throughput estimator.  Equal allocates
per eligible original gap; marginal gives more weight to costly queries while
retaining a positive floor.  Full native validation decides acceptance.
"""
    k = int(k)
    if k < 0 or mode not in ('equal', 'marginal'):
        raise ValueError('invalid allocation count or mode')
    caps = [int(p['capacity']) for p in parts]
    if k > sum(caps):
        raise ValueError('requested count exceeds legal capacity in selected scope')
    if not k:
        return [0] * len(parts)
    sizes = [max(1, int(p['original_count'])) for p in parts]
    weights = [n * (1.0 if mode == 'equal' else .1 + float(p['mean_cost']))
               for p, n in zip(parts, sizes)]
    def at(price):
        return [min(cap, max(0.0, math.sqrt(a * n / price) - n))
                for a, n, cap in zip(weights, sizes, caps)]
    low, high = 0.0, max(a / n for a, n in zip(weights, sizes)) + 1.0
    for _ in range(100):
        mid = (low + high) / 2
        if sum(at(mid)) > k:
            low = mid
        else:
            high = mid
    values = at(high)
    counts = [min(cap, int(value)) for value, cap in zip(values, caps)]
    left = k - sum(counts)
    order = sorted(range(len(parts)), key=lambda i: (-(values[i] - counts[i]), i))
    while left:
        previous = left
        for i in order:
            if counts[i] < caps[i]:
                counts[i] += 1
                left -= 1
                if not left:
                    break
        if left == previous:
            raise RuntimeError('integer allocation capacity exhausted')
    return counts


def native_binary():
    suffix = '.exe' if os.name == 'nt' else ''
    return Path(__file__).resolve().parent / 'bin' / ('proposal_stream' + suffix)


def merge_points(left_path, right_path, outpath, binary=None, timeout=1800):
    """Streaming sorted set union for cumulative Add candidates, including k=0."""
    left, right, out = Path(left_path), Path(right_path), Path(outpath)
    if out.resolve() in (left.resolve(), right.resolve()):
        raise ValueError('point union output must differ from inputs')
    executable = Path(binary) if binary else native_binary()
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        completed = subprocess.run([str(executable.resolve()), 'union', str(left.resolve()),
                                    str(right.resolve()), str(out.resolve())],
                                   capture_output=True, text=True, timeout=timeout, check=True)
        count = int(completed.stdout.strip())
        if out.stat().st_size != count * 8:
            raise RuntimeError('point union size mismatch')
    except BaseException:
        out.unlink(missing_ok=True)
        raise
    return count


def generate(real_path, regions, target_k, out_dir, generator='gap',
             scope='hybrid', allocation='marginal', binary=None,
             boundary_fraction=.125, timeout=1800, seed=1729, regional_counts=None):
    """Generate sorted raw UInt64 TOTAL shadows and small allocation metadata."""
    if generator not in ('gap', 'sse', 'random'):
        raise ValueError('generator must be gap, sse or random')
    folder = Path(out_dir)
    folder.mkdir(parents=True, exist_ok=True)
    parts = segments(real_path, regions, scope, boundary_fraction)
    if regional_counts is None:
        counts = allocate(parts, target_k, allocation)
    else:
        counts = [int(x) for x in regional_counts]
        if (len(counts) != len(parts) or sum(counts) != int(target_k)
                or any(x < 0 or x > int(p['capacity']) for x,p in zip(counts,parts))):
            raise ValueError('Preserved regional counts violate cardinality or capacity')
    plan = folder / 'allocation.txt'
    with plan.open('w', encoding='utf8', newline='\n') as stream:
        for p, count in zip(parts, counts):
            stream.write('{} {} {}\n'.format(p['gap_begin'], p['gap_end'], count))
    points = folder / 'shadows.bin'
    report = folder / 'proposal_native.json'
    log = folder / 'proposal_progress.log'
    executable = Path(binary) if binary else native_binary()
    if not executable.is_file():
        raise FileNotFoundError('Build finalopt proposal_stream first: ' + str(executable))
    command = [str(executable.resolve()), str(Path(real_path).resolve()),
               str(plan.resolve()), str(points.resolve()), generator, str(report.resolve()), str(int(seed))]
    try:
        with log.open('w', encoding='utf8') as output:
            subprocess.run(command, stdout=output, stderr=subprocess.STDOUT,
                           timeout=timeout, check=True)
    except BaseException:
        # A partial binary can never become a reusable candidate.
        points.unlink(missing_ok=True)
        raise
    if points.stat().st_size != int(target_k) * 8:
        points.unlink(missing_ok=True)
        raise RuntimeError('native generator did not produce requested exact count')
    native = json.loads(report.read_text(encoding='utf8'))
    metadata = {'requested_k': int(target_k), 'actual_k': int(target_k),
                'points_path': str(points.resolve()), 'allocation_path': str(plan.resolve()),
                'generator': generator, 'scope': scope, 'allocation': allocation, 'seed': int(seed),
                'boundary_fraction': boundary_fraction,
                'total_candidate_from_original': True,
                'legal_capacity': sum(p['capacity'] for p in parts),
                'parts': [dict(p, allocated=count) for p, count in zip(parts, counts)],
                'native': native}
    (folder / 'proposal.json').write_text(json.dumps(metadata, indent=2), encoding='utf8')
    return metadata
