"""Fit positive operation costs using ORIGINAL-index blocks and an independent prior.

The CSV must be emitted by finalopt/native.cpp --calibration-out before any
candidate search. It contains actual baseline lookup times, not timing of
optimized candidates. Coefficients express effective baseline costs; neither
cache misses nor cache-hit probabilities are measured by this regression.
"""
import csv
import hashlib
import math
from pathlib import Path

import numpy as np
from scipy.optimize import lsq_linear

from finalopt.cost import FEATURES


def _digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def _errors(actual, predicted):
    residual = predicted-actual
    denominator = float(np.sum((actual-np.mean(actual))**2))
    return dict(blocks=len(actual),
                mean_absolute_error_ns=float(np.mean(np.abs(residual))),
                median_absolute_percentage_error=float(np.median(np.abs(residual)/actual)),
                root_mean_squared_error_ns=float(np.sqrt(np.mean(residual**2))),
                r_squared=(float(1.-np.sum(residual**2)/denominator)
                           if denominator>0 else None))


def fit(csv_path, prior, index, ridge=.01, holdout_modulus=5):
    if index == 'pgm':
        return fit_pgm_groups(csv_path, prior, ridge, holdout_modulus)
    return fit_individual(csv_path, prior, index, ridge, holdout_modulus)


def fit_individual(csv_path, prior, index, ridge=.01, holdout_modulus=5):
    """Freeze a baseline fit; group repeat rows by block before holding blocks out.

    Relative coefficients u = coefficient / primitive_prior are fitted with
    nonnegative least squares and a ridge towards u=1. The ridge is a declared
    numerical regularizer, not selected using candidate throughput. Columns
    absent from all original blocks retain their standalone primitive prior.
    Held-out blocks never enter the fit and are reported even if fit is poor.
    """
    if index not in ('lipp', 'alex', 'pgm'):
        raise ValueError('Unknown calibration index')
    if not math.isfinite(ridge) or ridge<=0 or holdout_modulus<2:
        raise ValueError('Positive ridge and holdout modulus >=2 required')
    prior_coeff = np.asarray([prior['coefficients_ns'][k] for k in FEATURES], dtype=float)
    if np.any(~np.isfinite(prior_coeff)) or np.any(prior_coeff<=0):
        raise ValueError('Primitive prior must be finite and positive')
    groups = {}
    with Path(csv_path).open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream):
            operations = int(row['operations'])
            elapsed = float(row['elapsed_ns'])
            features = np.asarray([float(row[k]) for k in FEATURES])
            if operations<=0 or not math.isfinite(elapsed) or elapsed<=0:
                raise ValueError('Nonpositive calibration operations or time')
            if np.any(~np.isfinite(features)) or np.any(features<0):
                raise ValueError('Invalid native calibration features')
            key = int(row['block'])
            groups.setdefault(key, []).append((features, elapsed/operations))
    if len(groups)<5:
        raise ValueError('At least five distinct original calibration blocks required')
    block_ids = np.asarray(sorted(groups), dtype=np.int64)
    x, y = [], []
    repetitions = []
    for block_id in block_ids:
        repeated = groups[int(block_id)]
        matrix = np.asarray([r[0] for r in repeated])
        if not np.allclose(matrix, matrix[0], rtol=1e-10, atol=1e-10):
            raise ValueError('Repeated calibration block feature counts changed')
        x.append(matrix[0]); y.append(float(np.median([r[1] for r in repeated])))
        repetitions.append(len(repeated))
    x = np.asarray(x); y = np.asarray(y)
    held_out = block_ids%holdout_modulus==0
    if not np.any(held_out) or np.all(held_out):
        raise ValueError('Calibration split has empty training or held-out blocks')
    train = ~held_out
    active = np.max(np.abs(x[train]), axis=0)>1e-12
    if not np.any(active):
        raise ValueError('Calibration blocks contain no execution features')
    # Work in relative-prior units and normalized time to avoid feature/target
    # scale making the ridge unintentionally dominant on one architecture.
    scale = float(np.median(y[train]))
    design = x[train][:, active]*prior_coeff[active]/scale
    target = (y[train]-x[train][:, ~active]@prior_coeff[~active])/scale
    ntrain = int(np.count_nonzero(train))
    augmented_x = np.vstack((design/np.sqrt(ntrain), np.sqrt(ridge)*np.eye(int(np.sum(active)))))
    augmented_y = np.concatenate((target/np.sqrt(ntrain), np.sqrt(ridge)*np.ones(int(np.sum(active)))))
    result = lsq_linear(augmented_x, augmented_y,
                        bounds=(.001/prior_coeff[active], 1e6/prior_coeff[active]),
                        method='trf', tol=1e-11, max_iter=1000)
    if not result.success or np.any(~np.isfinite(result.x)):
        raise RuntimeError('Positive baseline calibration fit failed: '+str(result.message))
    coefficients = prior_coeff.copy(); coefficients[active] *= result.x
    predicted = x@coefficients
    result_info = dict(prior)
    result_info.update(
        schema='original_native_block_calibration_v1', index=index,
        coefficients_ns={k:float(v) for k,v in zip(FEATURES,coefficients)},
        primitive_prior_coefficients_ns={k:float(v) for k,v in zip(FEATURES,prior_coeff)},
        calibration_csv=str(Path(csv_path).resolve()), calibration_csv_sha256=_digest(csv_path),
        calibration_scope='original-index lookup blocks, before candidate search',
        original_index_only=True, measured_candidate_throughput=False,
        frozen_before_candidate_search=True, cache_miss_probability_measured=False,
        coefficient_interpretation='effective baseline operation costs; not exact cache simulation',
        regression='positive ridge toward independent primitive costs in relative-prior units',
        ridge=float(ridge), holdout_rule='original block id modulo %d equals zero'%holdout_modulus,
        fit_used_heldout_blocks=False, calibration_blocks=len(block_ids),
        repetitions_per_block_min=min(repetitions), repetitions_per_block_max=max(repetitions),
        active_features=[k for k,a in zip(FEATURES,active) if a],
        prior_only_features=[k for k,a in zip(FEATURES,active) if not a],
        normalized_training_design_rank=int(np.linalg.matrix_rank(design)),
        active_feature_count=int(np.sum(active)),
        fit_training_error=_errors(y[train],predicted[train]),
        fit_heldout_error=_errors(y[held_out],predicted[held_out]),
        prior_heldout_error=_errors(y[held_out],(x@prior_coeff)[held_out]),
        model_fidelity_requires_candidate_validation=True)
    return result_info


def fit_pgm_groups(csv_path, prior, ridge=.01, holdout_modulus=5):
    """Tie PGM counters into routing visits, routing comparisons, data search.

    Avoid fitting separate prices for correlated/constant counters. Fit only
    original-index blocks, with exactly the same train/holdout split as before.
    All executed final-search comparisons remain in C, including fixed work.
    This is an effective linear model, not a measured cache-miss model.
    """
    if ridge <= 0 or not math.isfinite(ridge) or holdout_modulus < 2:
        raise ValueError('Invalid PGM fit settings')
    groups=((0,1,2),(5,),(3,4,6,7))
    grouped={}
    with Path(csv_path).open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream):
            ops=int(row['operations']); elapsed=float(row['elapsed_ns'])
            x=np.asarray([float(row[k]) for k in FEATURES])
            if ops<=0 or elapsed<=0 or not math.isfinite(elapsed) or np.any(x<0) or np.any(~np.isfinite(x)):
                raise ValueError('Invalid PGM calibration row')
            grouped.setdefault(int(row['block']),[]).append((x,elapsed/ops))
    ids=np.asarray(sorted(grouped)); x=[]; y=[]
    if len(ids)<5:raise ValueError('At least five PGM calibration blocks required')
    for bid in ids:
        rows=grouped[int(bid)]
        if not all(np.allclose(z[0],rows[0][0]) for z in rows):
            raise ValueError('PGM repeated block features changed')
        x.append(rows[0][0]);y.append(float(np.median([z[1] for z in rows])))
    x=np.asarray(x);y=np.asarray(y)
    held=ids%holdout_modulus==0; train=~held
    if not np.any(held) or not np.any(train):raise ValueError('Empty PGM calibration split')
    pc=np.asarray([float(prior['coefficients_ns'][k]) for k in FEATURES])
    if np.any(pc<=0) or np.any(~np.isfinite(pc)):raise ValueError('Invalid PGM prior')
    z=np.column_stack([x[:,list(g)].sum(axis=1) for g in groups])
    # Weighted prior prices preserve the original primitive total on training
    # blocks before fitting, rather than importing a candidate timing price.
    gp=np.asarray([float((x[train][:,list(g)]@pc[list(g)]).sum()/max(z[train,j].sum(),1e-12))
                   if z[train,j].sum()>0 else float(np.mean(pc[list(g)])) for j,g in enumerate(groups)])
    active=np.max(z[train],axis=0)>0
    scale=float(np.median(y[train])); n=int(train.sum())
    design=z[train][:,active]*gp[active]/scale
    target=(y[train]-z[train][:,~active]@gp[~active])/scale
    fit=lsq_linear(np.vstack((design/np.sqrt(n),np.sqrt(ridge)*np.eye(int(active.sum())))),
                   np.r_[target/np.sqrt(n),np.sqrt(ridge)*np.ones(int(active.sum()))],
                   bounds=(.001/gp[active],1e6/gp[active]),tol=1e-11,max_iter=1000)
    if not fit.success:raise RuntimeError('Grouped PGM fit failed')
    prices=gp.copy();prices[active]*=fit.x
    coeff=pc.copy()
    for g,price in zip(groups,prices):coeff[list(g)]=price
    result=dict(prior)
    result.update(schema='pgm_grouped_original_calibration_v2',index='pgm',
        coefficients_ns={k:float(v) for k,v in zip(FEATURES,coeff)},
        primitive_prior_coefficients_ns=dict(prior['coefficients_ns']),
        calibration_csv=str(Path(csv_path).resolve()),calibration_csv_sha256=_digest(csv_path),
        original_index_only=True,measured_candidate_throughput=False,
        frozen_before_candidate_search=True,fit_used_heldout_blocks=False,
        groups=[[FEATURES[i] for i in g] for g in groups],ridge=ridge,
        training_error=_errors(y[train],(x@coeff)[train]),
        heldout_error=_errors(y[held],(x@coeff)[held]),
        cache_miss_probability_measured=False,model_fidelity_requires_candidate_validation=True)
    return result
