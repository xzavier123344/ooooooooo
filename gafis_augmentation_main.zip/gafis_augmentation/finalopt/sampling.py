"""Fixed original-rank strata; nested search samples and held-out validation."""
import hashlib
import json
from pathlib import Path

import numpy as np


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def _interleave(groups):
    """Each prefix covers strata evenly; random selection occurs inside strata."""
    if not groups:return np.empty(0,dtype='<u8')
    return np.concatenate([np.asarray([g[j] for g in groups if j<len(g)],dtype='<u8')
                           for j in range(max(map(len,groups),default=0))])


def prepare(real_path,folder,count=2097152,validation_count=2097152,strata=4096,seed=1729):
    real_path=Path(real_path);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    n=real_path.stat().st_size//8
    if n<3 or count<1 or validation_count<1 or strata<1:raise ValueError('invalid sample declaration')
    count=min(int(count),n);strata=min(int(strata),max(1,count//2))
    declaration=dict(n=n,search_count=count,validation_requested=int(validation_count),
                     strata=strata,seed=int(seed),real_sha256=digest(real_path))
    stamp=folder/'samples.json'
    if stamp.exists():
        info=json.loads(stamp.read_text(encoding='utf-8'))
        if info['declaration']!=declaration:raise ValueError('Frozen sampling declaration changed')
        for field in ('search_queries','search_ranks','validation_queries','validation_ranks'):
            if digest(info[field])!=info[field+'_sha256']:raise ValueError('Frozen query artifact changed')
        return info
    bounds=np.arange(strata+1,dtype=np.int64)*n//strata
    rng=np.random.default_rng(seed);search=[];valid=[]
    # Validation is disjoint whenever search does not exhaust the population.
    vcount=min(int(validation_count),n-count)
    # If too few held-out keys remain to cover the declared strata, validate
    # against the entire finite population and state explicitly that it is a
    # census, not an independent sample.
    census=(min(int(validation_count),n-count)<strata)
    if census:vcount=n
    quotas=(bounds*count//n)
    search_counts=np.diff(quotas)
    available_sizes=np.diff(bounds)-search_counts
    available_cumulative=np.concatenate(([0],np.cumsum(available_sizes)))
    valid_counts=(np.diff(available_cumulative*vcount//max(1,n-count))
                  if not census else np.diff(bounds))
    for h,(lo,hi) in enumerate(zip(bounds[:-1],bounds[1:])):
        size=int(hi-lo)
        m=int(search_counts[h])
        chosen=np.asarray(rng.choice(size,size=m,replace=False),dtype=np.int64)
        search.append(chosen+lo)
        if census:valid.append(np.arange(lo,hi,dtype=np.int64));continue
        want=int(valid_counts[h])
        available=size-m
        want=min(want,available)
        if not want:valid.append(np.empty(0,dtype=np.int64));continue
        # Map sampled complement ranks to original ranks without allocating size-N arrays.
        excluded=np.sort(chosen)
        draw=np.asarray(rng.choice(available,size=want,replace=False),dtype=np.int64)
        mapped=draw+np.searchsorted(excluded-np.arange(m),draw,side='right')
        valid.append(mapped+lo)
    search_ranks=_interleave(search)
    validation_ranks=_interleave(valid)
    real=np.memmap(real_path,dtype='<u8',mode='r')
    try:
        info=dict(declaration=declaration,bounds=bounds.tolist(),
                  validation_disjoint=not census,validation_is_full_population=census,
                  sample_order='round-robin strata; random without replacement within each stratum',
                  querying_shadow_keys=False)
        for role,ranks in (('search',search_ranks),('validation',validation_ranks)):
            q=folder/(role+'_queries.bin');r=folder/(role+'_ranks.bin')
            np.asarray(real[ranks.astype(np.int64)],dtype='<u8').tofile(q)
            ranks.tofile(r)
            info[role+'_queries']=str(q.resolve());info[role+'_ranks']=str(r.resolve())
            info[role+'_queries_sha256']=digest(q);info[role+'_ranks_sha256']=digest(r)
            info[role+'_count']=len(ranks)
    finally:real._mmap.close()
    stamp.write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    return info


def estimate(values,ranks,bounds):
    """Design-weighted original-key mean and finite-population sampling SE."""
    values=np.asarray(values,dtype=float);ranks=np.asarray(ranks,dtype=np.int64)
    bounds=np.asarray(bounds,dtype=np.int64)
    if len(values)!=len(ranks) or not len(values):raise ValueError('invalid sample observations')
    groups=np.searchsorted(bounds[1:],ranks,side='right')
    count=np.bincount(groups,minlength=len(bounds)-1)
    sizes=np.diff(bounds);weights=sizes/bounds[-1]
    if np.any(count==0):raise ValueError('Sample prefix omits an entire stratum')
    total=np.bincount(groups,weights=values,minlength=len(sizes))
    mean=total/count
    sq=np.bincount(groups,weights=values*values,minlength=len(sizes))
    variance=np.maximum(0.,(sq-total*total/count)/np.maximum(1,count-1))
    se=float(np.sqrt(np.sum(weights**2*np.maximum(0.,1-count/sizes)*variance/count)))
    return float(np.dot(weights,mean)),se
