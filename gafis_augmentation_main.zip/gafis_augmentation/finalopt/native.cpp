// Build native ALEX/LIPP/PGM once; export covering native regions and per-query
// untimed structural features. Reuses the experiment's pinned index wrappers.
#include <array>
#include <cstring>
#include <filesystem>
#include <random>
#define main finalopt_legacy_native_main
#include "../multi_sse_v5/native.cpp"
#undef main
#include "profile_common.hpp"
#if defined(OP_PGM)
#include "profile_pgm.hpp"
#else
#include "profile_alex_lipp.hpp"
#endif

namespace finalopt {
constexpr size_t F=8;
using Features=std::array<double,F>;
static constexpr const char* feature_names[F]={
    "root_steps","other_steps","leaf_models","exponential_comparisons",
    "binary_comparisons","route_comparisons","correction_comparisons","final_comparisons"};

static Features lookup_features(Native& native,Key key,uint64_t expected) {
    Features out{};bool found=false;uint64_t value=0;
#if defined(OP_LIPP)
    size_t visits=0;value=native.lookup(key,found,&visits);
    out[0]=visits?1:0;out[1]=visits?visits-1:0;out[7]=1;
#elif defined(OP_ALEX)
    fa::reset();value=native.lookup(key,found);const auto m=fa::finish();
    out[0]=m.route_models>0?1:0;out[1]=std::max(0.0,m.route_models-out[0]);
    out[2]=m.local_models;out[3]=m.exp_comparisons;out[4]=m.binary_comparisons;
    out[5]=m.route_keys;out[7]=m.final_comparisons;
#elif defined(OP_PGM)
    mi_cost::reset();value=native.lookup(key,found);const auto m=mi_cost::finish();
    out[0]=m.model_evals?1:0;out[1]=m.model_evals?m.model_evals-1:0;
    out[5]=m.route_key_comparisons;out[6]=m.correction_comparisons;out[7]=m.final_comparisons;
#endif
    if(!found||value!=expected)throw std::runtime_error("Finalopt original query payload mismatch");
    for(double v:out)if(!std::isfinite(v)||v<0)throw std::runtime_error("Invalid native feature");
    return out;
}

static std::vector<uint64_t> partition_path(const Native& native,Key key) {
#if defined(OP_LIPP)
    return native.index.finalopt_partition_path(key);
#elif defined(OP_PGM)
    return native.index.finalopt_partition_path(key);
#else
    return native.path(key);
#endif
}

static std::vector<uint64_t> prefix(const Native& native,Key key,size_t depth) {
    auto p=partition_path(native,key);if(p.size()>depth)p.resize(depth);return p;
}

struct CoverRegion {
    size_t begin=0,end=0,depth=0,sample_count=0;
    bool fallback=false;Features mass{};
};

// For each target cap, seek a genuine child/leaf/segment boundary at the
// shallowest usable native prefix. A giant unsplittable native leaf is capped
// by an explicitly reported rank fallback. No original key is omitted.
static std::vector<CoverRegion> covering_regions(const Native& native,
                                               const std::vector<Key>& real,
                                               size_t cap) {
    if(!cap)throw std::runtime_error("region-max-keys must be positive");
    std::vector<CoverRegion> out;size_t begin=0;
    while(begin<real.size()) {
        const size_t target=begin+std::min(cap,real.size()-begin);
        if(target==real.size()) {out.push_back({begin,target,0,0,false,{}});break;}
        size_t cut=0,used_depth=0;bool fallback=false;
        const auto full=partition_path(native,real[target-1]);
        for(size_t depth=1;depth<=std::max<size_t>(1,full.size());++depth) {
            const auto group=prefix(native,real[target-1],depth);
            if(group.empty())break;
            size_t lo=begin,hi=target;
            while(lo<hi) {
                const size_t mid=lo+(hi-lo)/2;
                if(prefix(native,real[mid],depth)<group)lo=mid+1;else hi=mid;
            }
            const size_t group_begin=lo;
            lo=target;hi=real.size();
            while(lo<hi) {
                const size_t mid=lo+(hi-lo)/2;
                if(prefix(native,real[mid],depth)<=group)lo=mid+1;else hi=mid;
            }
            const size_t group_end=lo;
            if(group_end<=target) {cut=group_end;used_depth=depth;break;}
            // Snap backward only when at least a quarter-cap has been covered;
            // otherwise descend, avoiding pathological tiny prefix partitions.
            if(group_begin>begin && group_begin-begin>=std::max<size_t>(1,cap/4)) {
                cut=group_begin;used_depth=depth;break;
            }
            if(group_end-begin<=cap) {cut=group_end;used_depth=depth;break;}
        }
        if(cut<=begin || cut>target) {cut=target;fallback=true;used_depth=full.size();}
        out.push_back({begin,cut,used_depth,0,fallback,{}});begin=cut;
    }
    size_t expected=0;
    for(const auto& r:out) {
        if(r.begin!=expected||r.end<=r.begin||r.end-r.begin>cap)
            throw std::runtime_error("Noncovering native partition");
        expected=r.end;
    }
    if(expected!=real.size())throw std::runtime_error("Incomplete native partition");
    return out;
}

static void write_f64(std::ofstream& out,double value) {
    static_assert(sizeof(double)==8&&std::numeric_limits<double>::is_iec559,
                  "Feature files require binary64");
    uint64_t bits=0;std::memcpy(&bits,&value,8);unsigned char data[8];
    for(size_t j=0;j<8;++j)data[j]=static_cast<unsigned char>(bits>>(8*j));
    out.write(reinterpret_cast<const char*>(data),8);
}

static void protect_output(const std::string& output,const std::vector<std::string>& inputs) {
    const auto path=std::filesystem::weakly_canonical(output);
    for(const auto& input:inputs) {
        if(path==std::filesystem::weakly_canonical(input) ||
           (std::filesystem::exists(path)&&std::filesystem::exists(input)&&
            std::filesystem::equivalent(path,input)))
            throw std::runtime_error("Native output would overwrite an input");
    }
}

static uint64_t write_structural(const Native& native,const std::vector<Key>& real,
                                const std::string& output_path) {
    const auto started=now_ns();
#if defined(OP_PGM)
    auto profile=extract_pgm(native,real,false);
#else
    auto profile=extract_alex_lipp(native,real,false);
#endif
    const auto elapsed=now_ns()-started;
    std::ofstream output(output_path);
    if(!output)throw std::runtime_error("Cannot create structural JSON");
    output<<std::setprecision(17)
          <<"{\"schema\":\"gafis_structural_v1\",\"index\":\""<<Native::name
          <<"\",\"query_free_structural_pass\":true,\"per_key_buffer_retained\":false"
          <<",\"extract_ns\":"<<elapsed<<",\"level_orientation\":\""
#if defined(OP_PGM)
          <<"bottom_zero"
#else
          <<"root_zero"
#endif
          <<"\",\"features\":{";
    bool first=true;
    for(const auto& feature:profile.f) {
        if(!std::isfinite(feature.second))
            throw std::runtime_error("Nonfinite structural feature");
        if(!first)output<<',';first=false;
        output<<'\"'<<feature.first<<"\":"<<feature.second;
    }
    output<<"}}\n";output.flush();
    if(!output)throw std::runtime_error("Structural JSON write failed");
    return elapsed;
}

static void write_regions(const std::string& path,const std::vector<CoverRegion>& regions,
                          const std::vector<Key>& real) {
    std::ofstream out(path);if(!out)throw std::runtime_error("Cannot create regions CSV");
    out<<"id,begin,end,original_count,left,right,boundary_depth,kind,gap_begin,gap_end,sample_count";
    for(size_t j=0;j<F;++j)out<<",feature_mass_"<<j;
    out<<'\n'<<std::setprecision(17);
    for(size_t i=0;i<regions.size();++i) {
        const auto& r=regions[i];
        out<<i<<','<<r.begin<<','<<r.end<<','<<r.end-r.begin<<','<<real[r.begin]<<','<<real[r.end-1]
           <<','<<r.depth<<','<<(r.fallback?"rank_fallback_inside_native_leaf":"grouped_native_path_regions")
           <<','<<r.begin<<','<<std::min(r.end,real.size()-1)<<','<<r.sample_count;
        for(double v:r.mass)out<<','<<v;out<<'\n';
    }
    out.flush();if(!out)throw std::runtime_error("Regions CSV write failed");
}

// Calibration is an optional baseline-only operation. The CSV reports raw
// native lookup block times and associated feature means; coefficients are
// fitted externally, never invented as cache penalties.
static void calibration(Native& native,const std::vector<Key>& queries,
                        const std::vector<Features>& features,const std::string& output) {
    std::ofstream out(output);if(!out)throw std::runtime_error("Cannot create calibration CSV");
    out<<"repeat,block,operations,elapsed_ns,checksum";
    for(const auto* name:feature_names)out<<','<<name;out<<'\n'<<std::setprecision(17);
    const size_t block_size=std::min<size_t>(4096,queries.size());
    const size_t blocks=std::min<size_t>(128,(queries.size()+block_size-1)/block_size);
    uint64_t checksum=0;
    std::vector<std::vector<size_t>> order(blocks);
    for(size_t block=0;block<blocks;++block) {
        const size_t begin=block*block_size,end=std::min(begin+block_size,queries.size());
        auto& positions=order[block];positions.resize(end-begin);
        std::iota(positions.begin(),positions.end(),begin);
        std::mt19937_64 rng(42+block);
        std::shuffle(positions.begin(),positions.end(),rng);
    }
    for(size_t rep=0;rep<3;++rep) {
      // Warm the whole representative pool, not each timed block immediately:
      // the latter would force an artificially cache-hot 4096-key workload.
      for(Key key:queries){bool found=false;checksum+=native.lookup(key,found);}
      for(size_t block=0;block<blocks;++block) {
        const size_t begin=block*block_size,end=std::min(begin+block_size,queries.size());
        Features means{};for(size_t i=begin;i<end;++i)for(size_t j=0;j<F;++j)means[j]+=features[i][j];
        const uint64_t start=now_ns();
        // Search samples are stratum-interleaved for balanced prefixes. Avoid
        // benchmarking monotonic rank-stratum execution during calibration.
        for(size_t i:order[block]){bool found=false;checksum+=native.lookup(queries[i],found);}
        const auto elapsed=now_ns()-start;
        out<<rep<<','<<block<<','<<end-begin<<','<<elapsed<<','<<checksum;
        for(double v:means)out<<','<<v/(end-begin);out<<'\n';
      }
    }
    out.flush();if(!out)throw std::runtime_error("Calibration CSV write failed");
}
}

int main(int argc,char** argv) {
    try {
        if(argc%2!=1)throw std::runtime_error("Options require --name value pairs");
        Args args;for(int i=1;i<argc;i+=2)
            if(std::string(argv[i]).rfind("--",0)!=0||!args.emplace(argv[i],argv[i+1]).second)
                throw std::runtime_error("Invalid or duplicate native option");
        const std::string real_path=args.at("--real"),physical_path=get(args,"--physical",real_path);
        const std::string query_path=args.at("--queries"),feature_path=args.at("--features-out");
        const std::string region_path=args.at("--regions-out");
        const std::vector<std::string> inputs={real_path,physical_path,query_path};
        finalopt::protect_output(feature_path,inputs);finalopt::protect_output(region_path,inputs);
        if(std::filesystem::weakly_canonical(feature_path)==std::filesystem::weakly_canonical(region_path))
            throw std::runtime_error("Feature and region outputs must differ");
        if(args.count("--calibration-out")) {
            const auto calibration_path=std::filesystem::weakly_canonical(args.at("--calibration-out"));
            finalopt::protect_output(args.at("--calibration-out"),inputs);
            if(calibration_path==std::filesystem::weakly_canonical(feature_path) ||
               calibration_path==std::filesystem::weakly_canonical(region_path))
                throw std::runtime_error("Calibration output must differ from features and regions");
        }
        if(args.count("--structural-out")) {
            const auto structural=std::filesystem::weakly_canonical(args.at("--structural-out"));
            finalopt::protect_output(args.at("--structural-out"),inputs);
            if(structural==std::filesystem::weakly_canonical(feature_path) ||
               structural==std::filesystem::weakly_canonical(region_path) ||
               (args.count("--calibration-out") &&
                structural==std::filesystem::weakly_canonical(args.at("--calibration-out"))))
                throw std::runtime_error("Structural output must differ from all other outputs");
        }
        auto real=load(real_path),physical=load(physical_path),queries=load(query_path);
        validate(real);validate(physical);if(queries.empty())throw std::runtime_error("No search queries");
        auto values=records(physical,real);
        const auto validation=get(args,"--validate","sample");
        if(validation!="all"&&validation!="sample")throw std::runtime_error("validate must be all or sample");
        phase("finalopt_build_start",values.size());
        const uint64_t build_start=now_ns();op_ledger::enabled=true;
        auto native=std::make_unique<Native>(values);op_ledger::enabled=false;
        const auto build_ns=now_ns()-build_start;
        const size_t retained=op_ledger::live,peak=op_ledger::peak;
        phase("finalopt_build_complete",values.size());
        uint64_t structural_extract_ns=0;
        if(args.count("--structural-out")) {
            structural_extract_ns=finalopt::write_structural(*native,real,args.at("--structural-out"));
        }
        size_t validated=0;
        const size_t validation_stride=validation=="all"?1:std::max<size_t>(1,values.size()/4096);
        for(size_t i=0;i<values.size();i+=validation_stride) {
            bool found=false;const auto value=native->lookup(values[i].first,found);
            if(!found||value!=values[i].second)throw std::runtime_error("Physical payload validation failed");
            ++validated;
        }
        if(validation!="all") {
            bool found=false;const auto& row=values.back();const auto value=native->lookup(row.first,found);
            if(!found||value!=row.second)throw std::runtime_error("Last physical payload validation failed");
            ++validated;
        }
        const auto cap=std::stoull(get(args,"--region-max-keys","1000000"));
        const auto regions_start=now_ns();
        auto regions=finalopt::covering_regions(*native,real,cap);
        const auto regions_extract_ns=now_ns()-regions_start;
        std::ofstream output(feature_path,std::ios::binary|std::ios::trunc);
        if(!output)throw std::runtime_error("Cannot create native feature binary");
        std::vector<finalopt::Features> all_features;
        if(args.count("--calibration-out"))all_features.reserve(queries.size());
        finalopt::Features sum{};uint64_t query_checksum=0;
        const auto counter_start=now_ns();
        PhaseProgress progress("finalopt_sample_features",queries.size());
        for(size_t i=0;i<queries.size();++i) {
            const auto at=std::lower_bound(real.begin(),real.end(),queries[i]);
            if(at==real.end()||*at!=queries[i])throw std::runtime_error("Native features require original queries");
            const size_t rank=at-real.begin();const auto f=finalopt::lookup_features(*native,queries[i],rank+1);
            query_checksum+=rank+1;
            auto region=std::upper_bound(regions.begin(),regions.end(),rank,
                [](size_t value,const finalopt::CoverRegion& r){return value<r.end;});
            if(region==regions.end()||rank<region->begin)throw std::runtime_error("Query region coverage mismatch");
            ++region->sample_count;
            for(size_t j=0;j<finalopt::F;++j) {
                finalopt::write_f64(output,f[j]);sum[j]+=f[j];region->mass[j]+=f[j];
            }
            if(args.count("--calibration-out"))all_features.push_back(f);
            progress.tick(i+1);
        }
        output.flush();if(!output)throw std::runtime_error("Native feature binary write failed");
        const auto counter_features_ns=now_ns()-counter_start;
        finalopt::write_regions(region_path,regions,real);
        if(args.count("--calibration-out")) {
            finalopt::protect_output(args.at("--calibration-out"),inputs);
            finalopt::calibration(*native,queries,all_features,args.at("--calibration-out"));
        }
        size_t fallbacks=0;for(const auto& r:regions)fallbacks+=r.fallback;
        std::cout<<std::setprecision(17)<<"RESULT_JSON {\"success\":true,\"index\":\""<<Native::name
                 <<"\",\"real_count\":"<<real.size()<<",\"physical_count\":"<<physical.size()
                 <<",\"shadow_count\":"<<physical.size()-real.size()<<",\"query_count\":"<<queries.size()
                 <<",\"query_checksum\":\""<<query_checksum<<"\",\"queries_correct\":true"
                 <<",\"validation\":\""<<validation<<"\",\"validated_physical_records\":"<<validated
                 <<",\"all_physical_validated\":"<<(validation=="all"?"true":"false")
                 <<",\"total_bytes\":"<<retained<<",\"peak_build_bytes\":"<<peak
                 <<",\"memory_scope\":\"retained native requested allocation bytes; includes virtual records; excludes input arrays and allocator overhead\""
                 <<",\"build_time_ms\":"<<double(build_ns)/1e6<<",\"region_count\":"<<regions.size()
                 <<",\"structural_extract_ns\":"<<structural_extract_ns
                 <<",\"region_extract_ns\":"<<regions_extract_ns
                 <<",\"counter_features_ns\":"<<counter_features_ns
                 <<",\"fallback_region_count\":"<<fallbacks<<",\"region_coverage\":\"all_original_keys\""
                 <<",\"feature_format\":\"little_endian_f64_row_major\",\"feature_columns\":[";
        for(size_t j=0;j<finalopt::F;++j){if(j)std::cout<<',';std::cout<<'"'<<finalopt::feature_names[j]<<'"';}
        std::cout<<"],\"feature_means\":[";
        for(size_t j=0;j<finalopt::F;++j){if(j)std::cout<<',';std::cout<<sum[j]/queries.size();}
        std::cout<<"],\"throughput_used_for_selection\":false}\n"<<std::flush;
        return 0;
    } catch(const std::exception& e) {std::cerr<<"FAILED: "<<e.what()<<'\n';return 8;}
}
