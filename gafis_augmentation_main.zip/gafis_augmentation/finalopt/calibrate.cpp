// Standalone platform probes. These are not candidate-index throughput runs.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>

using Clock=std::chrono::steady_clock;
static volatile uint64_t sink=0;
struct alignas(64) Cell {uint64_t next;uint64_t key;char padding[48];};
template<class F> double median(F operation) {
    std::vector<double> result;
    operation();
    for(int r=0;r<5;++r)result.push_back(operation());
    std::sort(result.begin(),result.end());return std::max(.01,result[2]);
}
static double access_cost(size_t count) {
    std::vector<Cell> cells(count);std::vector<uint32_t> permutation(count);
    std::iota(permutation.begin(),permutation.end(),0);std::mt19937 rng(1729);
    std::shuffle(permutation.begin(),permutation.end(),rng);
    for(size_t i=0;i<count;++i){cells[permutation[i]].next=permutation[(i+1)%count];cells[i].key=i*13+7;}
    const size_t iterations=std::max<size_t>(1<<19,count);
    return median([&](){uint64_t p=0,sum=0;auto start=Clock::now();
        for(size_t i=0;i<iterations;++i){p=cells[p].next;sum+=uint64_t(double(cells[p].key)*.125+3.);}
        auto end=Clock::now();sink=sum+p;
        return std::chrono::duration<double,std::nano>(end-start).count()/iterations;});
}
static double comparison_cost(size_t count,bool exponential) {
    std::vector<uint64_t> keys(count);for(size_t i=0;i<count;++i)keys[i]=i*17+11;
    const size_t queries=1<<17,block=64;std::vector<uint64_t> ranks(queries);
    std::mt19937_64 rng(19);for(auto& x:ranks)x=rng()%count;
    return median([&](){uint64_t comparisons=0,sum=0;auto start=Clock::now();
        for(auto rank:ranks){const auto key=keys[rank];size_t begin=rank/block*block,end=std::min(count,begin+block);
            if(exponential){size_t step=1;while(begin+step<end){++comparisons;if(keys[begin+step]>=key)break;step*=2;}
                end=std::min(end,begin+step+1);begin+=step/2;}
            while(begin<end){size_t mid=begin+(end-begin)/2;++comparisons;if(keys[mid]<key)begin=mid+1;else end=mid;}
            sum+=begin;}
        auto finish=Clock::now();sink=sum;
        return std::chrono::duration<double,std::nano>(finish-start).count()/std::max<uint64_t>(1,comparisons);});
}
int main(int argc,char** argv) {
    size_t megabytes=argc>1?std::stoull(argv[1]):128;
    if(megabytes<1||megabytes>2048)return 2;
    double root=access_cost(256),other=access_cost(megabytes*1024*1024/sizeof(Cell));
    double small=comparison_cost(8192,false),large=comparison_cost(megabytes*1024*1024/8,false);
    double exp=comparison_cost(megabytes*1024*1024/8,true);
    const size_t iterations=1<<22;
    double model=median([&](){auto start=Clock::now();uint64_t total=0;
        for(size_t i=0;i<iterations;++i)total+=uint64_t(double(i+sink%3)*.137+9.);
        auto finish=Clock::now();sink=total;return std::chrono::duration<double,std::nano>(finish-start).count()/iterations;});
    std::cout.precision(17);
    std::cout<<"{\"schema\":\"platform_operation_probes_v1\",\"large_workset_mib\":"<<megabytes
        <<",\"repeats\":5,\"statistic\":\"median\",\"measured_candidate_throughput\":false,"
        <<"\"cache_miss_probability_measured\":false,\"coefficients_ns\":{"
        <<"\"root_steps\":"<<root<<",\"other_steps\":"<<other<<",\"leaf_models\":"<<model
        <<",\"exponential_comparisons\":"<<exp<<",\"binary_comparisons\":"<<large
        <<",\"route_comparisons\":"<<small<<",\"correction_comparisons\":"<<large
        <<",\"final_comparisons\":"<<small<<"}}\n";
}
