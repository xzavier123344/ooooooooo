"""Full native index construction and frozen operation-count profiling."""
from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile
import time
import numpy as np
from finalopt import cost, proposals, sampling
from population import binary
from multi_sse_v5 import driver as d, storage, fast_measurement as timing
ROOT = Path(__file__).resolve().parents[1]

def executable(name):
    path=ROOT/'finalopt'/'bin'/name
    if not path.is_file():path=path.with_suffix('.exe')
    if not path.is_file():raise FileNotFoundError('Run python build.py first: '+str(path))
    return str(path)


def pinned(a,command):
    cpu=timing.old.resolve_cpu(a.cpu)
    return ['taskset','-c',str(cpu)]+command if os.name!='nt' and cpu is not None else command


def calibrate(a):
    path=a.out.resolve()/'calibration.json'
    if path.exists():return d.read(path)
    if a.calibration_file:
        info=d.read(a.calibration_file)
    else:
        print('[CALIBRATION START] independent platform operation probes',flush=True)
        command=[executable('operation_calibration'),str(a.calibration_mib)]
        done=subprocess.run(pinned(a,command),capture_output=True,text=True,timeout=a.timeout,check=True)
        info=json.loads(done.stdout)
    coeff=info.get('coefficients_ns',{})
    if set(coeff)!=set(cost.FEATURES) or any(not math.isfinite(float(v)) or float(v)<=0 for v in coeff.values()):
        raise ValueError('Calibration must supply positive finite ns for all eight feature types')
    info.update(frozen_before_candidate_search=True,calibration_scope='standalone operation probes; not exact per-index cache simulation',
                model_fidelity_requires_validation=True)
    d.write(path,info)
    print('[CALIBRATION FROZEN]',coeff,flush=True)
    return info


def native(a,case,physical,query,folder,all_keys=False,calibration=False):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    features=folder/'features.f64';regions=folder/'native_regions.csv';log=folder/'native.log'
    command=[executable('finalopt_'+case['index']),'--real',case['real_path'],'--physical',str(physical),
        '--queries',str(query),'--features-out',str(features),'--regions-out',str(regions),
        '--validate','all' if all_keys else 'sample','--region-max-keys',str(a.region_max_keys)]
    if calibration:command.extend(['--calibration-out',str(folder/'baseline_operation_calibration.csv')])
    structural_enabled=False
    if structural_enabled:
        command.extend(['--structural-out',str(folder/'structural.json')])
    start=time.monotonic()
    with log.open('w',encoding='utf-8') as handle:
        process=subprocess.Popen(pinned(a,command),stdout=handle,stderr=subprocess.STDOUT)
        while True:
            try:code=process.wait(timeout=30);break
            except subprocess.TimeoutExpired:
                elapsed=time.monotonic()-start
                print('[NATIVE WAIT]',case['case_id'],'pid='+str(process.pid),'elapsed_s='+str(round(elapsed)),'log='+str(log),flush=True)
                if elapsed>a.timeout:
                    process.kill();process.wait();raise TimeoutError('Native inspection timeout; see '+str(log))
    if code:raise RuntimeError('Native inspection failed; see '+str(log))
    lines=log.read_text(encoding='utf-8',errors='replace').splitlines()
    result=next((json.loads(x[len('RESULT_JSON '):]) for x in reversed(lines) if x.startswith('RESULT_JSON ')),None)
    if not result or result['feature_columns']!=list(cost.FEATURES):raise ValueError('Native feature schema changed')
    if result['real_count']!=case['n0'] or result['physical_count']*8!=Path(physical).stat().st_size:
        raise ValueError('Native population size mismatch')
    result.update(elapsed_seconds=time.monotonic()-start)
    if structural_enabled:
        structural=d.read(folder/'structural.json')
        if structural.get('schema')!='gafis_structural_v1':
            raise ValueError('Native structural feature schema changed')
        if int(structural['features']['original_count'])!=case['n0']:
            raise ValueError('Structural profile original-key coverage mismatch')
        result.update(structural=structural,structural_path=str((folder/'structural.json').resolve()),
                      structural_extract_ns=int(structural['extract_ns']))
    d.write(folder/'native_summary.json',result)
    return result,features,regions


@contextmanager
def physical(a,case,points,metrics_dest=None):
    k=Path(points).stat().st_size//8
    if not k and metrics_dest is None:yield Path(case['real_path']);return
    storage.ensure_space(Path(a.scratch_dir),(case['n0']+k)*8)
    with tempfile.TemporaryDirectory(prefix='finalopt_',dir=a.scratch_dir) as temp:
        target=Path(temp)/'physical.bin';metric=Path(metrics_dest) if metrics_dest else Path(temp)/'distribution.json'
        binary.invoke('merge',case['real_path'],points,target,metric,timeout=a.timeout)
        yield target if k else Path(case['real_path'])


def attach_region_costs(regions,coeff,global_mean):
    expected=0;result=[]
    for r in d.csvread(regions):
        r=dict(r);begin,end=int(r['begin']),int(r['end'])
        if begin!=expected or end<=begin:raise ValueError('Native regions have gaps/overlap')
        expected=end;nq=int(r['sample_count'])
        mass=sum(float(r['feature_mass_'+str(i)])*coeff[name] for i,name in enumerate(cost.FEATURES))
        mean=mass/nq if nq else global_mean
        r.update(begin=begin,end=end,original_count=end-begin,mean_cost=mean,cost_mass=mean*(end-begin))
        result.append(r)
    return result


class CaseSearch:
    def __init__(self,a,case,folder,samples,calibration):
        self.a,self.case,self.folder,self.samples,self.calibration=a,case,folder,samples,calibration
        if (folder/'index_calibration.json').exists():self.calibration=d.read(folder/'index_calibration.json')
        self.rows=[];self.by_id={};self.attempts=0;self.started=time.monotonic()
        clock=folder/'search_clock.json'
        self.prior_elapsed=float(d.read(clock)['elapsed_seconds']) if clock.exists() else 0.
        self.deadline=self.started+max(0.,a.case_seconds-self.prior_elapsed)
        self.cap_hit=False;self.failures=[]
        self.alias_path=folder/'candidate_aliases.json'
        self.aliases=d.read(self.alias_path) if self.alias_path.exists() else {}
        for f in sorted((folder/'states').glob('*/state.json')):
            row=d.read(f);self.rows.append(row);self.by_id[row['state_id']]=row
        self.rows.sort(key=lambda r:r['order'])
        self.attempts=len(d.lines(folder/'attempts.jsonl'))
    def allowed(self):
        okay=self.attempts<self.a.native_cap and time.monotonic()<self.deadline
        self.cap_hit|=not okay
        return okay
    def recipe_id(self,recipe):return hashlib.sha256(json.dumps(recipe,sort_keys=True).encode()).hexdigest()[:24]
    def ensure_points(self,row):
        path=Path(row['shadow_path'])
        if path.exists():
            if path.stat().st_size!=row['k']*8 or d.digest(path)!=row['shadow_sha256']:raise ValueError('Candidate points changed')
            return path
        self.generate(row['recipe'],path.parent)
        if d.digest(path)!=row['shadow_sha256']:raise ValueError('Candidate regeneration differs')
        return path
    def release_shadows(self,keep=()):
        """Release regenerated ancestors between trials, keeping recipes/hashes."""
        keep=set(keep)
        for row in self.rows:
            if not row['k'] or row['state_id'] in keep:continue
            path=Path(row['shadow_path']).resolve()
            try:path.relative_to(self.folder.resolve())
            except ValueError:raise ValueError('Refuse shadow release outside owned case')
            path.unlink(missing_ok=True)
    def generate(self,recipe,dest):
        a=self.a;dest=Path(dest);dest.mkdir(parents=True,exist_ok=True);out=dest/'shadows.bin'
        if recipe['action']=='original':out.touch();return out
        parent=self.by_id[recipe['parent']];parent_regions=d.read(parent['regions_path'])
        if recipe.get('global_regions'):
            parent_regions=[dict(begin=0,end=self.case['n0'],mean_cost=parent['estimated_cost_ns'])]
        if recipe['action']=='remove':
            old=np.memmap(self.ensure_points(parent),dtype='<u8',mode='r')
            try:
                # Evenly retained shadow ranks, bounded chunks; no millions of Python ints.
                target=int(recipe['target_k'])
                with out.open('wb') as handle:
                    for start in range(0,target,1000000):
                        ranks=np.arange(start,min(target,start+1000000),dtype=np.int64)*len(old)//target
                        np.asarray(old[ranks],dtype='<u8').tofile(handle)
            finally:old._mmap.close()
            return out
        kwargs=dict(generator=recipe['generator'],scope=recipe['scope'],allocation=recipe['allocation'],timeout=a.proposal_timeout)
        if 'proposal_seed' in recipe:
            kwargs['seed']=int(recipe['proposal_seed'])
        if recipe['action']=='add' and parent['k']:
            parent_points=self.ensure_points(parent)
            with physical(a,self.case,parent_points) as current:
                original=np.memmap(self.case['real_path'],dtype='<u8',mode='r')
                merged=np.memmap(current,dtype='<u8',mode='r');mapped=[]
                try:
                    for r in parent_regions:
                        b=int(np.searchsorted(merged,original[int(r['begin'])]))
                        e=int(np.searchsorted(merged,original[int(r['end'])])) if int(r['end'])<len(original) else len(merged)
                        mapped.append(dict(r,begin=b,end=e))
                finally:original._mmap.close();merged._mmap.close()
                generated=proposals.generate(current,mapped,recipe['target_k']-parent['k'],dest/'increment',**kwargs)
                actual=proposals.merge_points(parent_points,generated['points_path'],out,timeout=a.proposal_timeout)
                Path(generated['points_path']).unlink(missing_ok=True)
                if actual!=recipe['target_k']:raise ValueError('Cumulative Add count mismatch')
        else:
            generated=proposals.generate(self.case['real_path'],parent_regions,recipe['target_k'],dest/'proposal',**kwargs)
            Path(generated['points_path']).replace(out)
        return out
    def trial(self,recipe,role):
        sid=self.recipe_id(recipe)
        if sid in self.by_id:return self.by_id[sid]
        if sid in self.aliases and self.aliases[sid] in self.by_id:return self.by_id[self.aliases[sid]]
        if not self.allowed():return None
        dest=self.folder/'states'/sid;dest.mkdir(parents=True,exist_ok=True)
        phase_started=time.monotonic(); proposal_seconds=0.; feasibility_seconds=0.
        try:
            print('[PROPOSE]',self.case['case_id'],role,'action='+recipe['action'],'target='+str(recipe['target_k']),flush=True)
            points=self.generate(recipe,dest);k=points.stat().st_size//8
            proposal_seconds=time.monotonic()-phase_started
            io_event=dict(state_id=sid,phase='proposal_generation',seconds=proposal_seconds)
            d.append(self.folder/'overhead_events.jsonl',io_event)
            if k!=recipe['target_k']:raise ValueError('Requested and generated count differ')
            dist_path=dest/'distribution.json'
            phase_started=time.monotonic()
            with physical(self.a,self.case,points,dist_path) as merged:
                metrics=d.read(dist_path)
                identity=d.digest(merged)
                feasibility_seconds=time.monotonic()-phase_started
                d.append(self.folder/'overhead_events.jsonl',dict(state_id=sid,phase='feasibility_and_identity',seconds=feasibility_seconds))
                cached=next((r for r in self.rows if r['physical_sha256']==identity),None)
                if cached is not None:
                    self.aliases[sid]=cached['state_id'];d.write(self.alias_path,self.aliases)
                    d.append(self.folder/'cache_hits.jsonl',dict(recipe_id=sid,state_id=cached['state_id'],physical_sha256=identity))
                    points.unlink(missing_ok=True)
                    return cached
                if not self.allowed():return None
                self.attempts+=1;d.append(self.folder/'attempts.jsonl',dict(state_id=sid,role=role,k=k,recipe=recipe))
                reuse_calibration=bool(getattr(self.a,'reuse_index_calibration',False))
                summary,feature_path,region_path=native(self.a,self.case,merged,self.samples['search_queries'],dest,
                                                       calibration=recipe['action']=='original' and not reuse_calibration)
                identity=d.digest(merged)
            if recipe['action']=='original':
                if reuse_calibration:
                    if self.calibration.get('index',self.case['index'])!=self.case['index']:
                        raise ValueError('Reused operation calibration belongs to another index')
                else:
                    from finalopt.calibration import fit
                    calibration_csv=dest/'baseline_operation_calibration.csv'
                    blocks={r['block'] for r in d.csvread(calibration_csv)}
                    if len(blocks)>=5:
                        self.calibration=fit(calibration_csv,self.calibration,self.case['index'])
                    else:
                        self.calibration=dict(self.calibration,index=self.case['index'],native_baseline_fit=False,
                            fallback_reason='fewer than five independent calibration blocks; retain measured operation priors')
                d.write(self.folder/'index_calibration.json',self.calibration)
            features=np.memmap(feature_path,dtype='<f8',mode='r',shape=(self.samples['search_count'],8))
            values=cost.query_cost(features,self.calibration)
            unweighted=np.sum(features,axis=1)
            feature_means=np.mean(features,axis=0).tolist();features._mmap.close()
            ranks=np.memmap(self.samples['search_ranks'],dtype='<u8',mode='r')
            mean,se=sampling.estimate(values,ranks,self.samples['bounds'])
            prefixes=[]
            for q in sorted(set(min(x,len(values)) for x in (262144,1048576,2097152))):
                if q<self.samples['declaration']['strata']:continue
                m,s=sampling.estimate(values[:q],ranks[:q],self.samples['bounds'])
                prefixes.append(dict(queries=q,estimated_cost_ns=m,descriptive_sampling_se=s))
            ranks._mmap.close()
            np.savez_compressed(dest/'query_costs.npz',values=values)
            region_data=attach_region_costs(region_path,self.calibration['coefficients_ns'],mean)
            if region_data[-1]['end']!=self.case['n0']:raise ValueError('Native region coverage incomplete')
            d.write(dest/'regions.json',region_data)
            row=dict(self.case)
            row.update(metrics)
            row.update(state_id=sid,order=len(self.rows),role=role,recipe=recipe,k=k,requested_k=k,actual_k=k,
                shadow_path=str(points.resolve()),shadow_sha256=d.digest(points),physical_sha256=identity,
                regions_path=str((dest/'regions.json').resolve()),costs_path=str((dest/'query_costs.npz').resolve()),
                estimated_cost_ns=mean,sampling_se=se,prefix_estimates=prefixes,feature_means=feature_means,
                proposal_seconds=proposal_seconds,feasibility_seconds=feasibility_seconds,
                equal_weight_feature_sum=float(np.mean(unweighted)),total_bytes=summary['total_bytes'],
                native_summary=summary,selection_uses_throughput=False)
            d.write(dest/'state.json',row);self.rows.append(row);self.by_id[sid]=row
            feature_path.unlink(missing_ok=True)
            if k:points.unlink()  # Keep recipe+hash; regenerate only frozen timing endpoints.
            print('[VERIFIED]',self.case['case_id'],'k='+str(k),'C_ns='+str(mean),'S='+str(row['total_bytes']),flush=True)
            return row
        except Exception as error:
            failure=dict(state_id=sid,role=role,recipe=recipe,error_type=type(error).__name__,error=str(error))
            self.failures.append(failure);d.append(self.folder/'failures.jsonl',failure)
            print('[FAILED CANDIDATE]',failure,flush=True)
            # A failed build keeps its recipe/log, not an 800MB shadow array or
            # half-written feature dump. Never remove a previously valid state.
            if not (dest/'state.json').exists():
                for leftover in (dest/'shadows.bin',dest/'features.f64',dest/'increment'/'shadows.bin'):
                    leftover.unlink(missing_ok=True)
            if storage.is_disk_full(error):raise
            return None
        finally:
            self.release_shadows()
            d.csvwrite(self.folder/'candidate_summary.csv',[{k:v for k,v in r.items() if not isinstance(v,(dict,list))} for r in self.rows])
            d.write(self.folder/'search_clock.json',dict(elapsed_seconds=self.prior_elapsed+time.monotonic()-self.started,
                scope='active search invocation time accumulated across completed checkpoints; excludes idle restart gaps'))


def recipe(parent,k,action='replace',generator='gap',scope='hybrid',allocation='marginal'):
    return dict(parent=parent['state_id'],target_k=int(k),action=action,generator=generator,scope=scope,allocation=allocation)


def freeze(a,engine,rows,policies,stop):
    folder=engine.folder/'selection';folder.mkdir(parents=True,exist_ok=True)
    artifacts={engine.case['real_path']:engine.case['real_sha256'],engine.case['source_info_path']:d.digest(engine.case['source_info_path'])}
    variants=[];retained=set()
    for r in rows:
        points=engine.ensure_points(r);plan=folder/(r['physical_sha256']+'.json')
        content=dict(format='uint64_binary_v1',binary_path=str(points.resolve()),binary_sha256=d.digest(points),
                     k=r['k'],physical_sha256=r['physical_sha256'])
        d.write(plan,content);artifacts[str(plan.resolve())]=d.digest(plan);artifacts[str(points.resolve())]=content['binary_sha256']
        variant=dict(r,method='original' if not r['k'] else r['state_id'],variant_id=engine.case['case_id']+'.'+r['state_id'],
            points_path=str(plan.resolve()),points_format='uint64_binary_v1',storage_mode='compact',
            physical_path=engine.case['real_path'] if not r['k'] else '',physical_array_persistent=not bool(r['k']),
            correct=True,status='ok',frozen_before_timing=True)
        variants.append(variant)
        retained.add(r['state_id'])
        engine.release_shadows(retained)
    d.csvwrite(folder/'parameter_selections.csv',policies)
    artifacts[str((folder/'parameter_selections.csv').resolve())]=d.digest(folder/'parameter_selections.csv')
    manifest=dict(schema=d.SCHEMA,cases=[engine.case],declaration=dict(external_policy_specs=True),
        artifact_hashes=artifacts,code_hashes=d.code_hashes())
    frozen=dict(schema=d.SCHEMA,variants=variants,artifact_hashes=artifacts,code_hashes=d.code_hashes(),
        frozen_before_timing=True,selection_uses_throughput=False,all_policy_groups_complete=True,
        optimum_guaranteed=False,search_stop=stop,request_p99_latency_measured=False)
    policy_ids=[p.get('state_id',p.get('selected_state')) for p in policies]
    physical={r['physical_sha256'] for r in rows}
    frozen.update(all_weight_choices_recorded=True,
        all_weight_endpoints_selected_for_timing=all(sid in engine.by_id and
            engine.by_id[sid]['physical_sha256'] in physical for sid in policy_ids),
        policy_coverage_note='all_policy_groups_complete refers to recorded choices; timing coverage is reported separately')
    d.write(folder/'manifest.json',manifest);d.write(folder/'frozen_manifest.json',frozen)

