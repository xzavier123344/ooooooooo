// Batch gap allocation and refitted-rank SSE coordinate proposals.
// O(original keys + generated points) passes; no per-point refits, JSON arrays,
// or whole-population in-memory merge.  This is not the CSV subtree algorithm.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>
using U=uint64_t; using Wide=unsigned __int128;
struct Reader {
  std::ifstream f;std::vector<U>b;size_t p=0,n=0;U last=0;bool seen=false;
  explicit Reader(const std::string&s):f(s,std::ios::binary),b(65536){if(!f||std::filesystem::file_size(s)%8)throw std::runtime_error("union input open/partial UInt64");}
  bool next(U&x){if(p==n){f.read((char*)b.data(),b.size()*8);auto bytes=f.gcount();if(bytes%8)throw std::runtime_error("union partial read");n=bytes/8;p=0;if(!n)return false;}x=b[p++];if((seen&&x<=last)||x==std::numeric_limits<U>::max())throw std::runtime_error("union source ordering/sentinel");last=x;seen=true;return true;}
};
struct Writer {
  std::ofstream f; std::vector<U> b; U n=0,last=0;
  explicit Writer(const std::string&s):f(s,std::ios::binary){if(!f)throw std::runtime_error("output open");b.reserve(65536);}
  void add(U x){if(n&&x<=last)throw std::runtime_error("output not strictly increasing");last=x;++n;b.push_back(x);if(b.size()==65536)flush();}
  void flush(){if(b.empty())return;f.write((char*)b.data(),b.size()*8);b.clear();if(!f)throw std::runtime_error("output write (disk full?)");}
  void finish(){flush();f.close();if(!f)throw std::runtime_error("output close");}
};
struct Moment {
  long double n=0,sx=0,sy=0,sxx=0,sxy=0,syy=0;
  void add(long double x,long double y){++n;sx+=x;sy+=y;sxx+=x*x;sxy+=x*y;syy+=y*y;}
  long double slope() const {auto xx=sxx-sx*sx/n;return xx>0?(sxy-sx*sy/n)/xx:0;}
  long double intercept() const {return sy/n-slope()*sx/n;}
  long double loss() const {auto xx=sxx-sx*sx/n,xy=sxy-sx*sy/n,yy=syy-sy*sy/n;return std::max((long double)0,xx>0?yy-xy*xy/xx:yy);}
};
U hash64(U x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
std::vector<U> random_counts(const std::vector<U>&x,U k,U seed,U global_lo){
  U size=x.size()-1;std::vector<U>m(size),eligible;Wide capacity=0;
  for(U i=0;i<size;++i){if(x[i+1]<=x[i]||x[i+1]==std::numeric_limits<U>::max())throw std::runtime_error("source order/sentinel");U cap=x[i+1]-x[i]-1;capacity+=cap;if(cap)eligible.push_back(i);}
  if((Wide)k>capacity)throw std::runtime_error("random requested count exceeds legal capacity");
  auto weight=[&](U i){U left=x[i+1]-x[i]-1-m[i];return (long double)left*(.1L+(long double)(hash64(seed^(global_lo+i))>>11)/9007199254740992.L);};
  U left=k;
  while(left){
    long double total=0;for(U i:eligible)total+=weight(i);if(!(total>0))throw std::runtime_error("random capacity exhausted");
    U remaining=left,used=0;
    for(U i:eligible){U cap=x[i+1]-x[i]-1-m[i];U add=std::min<U>(cap,(U)std::max((long double)0,std::floor((long double)remaining*weight(i)/total)));add=std::min(add,left-used);m[i]+=add;used+=add;}
    left-=used;if(!left)break;
    // Random cyclic permutation rounds one point per legal gap.  This avoids
    // a point-sized hash set and remains practical at tens of millions of keys.
    U count=eligible.size(),start=hash64(seed^global_lo^left)%count,step=1+hash64(seed+global_lo+left)%count;
    while(std::gcd(step,count)!=1){++step;if(step>count)step=1;}
    U idx=start;for(U visit=0;visit<count&&left;++visit){U i=eligible[idx];if(m[i]<x[i+1]-x[i]-1){++m[i];--left;}idx=(idx+step)%count;}
  }
  return m;
}
void random_coordinates(const std::vector<U>&x,const std::vector<U>&m,U seed,U global_lo,Writer&out){
  for(U i=0;i<m.size();++i){if(!m[i])continue;U cap=x[i+1]-x[i]-1;
    for(U j=0;j<m[i];++j){U lo=(U)((Wide)j*cap/m[i]),hi=(U)((Wide)(j+1)*cap/m[i]);
      U offset=lo+hash64(seed^hash64(global_lo+i)^hash64(j))%(hi-lo);out.add(x[i]+1+offset);}
  }
}
std::vector<U> gap_counts(const std::vector<U>&x,U k){
  U size=x.size()-1;std::vector<U> m(size),order;Wide cap=0;
  for(U i=0;i<size;++i){if(x[i+1]<=x[i]||x[i+1]==std::numeric_limits<U>::max())throw std::runtime_error("source order/sentinel");U g=x[i+1]-x[i];cap+=g-1;if(g>1)order.push_back(i);}
  if((Wide)k>cap)throw std::runtime_error("insufficient legal integer capacity");
  auto gap=[&](U i){return x[i+1]-x[i];};
  std::sort(order.begin(),order.end(),[&](U a,U b){return gap(a)!=gap(b)?gap(a)>gap(b):a<b;});
  if(!k)return m;
  long double sum=0,h=1;size_t active=0;
  for(size_t j=0;j<order.size();++j){sum+=(long double)gap(order[j]);active=j+1;h=sum/((long double)k+active);if(j+1==order.size()||(long double)gap(order[j+1])<=h)break;}
  h=std::max((long double)1,h);U used=0;
  for(size_t j=0;j<active;++j){U i=order[j];auto value=std::max((long double)0,std::floor((long double)gap(i)/h-1));m[i]=std::min<U>(gap(i)-1,(U)value);used+=m[i];}
  if(used>k){for(U i:order){U d=std::min(m[i],used-k);m[i]-=d;used-=d;if(used==k)break;}}
  while(used<k){std::sort(order.begin(),order.end(),[&](U a,U b){auto aa=(long double)gap(a)/(m[a]+1),bb=(long double)gap(b)/(m[b]+1);return aa!=bb?aa>bb:a<b;});U before=used;for(U i:order){if(m[i]<gap(i)-1){++m[i];++used;if(used==k)break;}}if(before==used)throw std::runtime_error("rounding capacity");}
  return m;
}
template<class F> void coordinates(const std::vector<U>&x,const std::vector<U>&m,bool fitted,long double slope,long double intercept,F emit){
  U rank=0;const U origin=x.front();
  for(U i=0;i<m.size();++i){emit(x[i],rank++);U prev=x[i],g=x[i+1]-x[i];
    for(U j=1;j<=m[i];++j){U z=x[i]+(U)((Wide)j*g/((Wide)m[i]+1));
      if(fitted&&slope>0&&std::isfinite(slope)){
        U low=prev+1,high=x[i+1]-(m[i]-j+1);
        long double desired=((long double)rank-intercept)/slope;
        long double left=(long double)(low-origin),right=(long double)(high-origin);
        if(std::isfinite(desired)){if(desired<=left)z=low;else if(desired>=right)z=high;else z=origin+(U)std::floor(desired+.5L);z=std::max(low,std::min(high,z));}
      }
      emit(z,rank++);prev=z;
    }
  }
  emit(x.back(),rank);
}
int main(int argc,char**argv){try{
  if(argc==5&&std::string(argv[1])=="union"){
    if(std::filesystem::absolute(argv[2])==std::filesystem::absolute(argv[4])||std::filesystem::absolute(argv[3])==std::filesystem::absolute(argv[4]))throw std::runtime_error("union output must differ from inputs");
    Reader a(argv[2]),b(argv[3]);Writer out(argv[4]);U x=0,y=0;bool ax=a.next(x),by=b.next(y);
    while(ax||by){if(ax&&by&&x==y){out.add(x);ax=a.next(x);by=b.next(y);}else if(ax&&(!by||x<y)){out.add(x);ax=a.next(x);}else{out.add(y);by=b.next(y);}}
    out.finish();std::cout<<out.n<<'\n';return 0;
  }
  if(argc!=6&&argc!=7)throw std::runtime_error("usage: proposal_stream original allocations shadows gap|sse|random report.json [seed]");
  const bool sse=std::string(argv[4])=="sse",random=std::string(argv[4])=="random";if(!sse&&!random&&std::string(argv[4])!="gap")throw std::runtime_error("unknown generator");
  U seed=argc==7?std::stoull(argv[6]):1729;
  auto bytes=std::filesystem::file_size(argv[1]);if(bytes%8||bytes<24)throw std::runtime_error("invalid original file");U n=bytes/8;
  std::ifstream input(argv[1],std::ios::binary),plan(argv[2]);if(!input||!plan)throw std::runtime_error("input open");Writer output(argv[3]);
  U lo,hi,k,last=0,requested=0,regions=0,improved=0;long double uniform_sse=0,selected_sse=0;
  while(plan>>lo>>hi>>k){if(lo!=last||hi<lo||hi>n-1)throw std::runtime_error("gap coverage hole/overlap");last=hi;requested+=k;if(!k)continue;
    std::vector<U>x(hi-lo+1);input.clear();input.seekg(lo*8);input.read((char*)x.data(),x.size()*8);if((U)input.gcount()!=x.size()*8)throw std::runtime_error("short source read");
    auto counts=random?random_counts(x,k,seed,lo):gap_counts(x,k);bool use_fit=false;long double a=0,b=0;Moment base,fit;
    if(sse){U origin=x.front();coordinates(x,counts,false,0,0,[&](U z,U rank){base.add((long double)(z-origin),(long double)rank);});a=base.slope();b=base.intercept();
      coordinates(x,counts,true,a,b,[&](U z,U rank){fit.add((long double)(z-origin),(long double)rank);});
      auto old=base.loss(),next=fit.loss();use_fit=next+std::max((long double)1e-12,std::abs(old)*1e-12L)<old;uniform_sse+=old;selected_sse+=use_fit?next:old;if(use_fit)++improved;
    }
    // Emit only inserted keys.  Original-key rank positions are known from the
    // fixed counts, so no binary searches or per-point object allocation occurs.
    if(random)random_coordinates(x,counts,seed,lo,output);else{U oi=0;coordinates(x,counts,use_fit,a,b,[&](U z,U){if(oi<x.size()&&z==x[oi])++oi;else output.add(z);});}
    ++regions;std::cerr<<"[PROPOSAL REGION] lo="<<lo<<" hi="<<hi<<" k="<<k<<" generator="<<argv[4]<<" sse_update="<<use_fit<<" cumulative="<<output.n<<'\n';
  }
  if(!plan.eof()||last!=n-1)throw std::runtime_error("incomplete allocation coverage");output.finish();if(output.n!=requested)throw std::runtime_error("generated count mismatch");
  std::ofstream report(argv[5]);report<<std::setprecision(19)<<"{\"requested_k\":"<<requested<<",\"actual_k\":"<<output.n<<",\"generator\":\""<<argv[4]<<"\",\"seed\":"<<seed<<",\"regions_generated\":"<<regions<<",\"sse_improved_regions\":"<<improved<<",\"uniform_batch_sse\":"<<uniform_sse<<",\"selected_batch_sse\":"<<selected_sse<<",\"csv_algorithm\":false,\"uniform_random_subset\":false,\"per_point_refits\":0,\"coordinate_method\":\""<<(random?"randomized_gap_allocation_and_stratified_integer_jitter":sse?"OLS_rank_inverse_with_gap_feasibility_and_refit_acceptance":"integer_gap_waterfill")<<"\"}\n";
  if(!report)throw std::runtime_error("report write");return 0;
}catch(const std::exception&e){std::cerr<<"[PROPOSAL ERROR] "<<e.what()<<'\n';return 2;}}
