#pragma once
#include "profile_common.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <utility>
#include <vector>

// Included after the experiment's pinned Native/Key/Record declarations.
// All statistics below come from stored nodes/records, never index lookups.
namespace structural_detail_alex_lipp {
struct Accumulator {
    const std::vector<Key>& real;
    StructuralProfile result;
    bool retain;
    std::uint64_t originals = 0, auxiliaries = 0, nodes = 0;
    std::uint64_t metadata_bytes = 0, data_bytes = 0, slots = 0;
    std::uint64_t maximum_depth = 0, maximum_structural_depth = 0;
    long double depth_sum = 0, log_error_sum = 0, error_sum = 0;
    long double original_capacity_sum = 0;
    double maximum_error = 0;
    struct Level {
        std::uint64_t metadata=0,data=0,nodes=0,stored_originals=0;
    };
    std::vector<Level> levels;

    Accumulator(const std::vector<Key>& original_keys, bool keep_per_key)
        : real(original_keys), retain(keep_per_key) {
        if (real.empty())
            throw std::runtime_error("Structural profile requires original keys");
        if (retain) result.per_key.assign(real.size(), {{0, 0, 0, 0}});
    }

    void node(std::size_t depth, std::size_t capacity,
              std::size_t metadata, std::size_t data) {
        if (!depth) throw std::runtime_error("Nonpositive structural depth");
        ++nodes;
        metadata_bytes += metadata;
        data_bytes += data;
        slots += capacity;
        if(levels.size()<depth)levels.resize(depth);
        levels[depth-1].metadata+=metadata;
        levels[depth-1].data+=data;
        ++levels[depth-1].nodes;
        maximum_structural_depth = std::max(
            maximum_structural_depth, static_cast<std::uint64_t>(depth));
    }

    void record(Key key, std::uint64_t payload, std::size_t depth,
                double absolute_error, std::size_t capacity) {
        if (payload == 0) { ++auxiliaries; return; }
        if (payload > real.size() || real[static_cast<std::size_t>(payload - 1)] != key)
            throw std::runtime_error("Structural original key/payload mismatch");
        if (!depth || !std::isfinite(absolute_error) || absolute_error < 0)
            throw std::runtime_error("Invalid structural record feature");
        const double log_error = std::log2(1.0 + absolute_error);
        const std::size_t rank = static_cast<std::size_t>(payload - 1);
        if (retain) {
            if (result.per_key[rank][0] != 0)
                throw std::runtime_error("Duplicate original structural payload");
            result.per_key[rank] = {{static_cast<double>(depth), log_error, 0, 0}};
        }
        ++originals;
        ++levels[depth-1].stored_originals;
        depth_sum += depth;
        log_error_sum += log_error;
        error_sum += absolute_error;
        original_capacity_sum += capacity;
        maximum_depth = std::max(maximum_depth, static_cast<std::uint64_t>(depth));
        maximum_error = std::max(maximum_error, absolute_error);
    }

    StructuralProfile finish() {
        if (originals != real.size())
            throw std::runtime_error("Structural profile does not cover all originals");
        const long double denominator = static_cast<long double>(originals);
        auto& f = result.f;
        f["original_count"] = static_cast<double>(originals);
        f["aux_count"] = static_cast<double>(auxiliaries);
        f["physical_count"] = static_cast<double>(originals + auxiliaries);
        f["mean_depth"] = static_cast<double>(depth_sum / denominator);
        f["mean_model_evals"] = f["mean_depth"];
        f["mean_final_comparisons"] = 1.0;
        // max_depth is over stored original records; the second maximum is
        // over every native node, including nodes with auxiliary records only.
        f["max_depth"] = static_cast<double>(maximum_depth);
        f["max_structural_depth"] = static_cast<double>(maximum_structural_depth);
        f["mean_log_error"] = static_cast<double>(log_error_sum / denominator);
        f["mean_absolute_error"] = static_cast<double>(error_sum / denominator);
        f["max_absolute_error"] = maximum_error;
        f["metadata_bytes"] = static_cast<double>(metadata_bytes);
        f["data_bytes"] = static_cast<double>(data_bytes);
        f["structural_bytes"] = static_cast<double>(metadata_bytes + data_bytes);
        f["node_count"] = static_cast<double>(nodes);
        f["slot_count"] = static_cast<double>(slots);
        f["mean_node_capacity"] = nodes ? static_cast<double>(slots) / nodes : 0;
        f["original_weighted_storage_capacity"] =
            static_cast<double>(original_capacity_sum / denominator);
        f["physical_slot_occupancy"] = slots ?
            static_cast<double>(originals + auxiliaries) / slots : 0;
        std::uint64_t visiting=0;
        for(size_t at=levels.size();at>0;--at) {
            const auto& level=levels[at-1];
            visiting+=level.stored_originals;
            const std::string prefix="level_"+std::to_string(at-1);
            f[prefix+"_bytes"]=double(level.metadata+level.data);
            f[prefix+"_metadata_bytes"]=double(level.metadata);
            f[prefix+"_data_bytes"]=double(level.data);
            f[prefix+"_node_count"]=double(level.nodes);
            f[prefix+"_stored_originals"]=double(level.stored_originals);
            f[prefix+"_visited_originals"]=double(visiting);
            f[prefix+"_visited_mass"]=double(visiting)/double(originals);
        }
        return std::move(result);
    }
};
}  // namespace structural_detail_alex_lipp

#if defined(OP_ALEX) || defined(OP_LIPP)
inline StructuralProfile extract_alex_lipp(const Native& native,
                                          const std::vector<Key>& real,
                                          bool retain_per_key) {
    structural_detail_alex_lipp::Accumulator a(real, retain_per_key);
#if defined(OP_ALEX)
    using Index = Native::Index;
    using DataNode = typename Index::data_node_type;
    const auto& index = native.index;
    if (!index.root_node_)
        throw std::runtime_error("Missing ALEX structural root");
    const int root_level = index.root_node_->level_;
    std::uint64_t leaf_count = 0, original_leaf_count = 0;
    std::uint64_t leaf_capacity = 0;
    for (typename Index::NodeIterator it(&index); !it.is_end(); it.next()) {
        const auto* node = it.current();
        const int signed_depth = int(node->level_) - root_level + 1;
        if (signed_depth < 1)
            throw std::runtime_error("Invalid ALEX structural node level");
        const std::size_t depth = static_cast<std::size_t>(signed_depth);
        if (!node->is_leaf_) {
            a.node(depth, 0, static_cast<std::size_t>(node->node_size()), 0);
            continue;
        }
        const auto* leaf = static_cast<const DataNode*>(node);
        const std::size_t capacity = static_cast<std::size_t>(leaf->data_capacity_);
        a.node(depth, capacity, static_cast<std::size_t>(leaf->node_size()),
               static_cast<std::size_t>(leaf->data_size()));
        ++leaf_count;
        leaf_capacity += capacity;
        bool stores_original = false;
        for (int slot = 0; slot < leaf->data_capacity_; ++slot) {
            if (!leaf->check_exists(slot)) continue;
            const auto payload = static_cast<std::uint64_t>(leaf->get_payload(slot));
            if (!payload) { ++a.auxiliaries; continue; }
            const Key key = leaf->get_key(slot);
            const int prediction = leaf->predict_position(key);
            const double error = std::abs(static_cast<double>(slot) - prediction);
            a.record(key, payload, depth, error, capacity);
            stores_original = true;
        }
        if (stores_original) ++original_leaf_count;
    }
    a.result.f["leaf_count"] = static_cast<double>(leaf_count);
    a.result.f["original_leaf_count"] = static_cast<double>(original_leaf_count);
    a.result.f["mean_leaf_capacity"] = leaf_count ?
        static_cast<double>(leaf_capacity) / leaf_count : 0;
    return a.finish();
#elif defined(OP_LIPP)
    std::uint64_t node_originals=0;
    std::size_t node_depth=0,node_capacity=0;
    const auto flush_node = [&]() {
        a.depth_sum += node_originals * node_depth;
        a.original_capacity_sum += node_originals * node_capacity;
        if (node_originals)
            a.maximum_depth=std::max(a.maximum_depth,static_cast<std::uint64_t>(node_depth));
        node_originals=0;
    };
    native.index.structural_cost_visit(
        [&](std::size_t depth, std::size_t capacity,
            std::size_t metadata, std::size_t data) {
            flush_node();
            node_depth=depth;node_capacity=capacity;
            a.node(depth, capacity, metadata, data);
        },
        [&](Key key, std::uint64_t payload,
            std::size_t depth, std::size_t capacity) {
            (void)capacity;
            if (!payload) {++a.auxiliaries;return;}
            if (payload>real.size()||real[static_cast<std::size_t>(payload-1)]!=key)
                throw std::runtime_error("LIPP structural original key/payload mismatch");
            if (retain_per_key) {
                auto& row=a.result.per_key[static_cast<std::size_t>(payload-1)];
                if (row[0]!=0)throw std::runtime_error("Duplicate LIPP structural payload");
                row={{static_cast<double>(depth),0,0,0}};
            }
            ++a.originals;++node_originals;
            ++a.levels[depth-1].stored_originals;
        });
    flush_node();
    return a.finish();
#endif
}
#endif
