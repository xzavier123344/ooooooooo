#pragma once
#include "profile_common.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

// Include after the unchanged native wrapper has defined Native, Key, and
// Record. The isolated PGM header must contain pgm_accessors.inc. No native
// lookup or search routine is called by this extractor.
namespace structural_pgm_detail {
struct Segment {
    Key key;
    double slope;
    uint64_t intercept;
};

// Reproduce the pinned uint64-key model arithmetic, not an ideal real-valued
// line. A float slope was converted losslessly to double by the accessor.
inline size_t prediction(const Segment& segment, Key key) {
    if (key < segment.key)
        throw std::runtime_error("PGM structural prediction precedes segment");
    const double scaled = segment.slope * double(key - segment.key);
    if (!std::isfinite(scaled) || scaled < 0 ||
        static_cast<long double>(scaled) >
            static_cast<long double>(std::numeric_limits<size_t>::max()) -
                segment.intercept)
        throw std::runtime_error("Invalid PGM structural model prediction");
    return static_cast<size_t>(scaled) + static_cast<size_t>(segment.intercept);
}

// std::lower_bound over random-access records compares the midpoint key to
// the query. For a known distinct-key physical rank, midpoint < rank is the
// same comparison outcome. This calculation reads no query-path data keys.
inline size_t lower_bound_comparisons(size_t first, size_t last, size_t rank) {
    if (rank < first || rank >= last)
        throw std::runtime_error("PGM structural window misses original key");
    size_t count = last - first, comparisons = 0;
    while (count != 0) {
        const size_t half = count / 2;
        const size_t midpoint = first + half;
        ++comparisons;
        if (midpoint < rank) {
            first = midpoint + 1;
            count -= half + 1;
        } else {
            count = half;
        }
    }
    if (first != rank)
        throw std::runtime_error("PGM structural lower_bound rank mismatch");
    return comparisons;
}
} // namespace structural_pgm_detail

inline StructuralProfile extract_pgm(const Native& native,
                                     const std::vector<Key>& real,
                                     bool retain_per_key) {
    using structural_pgm_detail::Segment;
    StructuralProfile profile;
    const size_t original_count = real.size();
    const size_t physical_count = native.data.size();
    const size_t height = native.index.gafis_structural_level_count();
    const size_t epsilon = Native::Index::epsilon_value;
    const size_t recursive_epsilon =
        Native::Index::gafis_structural_recursive_epsilon();
    const size_t segment_bytes = Native::Index::gafis_structural_segment_bytes();
    if (original_count == 0 || physical_count < original_count || height == 0)
        throw std::runtime_error("PGM structural extraction needs nonempty data");
    // This implementation audits the pinned recursive-linear PGM variant.
    // Failing explicitly is preferable to inventing comparisons for a
    // different internal search branch.
    if (height > 1 && (recursive_epsilon == 0 ||
        recursive_epsilon > 8 * 64 / segment_bytes))
        throw std::runtime_error("PGM structural extractor requires linear routing");

    std::vector<std::vector<Segment>> levels(height);
    native.index.gafis_structural_visit_segments(
        [&](size_t level, size_t local_index, Key key, double slope,
            uint64_t intercept) {
            if (level >= height || local_index != levels[level].size())
                throw std::runtime_error("Invalid PGM structural segment layout");
            if (!levels[level].empty() && key < levels[level].back().key)
                throw std::runtime_error("Unordered PGM structural segment starts");
            levels[level].push_back({key, slope, intercept});
        });
    for (const auto& level : levels)
        if (level.size() < 2)
            throw std::runtime_error("PGM structural level lacks successor sentinel");
    if (retain_per_key) profile.per_key.resize(original_count);

    // Monotone cursors assign sorted original keys directly from segment
    // starts at every level. They do not follow prediction/search paths.
    std::vector<size_t> assigned(height, 0);
    const size_t largest_window=std::min(physical_count,2*epsilon+2);
    std::vector<std::vector<unsigned char>> comparison_table(largest_window+1);
    for(size_t width=1;width<=largest_window;++width) {
        comparison_table[width].resize(width);
        for(size_t offset=0;offset<width;++offset)
            comparison_table[width][offset]=static_cast<unsigned char>(
                structural_pgm_detail::lower_bound_comparisons(0,width,offset));
    }
    long double route_sum = 0, correction_sum = 0, window_sum = 0;
    std::vector<long double> route_level_sum(height,0);
    long double absolute_error_sum = 0, log_error_sum = 0;
    size_t window_min = std::numeric_limits<size_t>::max(), window_max = 0;
    size_t seen = 0;
    for (size_t physical_rank = 0; physical_rank < physical_count; ++physical_rank) {
        const auto& record = native.data[physical_rank];
        if (physical_rank && native.data[physical_rank - 1].first >= record.first)
            throw std::runtime_error("PGM structural records are not distinct sorted keys");
        if (record.second == 0) continue;
        if (seen >= original_count || record.second != seen + 1 ||
            record.first != real[seen])
            throw std::runtime_error("PGM structural original payload mismatch");
        const Key key = record.first;
        for (size_t level = 0; level < height; ++level) {
            const auto& segments = levels[level];
            size_t& at = assigned[level];
            while (at + 1 < segments.size() && segments[at + 1].key <= key)
                ++at;
            if (segments[at].key > key || at + 1 >= segments.size())
                throw std::runtime_error("PGM structural original lacks segment successor");
        }
        // The native recursive routine begins at the first top-level model.
        if (assigned[height - 1] != 0)
            throw std::runtime_error("PGM structural root assignment is not native root");

        size_t route_comparisons = 0;
        for (size_t upper = height - 1; upper > 0; --upper) {
            const size_t parent = assigned[upper];
            const auto& parent_segments = levels[upper];
            const size_t predicted = std::min<size_t>(
                structural_pgm_detail::prediction(parent_segments[parent], key),
                parent_segments[parent + 1].intercept);
            const size_t offset = recursive_epsilon + 1;
            const size_t lo = predicted <= offset ? 0 : predicted - offset;
            const size_t target = assigned[upper - 1];
            if (lo > target)
                throw std::runtime_error("PGM structural linear routing starts after target");
            // One comparison for each advance plus the terminating false
            // comparison against the next segment's start key.
            const size_t local_comparisons=target-lo+1;
            route_comparisons += local_comparisons;
            route_level_sum[upper]+=local_comparisons;
        }
        const size_t bottom = assigned[0];
        const auto& bottom_segments = levels[0];
        const size_t predicted = std::min<size_t>(
            structural_pgm_detail::prediction(bottom_segments[bottom], key),
            bottom_segments[bottom + 1].intercept);
        const size_t lo = predicted <= epsilon ? 0 : predicted - epsilon;
        if (predicted > std::numeric_limits<size_t>::max() - epsilon - 2)
            throw std::runtime_error("PGM structural window arithmetic overflow");
        const size_t hi = std::min(physical_count, predicted + epsilon + 2);
        const size_t window = hi - lo;
        if(physical_rank<lo||physical_rank>=hi||window>largest_window)
            throw std::runtime_error("PGM structural window misses original key");
        const size_t correction_comparisons=comparison_table[window][physical_rank-lo];
        const size_t absolute_error = predicted >= physical_rank
            ? predicted - physical_rank : physical_rank - predicted;
        route_sum += route_comparisons;
        correction_sum += correction_comparisons;
        window_sum += window;
        absolute_error_sum += absolute_error;
        log_error_sum += std::log2(1.0 + double(absolute_error));
        window_min = std::min(window_min, window);
        window_max = std::max(window_max, window);
        if (retain_per_key)
            profile.per_key[seen] = {{double(height), double(route_comparisons),
                                      double(correction_comparisons), 0.0}};
        ++seen;
    }
    if (seen != original_count)
        throw std::runtime_error("PGM structural profile omitted original keys");

    auto& f = profile.f;
    const double count = double(original_count);
    f["original_count"] = count;
    f["aux_count"] = double(physical_count - original_count);
    f["physical_count"] = double(physical_count);
    f["height"] = double(height);
    f["mean_depth"] = double(height);
    f["max_depth"] = double(height);
    f["mean_model_evals"] = double(height);
    f["mean_route_comparisons"] = double(route_sum / original_count);
    f["mean_correction_comparisons"] = double(correction_sum / original_count);
    f["mean_final_comparisons"] = 1.0;
    f["mean_total_operations"] = double(height) +
        f["mean_route_comparisons"] + f["mean_correction_comparisons"] + 1.0;
    f["mean_window_size"] = double(window_sum / original_count);
    f["min_window_size"] = double(window_min);
    f["max_window_size"] = double(window_max);
    f["mean_abs_prediction_error"] = double(absolute_error_sum / original_count);
    f["mean_log2_one_plus_prediction_error"] = double(log_error_sum / original_count);
    f["epsilon"] = double(epsilon);
    f["epsilon_recursive"] = double(recursive_epsilon);
    f["metadata_bytes"] = double(native.index.size_in_bytes());
    f["data_bytes"] = double(native.data.capacity()) * sizeof(Record);
    f["node_count"] = double(native.index.op_model_segments());
    f["bottom_segments"] = double(native.index.segments_count());
    f["segment_bytes"] = double(segment_bytes);
    f["analytic_comparisons_available"] = 1.0;
    f["native_queries_executed_for_profile"] = 0.0;
    for (size_t level = 0; level < height; ++level) {
        const auto name = std::string("level_") + std::to_string(level);
        f[name + "_stored_segments"] = double(levels[level].size());
        f[name + "_bytes"] = double(levels[level].size()) * segment_bytes;
        f[name + "_metadata_bytes"] = f[name + "_bytes"];
        f[name + "_data_bytes"] = 0.0;
        f[name + "_visited_mass"] = 1.0;
        f[name + "_visited_originals"] = count;
        f[name + "_route_comparisons"] =
            double(route_level_sum[level]/original_count);
    }

    // Deliberately separate coarse, fixed-bound predictors from the analytic
    // profile above. The routing quantity assumes no signed prediction bias;
    // it is a proxy, not a measurement or an exact comparison count.
    const size_t fixed_window = std::min(physical_count, 2 * epsilon + 2);
    f["basic_model_evals"] = double(height);
    f["basic_route_comparisons_proxy"] =
        double(height - 1) * double(recursive_epsilon + 2);
    f["basic_correction_comparisons_upper"] =
        std::ceil(std::log2(double(fixed_window) + 1.0));
    f["basic_lookup_work_proxy"] = f["basic_model_evals"] +
        f["basic_route_comparisons_proxy"] +
        f["basic_correction_comparisons_upper"] + 1.0;
    return profile;
}
