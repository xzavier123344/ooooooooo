"""Two independent ratios; calibrated operations, real bytes, exact raw PLAFI."""
import math
import numpy as np

FEATURES=('root_steps','other_steps','leaf_models','exponential_comparisons',
          'binary_comparisons','route_comparisons','correction_comparisons','final_comparisons')


def query_cost(features,calibration):
    array=np.asarray(features,dtype=float)
    coeff=np.asarray([calibration['coefficients_ns'][x] for x in FEATURES],dtype=float)
    if array.ndim!=2 or array.shape[1]!=len(FEATURES):raise ValueError('Native feature schema mismatch')
    if np.any(array<0) or np.any(~np.isfinite(array)) or np.any(coeff<=0) or np.any(~np.isfinite(coeff)):
        raise ValueError('Invalid operation counts or calibration')
    return array@coeff


def terms(row,base,gamma1,gamma2):
    if min(gamma1,gamma2)<0 or not all(math.isfinite(x) for x in (gamma1,gamma2)):
        raise ValueError('Invalid cost ratios')
    a=math.log(row['estimated_cost_ns']/base['estimated_cost_ns'])
    b=math.log(row['total_bytes']/base['total_bytes'])
    c=math.log1p(row['plafi_raw_fixed'])-math.log1p(base['plafi_raw_fixed'])
    return dict(J=a+gamma1*b+gamma2*c,query_component=a,space_component=b,
                plafi_component=c,weighted_space=gamma1*b,weighted_plafi=gamma2*c,
                lambda1=1.,gamma1=gamma1,gamma2=gamma2,
                lambda2=gamma1,lambda3=gamma2)


def choose(rows,base,gamma1,gamma2):
    return min(rows,key=lambda r:(terms(r,base,gamma1,gamma2)['J'],r['total_bytes'],r['k'],r['state_id']))


def frontier(rows):
    """Empirical proxy frontier only; not measured throughput or global optimality."""
    return [r for r in rows if not any(
        s['estimated_cost_ns']<=r['estimated_cost_ns'] and s['total_bytes']<=r['total_bytes']
        and (s['estimated_cost_ns']<r['estimated_cost_ns'] or s['total_bytes']<r['total_bytes'])
        for s in rows)]
