"""Full count-header input canonicalization and stable identities."""
import hashlib
import json
import os
import shutil
from pathlib import Path
import numpy as np
_SOURCE_AUDITS={}


def ordered_source(path, cache_dir=None, strict=False):
    """Canonicalize the entire declared key collection, never a thinned sample.

    GRE's header is a record count, not a sortedness guarantee. Unsorted inputs
    are copied to a separate disk-backed array and sorted in place. Duplicate
    removal remains in source_sample, as it was for already ordered inputs.
    """
    path = Path(path).resolve()
    stat = path.stat()
    size = stat.st_size
    if size < 8 or (size - 8) % 8:
        raise ValueError('Invalid GRE uint64 length: ' + str(path))
    with path.open('rb') as f:
        header = int(np.fromfile(f, dtype='<u8', count=1)[0])
    available = (size - 8) // 8
    if not 0 < header <= available:
        raise ValueError('Bad/truncated count header: ' + str(path))
    stamp = dict(path=str(path), size=size, mtime_ns=stat.st_mtime_ns, header=header)
    cache_dir = Path(cache_dir or os.environ.get('PLAFI_SOURCE_CACHE', Path(__file__).parent / 'source_cache')).resolve()
    identity = json.dumps(stamp, sort_keys=True)
    audit_key = (identity, str(cache_dir), bool(strict))
    common = dict(header=header, available=available, ignored_tail=available - header, source_bytes=size, source_stamp=stamp)
    if audit_key in _SOURCE_AUDITS:
        (ordered, extra) = _SOURCE_AUDITS[audit_key]
        return (np.memmap(ordered, dtype='<u8', mode='r', offset=8, shape=(header,)), dict(common, **extra))
    data = np.memmap(path, dtype='<u8', mode='r', offset=8, shape=(header,))
    previous = None
    inversion = None
    for start in range(0, header, 1000000):
        block = data[start:start + 1000000]
        if previous is not None and block[0] < previous:
            inversion = start
            break
        bad = np.flatnonzero(block[1:] < block[:-1])
        if len(bad):
            inversion = start + int(bad[0]) + 1
            break
        previous = block[-1]
    if inversion is None:
        extra = dict(source_order='already_sorted', canonicalization='none')
        _SOURCE_AUDITS[audit_key] = (path, extra)
        return (data, dict(common, **extra))
    del data
    if strict:
        raise ValueError('Unsorted source: ' + str(path))
    cache_dir.mkdir(parents=True, exist_ok=True)
    tag = hashlib.sha256(identity.encode()).hexdigest()[:24]
    ordered = cache_dir / (tag + '.sorted.bin')
    meta = cache_dir / (tag + '.json')
    if ordered.exists() and meta.exists():
        record = json.loads(meta.read_text(encoding='utf-8'))
        if record['source_stamp'] != stamp or ordered.stat().st_size != 8 * (header + 1) or digest(ordered) != record['sorted_sha256']:
            raise ValueError('Sorted source cache failed integrity check: ' + str(ordered))
        print('[SOURCE CACHE HIT]', path.name, ordered, flush=True)
    else:
        required = 8 * (header + 1)
        if shutil.disk_usage(cache_dir).free < required + (64 << 20):
            raise ValueError(f'Insufficient disk for sorted source cache: need {required} bytes + 64 MiB')
        lock = cache_dir / (tag + '.lock')
        temporary = cache_dir / (tag + '.partial')
        try:
            descriptor = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise RuntimeError('Source sorting already active, or interrupted .lock needs checking: ' + str(lock))
        os.close(descriptor)
        print(f'[SOURCE SORT] {path.name}: first inversion={inversion}; sorting ALL {header} declared keys; source unchanged', flush=True)
        try:
            hasher = hashlib.sha256()
            with path.open('rb') as src, temporary.open('wb') as dst:
                remaining = required
                while remaining:
                    block = src.read(min(8 << 20, remaining))
                    if not block:
                        raise ValueError('Source truncated while copying')
                    dst.write(block)
                    hasher.update(block)
                    remaining -= len(block)
            array = np.memmap(temporary, dtype='<u8', mode='r+', offset=8, shape=(header,))
            array.sort(kind='quicksort')
            array.flush()
            del array
            final = path.stat()
            if (final.st_size, final.st_mtime_ns) != (size, stat.st_mtime_ns):
                raise ValueError('Source changed while sorting')
            record = dict(source_stamp=stamp, declared_source_sha256=hasher.hexdigest(), sorted_sha256=digest(temporary), first_inversion=inversion, canonicalization='full count-header key sort, no thinning')
            os.replace(temporary, ordered)
            write_json(meta, record)
        finally:
            lock.unlink()
        print('[SOURCE SORT READY]', ordered, flush=True)
    extra = dict(source_order='unsorted', canonicalization=record['canonicalization'], sorted_source=str(ordered), sorted_sha256=record['sorted_sha256'], declared_source_sha256=record['declared_source_sha256'])
    _SOURCE_AUDITS[audit_key] = (ordered, extra)
    return (np.memmap(ordered, dtype='<u8', mode='r', offset=8, shape=(header,)), dict(common, **extra))

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda : f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def stable_seed(*parts):
    return int.from_bytes(hashlib.sha256('|'.join(map(str, parts)).encode()).digest()[:8], 'little')

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')

def append(path, value):
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(value, allow_nan=False) + '\n')
        f.flush()

def read_lines(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
