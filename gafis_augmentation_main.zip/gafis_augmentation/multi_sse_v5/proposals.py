"""Exact integer merge validation for compact timing plans."""
import numpy as np
MAX_KEY=(1<<64)-1


def keys(values):
    if isinstance(values, np.ndarray) and values.dtype == np.dtype('uint64'):
        out = values
    else:
        seq = []
        for value in values:
            if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
                raise ValueError('keys must be exact UInt64 integers')
            value = int(value)
            if not 0 <= value < MAX_KEY:
                raise ValueError('reserved UINT64_MAX or out-of-range key')
            seq.append(value)
        out = np.asarray(seq, dtype=np.uint64)
    if out.ndim != 1 or len(out) < 3 or out[-1] == MAX_KEY or np.any(out[1:] <= out[:-1]):
        raise ValueError('at least three sorted unique supported keys required')
    return out

def merge(original, additions):
    original = keys(original)
    additions = list(additions)
    if not additions:
        return original.copy()
    for value in additions:
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
            raise ValueError('shadow coordinates must be exact integers')
    additions = sorted((int(x) for x in additions))
    if additions[0] <= int(original[0]) or additions[-1] >= int(original[-1]):
        raise ValueError('shadow points must stay inside the original domain')
    if len(set(additions)) != len(additions):
        raise ValueError('duplicate shadow points')
    added = np.asarray(additions, dtype=np.uint64)
    positions = np.searchsorted(original, added)
    if np.any(original[positions] == added):
        raise ValueError('shadow duplicates an original key')
    destinations = positions + np.arange(len(added), dtype=positions.dtype)
    result = np.empty(len(original) + len(added), dtype=np.uint64)
    original_slots = np.ones(len(result), dtype=bool)
    original_slots[destinations] = False
    result[destinations] = added
    result[original_slots] = original
    return result
