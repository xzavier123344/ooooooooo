// Full original-data Google B-tree; bounded-time sampled-query measurement.
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include "fast_protocol.hpp"
#include "google_btree/btree_map.h"

using Key=uint64_t;
static std::vector<Key> load(const std::string& path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    if(!f) throw std::runtime_error("Cannot open raw UInt64 file: "+path);
    const auto length=f.tellg();
    if(length<=0 || length%8) throw std::runtime_error("Invalid raw UInt64 file length");
    std::vector<Key> values(size_t(length)/8);
    f.seekg(0);f.read(reinterpret_cast<char*>(values.data()),length);
    if(!f) throw std::runtime_error("Raw UInt64 read failed");
    return values;
}
int main(int argc,char** argv) {
    try {
        if(argc%2!=1) throw std::runtime_error("Expected --option value pairs");
        std::map<std::string,std::string> args;
        for(int i=1;i<argc;i+=2) {
            if(!args.emplace(argv[i],argv[i+1]).second) throw std::runtime_error("Duplicate argument");
            if(args.at(argv[i]).empty() || (std::string(argv[i])!="--real" && std::string(argv[i])!="--queries"))
                throw std::runtime_error("Invalid argument");
        }
        std::cerr<<"[FAST REFERENCE] load_start\n";
        auto real=load(args.at("--real")),queries=load(args.at("--queries"));
        if(!std::is_sorted(real.begin(),real.end()) ||
            std::adjacent_find(real.begin(),real.end())!=real.end() || real.back()==UINT64_MAX)
            throw std::runtime_error("Original keys must be sorted unique without UINT64_MAX");
        const auto real_count=real.size();
        std::cerr<<"[FAST REFERENCE] build_start originals="<<real_count<<"\n";
        btree::btree_map<Key,uint64_t> index;
        for(size_t i=0;i<real.size();++i) index.insert({real[i],uint64_t(i)+1});
        std::cerr<<"[FAST REFERENCE] build_complete sampled_validation_start\n";
        const size_t checks=std::min<size_t>(65536,real.size());
        for(size_t i=0;i<checks;++i) {
            const size_t pos=checks>1 ? uint64_t(i)*(real.size()-1)/(checks-1):0;
            const auto found=index.find(real[pos]);
            if(found==index.end() || found->second!=uint64_t(pos)+1)
                throw std::runtime_error("Reference sampled physical validation failed");
        }
        std::vector<uint64_t> expected;expected.reserve(queries.size());
        for(auto query:queries) {
            const auto position=std::lower_bound(real.begin(),real.end(),query);
            const auto found=index.find(query);
            if(position==real.end() || *position!=query || found==index.end() ||
                found->second!=uint64_t(position-real.begin())+1)
                throw std::runtime_error("Reference original query/payload validation failed");
            expected.push_back(found->second);
        }
        auto prefix=fast_timing::prefix_sums(expected);
        std::vector<Key>().swap(real);std::vector<uint64_t>().swap(expected);
        const auto population_checksum=prefix.back();
        fast_timing::Sample sample;uint64_t offset=0,warmup_operations=0;
        auto emit=[&](const char* label) {
            std::cout<<std::setprecision(17)<<label<<" {\"success\":true,\"index\":\"google_btree\",\"version\":\"1.0.1\","
                <<"\"timing_protocol\":\"bounded_offset_v1\",\"real_count\":"<<real_count
                <<",\"physical_count\":"<<real_count<<",\"query_count\":"<<queries.size()
                <<",\"physical_samples_correct\":true,\"sampled_physical_count\":"<<checks
                <<",\"queries_correct\":true,\"all_shadow_correct\":true,\"all_real_correct\":"<<(checks==real_count?"true":"false")
                <<",\"physical_validation_complete\":"<<(checks==real_count?"true":"false")
                <<",\"correctness_scope\":\"sampled_physical_and_all_query_corpus\",\"has_structural_cost\":false,"
                <<"\"query_checksum\":\""<<population_checksum<<"\",\"complete_passes_required\":false,"
                <<"\"start_offset\":"<<offset<<",\"warmup_operations\":"<<warmup_operations
                <<",\"throughput\":"<<(sample.seconds>0?double(sample.operations)/sample.seconds:0)
                <<",\"operations\":"<<sample.operations<<",\"elapsed_seconds\":"<<sample.seconds
                <<",\"checksum\":\""<<sample.checksum<<"\"}"<<std::endl;
        };
        emit("READY_JSON");
        std::string line;
        while(std::getline(std::cin,line)) {
            if(line=="quit") break;
            std::istringstream command(line);double seconds=0,warmup=0;std::string extra;
            if(!(command>>seconds>>warmup>>offset) || command>>extra || seconds<=0 || warmup<0 || offset>=queries.size())
                throw std::runtime_error("Expected seconds warmup start_offset");
            auto lookup=[&](Key key){return index.find(key)->second;};
            warmup_operations=fast_timing::run(queries,warmup,offset,lookup).operations;
            sample=fast_timing::run(queries,seconds,offset,lookup);
            if(sample.checksum!=fast_timing::expected_checksum(prefix,sample.operations,offset))
                throw std::runtime_error("Reference timed query checksum mismatch");
            emit("RESULT_JSON");
        }
        return 0;
    } catch(const std::exception& error) {
        std::cerr<<"FAILED: "<<error.what()<<'\n';return 8;
    }
}
