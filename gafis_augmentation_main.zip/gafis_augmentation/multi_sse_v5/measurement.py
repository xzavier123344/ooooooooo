"""Resident worker protocol and paired throughput summaries."""
from collections import defaultdict
import json
import math
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import time
import numpy as np


class Worker:

    def __init__(self, command, cpu=None, timeout=180):
        self.timeout = timeout
        if cpu is not None and sys.platform.startswith('linux'):
            command = ['taskset', '-c', str(cpu)] + command
        self.stderr = tempfile.TemporaryFile(mode='w+b')
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr, text=True, bufsize=1)
        self.queue = queue.Queue()
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()
        try:
            self.ready = self.receive('READY_JSON')
            if self.ready.get('success') is not True:
                raise RuntimeError('Native startup failed')
        except BaseException:
            self.close()
            raise

    def _read(self):
        try:
            for line in self.process.stdout:
                self.queue.put(line.rstrip())
        finally:
            self.queue.put(None)

    def receive(self, prefix):
        until = time.monotonic() + self.timeout
        while True:
            left = until - time.monotonic()
            if left <= 0:
                raise TimeoutError('Resident worker timeout waiting for ' + prefix)
            try:
                line = self.queue.get(timeout=left)
            except queue.Empty as error:
                raise TimeoutError('Resident worker timeout') from error
            if line is None:
                self.stderr.seek(0)
                raise RuntimeError('Resident exited: ' + self.stderr.read().decode(errors='replace')[-4000:])
            if line.startswith(prefix + ' '):
                value = json.loads(line[len(prefix) + 1:])
                if value.get('success') is not True:
                    raise RuntimeError('Failed resident sample')
                return value

    def sample(self, seconds, warmup):
        self.process.stdin.write(f'{seconds} {warmup}\n')
        self.process.stdin.flush()
        value = self.receive('RESULT_JSON')
        if not math.isfinite(float(value['throughput'])) or value['throughput'] <= 0:
            raise ValueError('Nonpositive or invalid throughput')
        if str(value.get('query_checksum')) != str(self.ready['query_checksum']):
            raise ValueError('Timing query checksum changed')
        if self.ready.get('complete_passes_required'):
            size = int(self.ready['query_count'])
            operations = int(value.get('operations', 0))
            if not size or operations < size or operations % size:
                raise ValueError('Full-population timing did not complete the original query corpus')
        return value

    def close(self):
        if self.process.poll() is None:
            try:
                self.process.stdin.write('quit\n')
                self.process.stdin.flush()
                self.process.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                self.process.kill()
                self.process.wait()
        for stream in (self.process.stdin, self.process.stdout):
            try:
                stream.close()
            except OSError:
                pass
        self.reader.join(timeout=1)
        self.stderr.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

def normalized_pair(native, refs, order):
    positions = {role: i for (i, role) in enumerate(order)}
    normalized = {role: native[role]['throughput'] / math.sqrt(refs[pos]['throughput'] * refs[pos + 1]['throughput']) for (role, pos) in positions.items()}
    return (normalized, normalized['candidate'] / normalized['original'])

def log_summary(values):
    values = np.asarray(values, dtype=float)
    if not len(values):
        return dict(n=0, geometric_mean=None, ci95_low=None, ci95_high=None)
    if np.any(~np.isfinite(values)) or np.any(values <= 0):
        raise ValueError('Positive finite ratios required')
    z = np.log(values)
    if len(values) < 3:
        return dict(n=len(z), geometric_mean=float(np.exp(z.mean())), ci95_low=None, ci95_high=None)
    rng = np.random.default_rng(1729)
    draws = rng.choice(z, size=(5000, len(z)), replace=True).mean(axis=1)
    return dict(n=len(z), geometric_mean=float(np.exp(z.mean())), ci95_low=float(np.exp(np.quantile(draws, 0.025))), ci95_high=float(np.exp(np.quantile(draws, 0.975))))

def resolve_cpu(value):
    if value in ('none', '', None):
        return None
    allowed = os.sched_getaffinity(0) if hasattr(os, 'sched_getaffinity') else None
    cpu = min(allowed) if value == 'auto' and allowed else None if value == 'auto' else int(value)
    if allowed is not None and cpu not in allowed:
        raise ValueError('CPU is outside the permitted affinity set')
    return cpu

def report(a):
    """Summarize every frozen endpoint without selecting by test throughput."""
    from multi_sse_v5 import driver as d
    manifest=d.read(a.out/'frozen_manifest.json')
    records=d.lines(a.out/'timing_raw.jsonl')
    grouped=defaultdict(list); originals_grouped=defaultdict(list)
    for record in records:
        if record.get('status')=='ok':
            target=originals_grouped if record.get('kind')=='original_baseline' else grouped
            target[(record['case_id'],record['physical_sha256'])].append(record)
    originals={v['case_id']:v for v in manifest['variants'] if v['method']=='original'}
    rows=[]
    for variant in manifest['variants']:
        key=(variant['case_id'],variant['physical_sha256'])
        alias=variant['physical_sha256']==originals[variant['case_id']]['physical_sha256']
        samples=originals_grouped[key] if alias else grouped[key]
        row=dict(variant)
        row.update(successful_repeats=len(samples),reuse_original=alias,
                   timing_physical_unit_id=':'.join(key),all_repeats_retained=True,
                   B_reference='Google cpp-btree 1.0.1',throughput_used_for_selection=False)
        if alias:
            row.update(paired_original_gain_ratio=1.0,alias_not_independent_speedup=True,
                raw_throughput_geomean=log_summary([s['raw_original_throughput'] for s in samples])['geometric_mean'],
                B_normalized_speedup=log_summary([s['B_normalized_speedup'] for s in samples])['geometric_mean'])
        else:
            stats=log_summary([s['paired_original_gain_ratio'] for s in samples])
            row.update(paired_original_gain_ratio=stats['geometric_mean'],
                paired_ci95_low=stats['ci95_low'],paired_ci95_high=stats['ci95_high'],
                raw_throughput_geomean=log_summary([s['raw_throughput'] for s in samples])['geometric_mean'],
                B_normalized_speedup=log_summary([s['B_normalized_speedup'] for s in samples])['geometric_mean'],
                raw_original_gain_ratio=log_summary([s['raw_original_gain_ratio'] for s in samples])['geometric_mean'],
                max_reference_drift=max((s['reference_drift'] for s in samples),default=None))
        rows.append(row)
    d.csvwrite(a.out/'timing_summary.csv',rows)
    d.write(a.out/'timing_summary.json',dict(successful_samples=sum(map(len,grouped.values())),
        original_baseline_samples=sum(map(len,originals_grouped.values())),
        failures=sum(r.get('status')=='failed' for r in records),
        throughput_used_in_selection=False,drift_filtered=False,
        confidence_interval='paired-repeat bootstrap on mean log ratios; exploratory under temporal dependence'))
    return rows
