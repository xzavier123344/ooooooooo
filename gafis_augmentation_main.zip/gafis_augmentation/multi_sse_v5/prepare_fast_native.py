"""Generate a timing-only backend without modifying the pinned native source."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def once(text,old,new):
    if text.count(old)!=1:
        raise ValueError('Unsupported native timing source anchor: '+old[:100])
    return text.replace(old,new,1)


def render(text):
    text='#include "fast_protocol.hpp"\n'+text
    start=text.index('        PhaseProgress validation_progress("validate_physical_payloads"')
    end=text.index('        double cost=0,',start)
    text=text[:start]+'''        phase("sampled_physical_validation_start",values.size());
        bool all_shadows_validated=false;
        const auto sampled_physical_count=fast_timing::validate_physical_sample(values,
            [&](Key key,bool& found){return index->lookup(key,found);},all_shadows_validated);
        const bool full_physical_validation=values.size()<=65536;
        phase("query_corpus_validation_start",queries.size());
        for(size_t i=0;i<queries.size();++i) {
            bool found=false;auto value=index->lookup(queries[i],found);
            if(!found || value!=expected[i]) throw std::runtime_error("Query corpus payload validation failed");
        }
        phase("query_corpus_validation_complete",queries.size());
''' +text[end:]
    start=text.index('        auto measure=[&](double seconds,double warmup) {')
    end=text.index('        uint64_t population_checksum=0;',start)
    text=text[:start]+'''        const auto timing_query_prefix=fast_timing::prefix_sums(expected);
        uint64_t start_offset=0,warmup_operations=0;
        auto measure=[&](double seconds,double warmup) {
            if(!std::isfinite(seconds)||seconds<=0||!std::isfinite(warmup)||warmup<0)
                throw std::runtime_error("Invalid sample duration");
            auto lookup=[&](Key key){bool found=false;return index->lookup(key,found);};
            warmup_operations=fast_timing::run(queries,warmup,start_offset,lookup).operations;
            auto sample=fast_timing::run(queries,seconds,start_offset,lookup);
            if(sample.checksum!=fast_timing::expected_checksum(timing_query_prefix,sample.operations,start_offset))
                throw std::runtime_error("Timed query payload checksum mismatch");
            operations=sample.operations;checksum=sample.checksum;elapsed_seconds=sample.seconds;
            throughput=double(operations)/elapsed_seconds;
        };
''' +text[end:]
    text=once(text,'        const bool complete_passes=get(args,"--complete-passes","0")=="1";',
        '        const bool complete_passes=false; // New bounded-time protocol never forces a corpus pass.')
    text=once(text,r'<<",\"n0\":"<<original_count<<",\"queries_correct\":true,\"all_real_correct\":true,\"all_shadow_correct\":true"',
        r'''<<",\"n0\":"<<original_count<<",\"queries_correct\":true,\"all_real_correct\":"<<(full_physical_validation?"true":"false")
                 <<",\"all_shadow_correct\":"<<(all_shadows_validated?"true":"false")
                 <<",\"physical_samples_correct\":true,\"sampled_physical_count\":"<<sampled_physical_count
                 <<",\"physical_validation_complete\":"<<(full_physical_validation?"true":"false")
                 <<",\"correctness_scope\":\"sampled_physical_and_all_query_corpus\",\"timing_protocol\":\"bounded_offset_v1\""
                 <<",\"start_offset\":"<<start_offset<<",\"warmup_operations\":"<<warmup_operations''')
    text=once(text,r'<<",\"capacity_only_control_supported\":false,\"physical_correctness\":true"',
        r'<<",\"capacity_only_control_supported\":false,\"physical_correctness\":"<<(full_physical_validation?"true":"false")')
    text=once(text,'if(!(command>>seconds>>warmup) || command>>extra)',
                   'if(!(command>>seconds>>warmup>>start_offset) || command>>extra || start_offset>=queries.size())')
    text=once(text,"Resident command must be '<seconds> <warmup>' or quit",
                   "Resident command must be '<seconds> <warmup> <start_offset>' or quit")
    # Do not call reported_bytes()/nodes()/root metadata on every sample:
    # some native implementations traverse the ENTIRE index in these methods.
    start=text.index('        auto emit=[&](const char* prefix) {')
    end=text.index('        if(mode=="inspect") emit("RESULT_JSON");',start)
    text=text[:start]+r'''        auto emit=[&](const char* label) {
            std::cout<<std::setprecision(17)<<label<<" {\"success\":true,\"index\":\""<<Native::name
                <<"\",\"timing_protocol\":\"bounded_offset_v1\",\"real_count\":"<<original_count
                <<",\"physical_count\":"<<physical_count<<",\"shadow_count\":"<<physical_count-original_count
                <<",\"query_count\":"<<queries.size()<<",\"query_checksum\":\""<<population_checksum<<"\""
                <<",\"physical_samples_correct\":true,\"queries_correct\":true,\"sampled_physical_count\":"<<sampled_physical_count
                <<",\"physical_validation_complete\":"<<(full_physical_validation?"true":"false")
                <<",\"all_real_correct\":"<<(full_physical_validation?"true":"false")
                <<",\"all_shadow_correct\":"<<(all_shadows_validated?"true":"false")
                <<",\"correctness_scope\":\"sampled_physical_and_all_query_corpus\",\"has_structural_cost\":false,\"complete_passes_required\":false"
                <<",\"start_offset\":"<<start_offset<<",\"warmup_operations\":"<<warmup_operations
                <<",\"operations\":"<<operations<<",\"elapsed_seconds\":"<<elapsed_seconds
                <<",\"throughput\":"<<throughput<<",\"checksum\":\""<<checksum<<"\"} "<<std::endl;
        };
''' +text[end:]
    return text


def prepare():
    original=HERE/'native.cpp';before=hashlib.sha256(original.read_bytes()).hexdigest()
    generated=HERE/'bin'/'fast_generated';generated.mkdir(parents=True,exist_ok=True)
    target=generated/'fast_native.cpp'
    with target.open('w',encoding='utf-8',newline='\n') as stream:
        stream.write(render(original.read_text(encoding='utf-8')))
    if hashlib.sha256(original.read_bytes()).hexdigest()!=before:
        raise RuntimeError('Pinned native source changed while generating timing backend')
    info=dict(native_source_sha256=before,generated_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
              original_native_source_modified=False,index_class_and_build_unchanged=True,
              physical_validation='<=65536 deterministic physical positions plus all shadows if <=65536',
              query_validation='all keys in the fixed sampled original-query corpus',
              per_sample_index_wide_metadata_traversal=False,
              timing_protocol='bounded_offset_v1',query_batch=1024)
    (generated/'generation_manifest.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    print('[FAST NATIVE GENERATED]',target,'original_source_unchanged=True')
    return target


if __name__=='__main__':
    prepare()
