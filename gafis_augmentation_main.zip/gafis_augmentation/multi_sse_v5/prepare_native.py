"""Prepare pinned native headers with read-only root and subtree-path accessors."""
import hashlib
import json
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent


def replace_once(text, before, after, count=1):
    if text.count(before) != count:
        raise ValueError("Unsupported native marker: " + before)
    return text.replace(before, after)


def prepare_extra_indices(manifest):
    """Copy pinned ALEX / static PGM sources; passive hooks and region access only."""
    sources = {"alex": HERE.parent / "vendor/alex",
               "pgm": HERE.parent.parent / "src/competitor/pgm/src/include/pgm"}
    for name, original in sources.items():
        snapshot = HERE / "dependency_sources" / name
        source = snapshot if snapshot.is_dir() else original
        if not source.is_dir():
            raise FileNotFoundError("Pinned native source missing: " + str(source))
        destination = HERE / "vendor" / name
        shutil.copytree(source, destination, dirs_exist_ok=True)
        manifest["sources"][name] = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                      for p in sorted(source.rglob("*")) if p.is_file()}
    path = HERE / "vendor/alex/alex.h"
    text = path.read_text(encoding="utf-8")
    marker = "  const struct Stats& get_stats() const { return stats_; }"
    hook = """
  std::vector<uint64_t> op_path(T key) const {
    std::vector<TraversalNode> native_path; get_leaf(key,&native_path);
    std::vector<uint64_t> result;
    for (const auto& entry:native_path) {
      if (entry.node==superroot_) continue;
      auto* child=entry.node->children_[entry.bucketID];
      const uint64_t repeats=uint64_t(1)<<child->duplication_factor_;
      result.push_back(uint64_t(entry.bucketID)/repeats*repeats+1);
    }
    return result;
  }
  uint64_t op_height() const {
    int maximum=root_node_->level_;
    for (NodeIterator it(this); !it.is_end(); it.next())
      maximum=std::max(maximum,int(it.current()->level_));
    return static_cast<uint64_t>(maximum-root_node_->level_+1);
  }
"""
    hook += (HERE / "local_alex.inc").read_text(encoding="utf-8")
    path.write_text(replace_once(text, marker, hook+marker), encoding="utf-8")
    path = HERE / "vendor/pgm/pgm_index.hpp"
    text = path.read_text(encoding="utf-8")
    text = replace_once(text, '#include "piecewise_linear_model.hpp"',
                         '#include "cost_hooks.hpp"\n#include "piecewise_linear_model.hpp"')
    text = replace_once(text, 'for (; std::next(lo)->key <= key; ++lo)',
                         'for (; mi_cost::route_compare(std::next(lo)->key <= key); ++lo)')
    for expression in ('s.key < k', 'k < s.key', 's.key < t.key'):
        text = replace_once(text, 'return '+expression+';', 'return mi_cost::route_compare('+expression+');')
    text = replace_once(text, '    inline size_t operator()(const K &k) const {\n        size_t pos;',
                         '    inline size_t operator()(const K &k) const {\n        mi_cost::model();\n        size_t pos;')
    marker = '    static constexpr size_t epsilon_value = Epsilon;'
    hook = """
    size_t op_leaf_id(const K& key) const {
        return static_cast<size_t>(segment_for_key(std::max(first_key,key))-segments.begin());
    }
    size_t op_model_segments() const { return segments.size()-height(); }
"""
    path.write_text(replace_once(text, marker, hook+marker), encoding="utf-8")


def prepare():
    sources = {"lipp": HERE / "dependency_sources/lipp"}
    manifest = {"algorithm_changes": "passive lookup hooks and read-only routing accessors; native bulk construction unchanged", "sources": {}}
    for name, source in sources.items():
        if not source.is_dir():
            raise FileNotFoundError("Native headers missing: " + str(source))
        target = HERE / "vendor" / name
        target.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target, dirs_exist_ok=True)
        manifest["sources"][name] = {
            p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(source.rglob("*")) if p.is_file()
        }
    shutil.copy2(HERE.parent / "trace_metrics.hpp", HERE / "vendor/trace_metrics.hpp")
    shutil.copy2(HERE.parent / "multi_index/cost_hooks.hpp", HERE / "cost_hooks.hpp")
    path = HERE / "vendor/lipp/lipp.h"
    text = path.read_text(encoding="utf-8")
    marker = "    std::allocator<Node> node_allocator;"
    if text.count(marker) != 1 or "op_root_slot(" in text:
        raise ValueError("Unsupported or already injected LIPP header")
    hook = """
public:
    std::vector<uint64_t> op_path(T key) const {
        std::vector<uint64_t> path; Node* node=root;
        while (true) {
            int pos=PREDICT_POS(node,key);
            if (BITMAP_GET(node->none_bitmap,pos)) break;
            if (!BITMAP_GET(node->child_bitmap,pos)) break;
            path.push_back(static_cast<uint64_t>(pos)+1);
            node=node->items[pos].comp.child;
        }
        return path;
    }
    int op_root_slot(T key) const { return PREDICT_POS(root,key); }
    int op_root_capacity() const { return root->num_items; }
    double op_root_slope() const { return root->model.a; }
    long double op_root_intercept() const { return root->model.b; }
    size_t op_reported_bytes() const {
        size_t bytes=0; std::vector<Node*> todo{root};
        while (!todo.empty()) {
            Node* node=todo.back(); todo.pop_back();
            bytes+=sizeof(Node)+sizeof(Item)*node->num_items+2*BITMAP_SIZE(node->num_items);
            for (int i=0; i<node->num_items; ++i)
                if (BITMAP_GET(node->child_bitmap,i)) todo.push_back(node->items[i].comp.child);
        }
        return bytes;
    }
private:
"""
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(text.replace(marker, hook + (HERE / "local_lipp.inc").read_text(encoding="utf-8") + marker))
    prepare_extra_indices(manifest)
    (HERE / "vendor/manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("[PREPARED] isolated ALEX/LIPP/static-PGM; native lookup algorithms preserved", flush=True)


if __name__ == "__main__":
    prepare()
