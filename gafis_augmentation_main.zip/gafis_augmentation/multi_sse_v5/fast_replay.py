"""Import frozen point decisions only, into a NEW timing-only output directory."""
from pathlib import Path
import hashlib
import json
import shutil

import numpy as np

from multi_sse_v5 import driver as d


def _verify_artifacts(artifacts):
    for path,expected in artifacts.items():
        if not Path(path).is_file() or d.digest(path)!=expected:
            raise ValueError('Source/frozen artifact changed: '+str(path))


def _native_compatible(prior,current):
    if not prior.get('multi_sse_v5/native.cpp') or not prior.get('trace_metrics.hpp'):
        raise ValueError('Source freeze lacks native implementation identity')
    for name,identity in prior.items():
        path=Path(name)
        core=(name in ('multi_sse_v5/native.cpp','trace_metrics.hpp')
              or name.startswith('multi_sse_v5/vendor/')
              or (name.startswith('multi_sse_v5/') and len(path.parts)==2
                  and path.suffix in ('.h','.hpp','.inc')))
        if core and current.get(name)!=identity:
            raise ValueError('Index/structural implementation changed: '+name)


def prepare(source_out,new_out,config):
    source=Path(source_out).resolve();out=Path(new_out).resolve()
    if source==out or source in out.parents or out in source.parents:
        raise ValueError('Timing OUT must be a separate directory, not the source or its ancestor/child')
    source_manifest=source/'manifest.json';source_freeze=source/'frozen_manifest.json'
    manifest=d.read(source_manifest);frozen=d.read(source_freeze)
    if frozen.get('frozen_before_timing') is not True or frozen.get('selection_uses_throughput') is not False:
        raise ValueError('Source must be a pre-throughput frozen selection')
    if not frozen.get('variants'):
        raise ValueError('Source contains no frozen variants')
    current=d.code_hashes()
    _native_compatible(frozen.get('code_hashes',{}),current)
    _verify_artifacts(manifest['artifact_hashes']);_verify_artifacts(frozen['artifact_hashes'])
    identity=dict(source_out=str(source),source_manifest_sha256=d.digest(source_manifest),
                  source_frozen_manifest_sha256=d.digest(source_freeze),config=config)
    target_manifest=out/'manifest.json'
    if target_manifest.exists():
        existing=d.read(target_manifest)
        if existing.get('timing_replay')!=identity or existing.get('code_hashes')!=current:
            raise ValueError('Replay configuration/source/code changed; use a NEW OUT')
        _verify_artifacts(existing['artifact_hashes'])
        result=d.read(out/'frozen_manifest.json')
        if result.get('code_hashes')!=current:
            raise ValueError('Replay executable code identity changed')
        _verify_artifacts(result['artifact_hashes'])
        return result
    if out.exists() and any(out.iterdir()):
        raise ValueError('New replay OUT is nonempty without its manifest; use a fresh directory')
    cases={c['case_id']:c for c in manifest['cases']}
    seen=set();plans={};originals=set()
    for row in frozen['variants']:
        cid=row['case_id']
        if cid not in cases or row.get('selection_uses_throughput') is not False:
            raise ValueError('Unplanned or throughput-selected frozen endpoint')
        if row.get('variant_id') in seen:
            raise ValueError('Duplicate frozen variant identity')
        seen.add(row.get('variant_id'))
        case=cases[cid]
        for key in ('n0','index','real_path','real_sha256','queries_path','queries_sha256','query_population_sha256'):
            if row.get(key)!=case.get(key):
                raise ValueError('Frozen endpoint original/query population changed: '+key)
        path=Path(row['points_path']);plan=d.read(path)
        binary_plan=plan.get('format')=='uint64_binary_v1'
        if (plan.get('physical_sha256')!=row['physical_sha256'] or plan.get('k')!=row['k']
            or (not binary_plan and len(plan.get('points',[]))!=row['k'])
            or frozen['artifact_hashes'].get(str(path))!=d.digest(path)):
            raise ValueError('Frozen point plan/hash/count mismatch')
        key=(cid,row['physical_sha256'])
        if key in plans and plans[key]!=plan:
            raise ValueError('Aliases disagree on frozen point coordinates')
        plans[key]=plan
        if row['method']=='original':
            if row['k']!=0 or row['physical_sha256']!=case['real_sha256']:
                raise ValueError('Original endpoint is not the original population')
            originals.add(cid)
        if binary_plan:
            from population import binary
            binary.validate_plan(plan,row,frozen['artifact_hashes'])
            # Streaming merge validates strict order, integer domain, complete
            # original preservation and original-shadow disjointness again.
        elif row['k']:
            points=[]
            for value in plan['points']:
                if isinstance(value,(bool,float)):
                    raise ValueError('Point values must be exact UInt64 integers')
                v=int(value)
                if not 0<=v<2**64-1:
                    raise ValueError('Point outside UInt64 domain')
                points.append(v)
            if points!=sorted(set(points)):
                raise ValueError('Point coordinates must be sorted unique')
            real=np.memmap(case['real_path'],dtype='<u8',mode='r',shape=(case['n0'],))
            try:
                if points[0]<=int(real[0]) or points[-1]>=int(real[-1]):
                    raise ValueError('Shadow point outside original domain')
                values=np.asarray(points,dtype='<u8');positions=np.searchsorted(real,values)
                if np.any(real[positions]==values):
                    raise ValueError('Shadow point collides with an original key')
            finally:
                real._mmap.close()
    if {r['case_id'] for r in frozen['variants']}-originals:
        raise ValueError('Frozen comparison lacks original baseline')
    out.mkdir(parents=True,exist_ok=True)
    # Copy only compact point plans once per physical state. No physical arrays,
    # native per-query dumps, old measurement records, or historical timings.
    paths={};artifacts=dict(frozen['artifact_hashes'])
    for (cid,sha),plan in plans.items():
        filename=hashlib.sha256((cid+':'+sha).encode()).hexdigest()+'.json'
        path=out/'frozen_points'/filename;d.write(path,plan)
        paths[cid,sha]=str(path);artifacts[str(path)]=d.digest(path)
    variants=[]
    for row in frozen['variants']:
        v=dict(row,storage_mode='compact',physical_array_persistent=False,
               points_path=paths[row['case_id'],row['physical_sha256']],
               source_variant_id=row['variant_id'],selection_replayed_without_changes=True)
        if not v['k']:
            v.update(physical_path=v['real_path'],physical_array_persistent=True)
        variants.append(v)
    # Analysis inputs only; never copy timing*.jsonl/csv, measurement_run, etc.
    names=('endpoints.csv','endpoint_rows.jsonl','auto_status.jsonl','coverage_audit.jsonl',
           'regional_options.jsonl','joint_prediction_validation.jsonl','automatic_trials.jsonl',
           'sse_generation.jsonl','original_baselines.csv','baseline_status.json')
    for name in names:
        if (source/name).is_file():
            shutil.copyfile(source/name,out/name);artifacts[str(out/name)]=d.digest(out/name)
    for name,path in (('source_manifest_snapshot.json',source_manifest),('source_frozen_snapshot.json',source_freeze)):
        shutil.copyfile(path,out/name);artifacts[str(out/name)]=d.digest(out/name)
    new_manifest=dict(manifest,code_hashes=current,artifact_hashes=artifacts,timing_replay=identity,
                      original_source_code_hashes=frozen['code_hashes'])
    result=dict(frozen,code_hashes=current,artifact_hashes=artifacts,variants=variants,
                timing_only_replay=True,timing_replay=identity,old_timing_imported=False,
                source_structure_and_cost_recomputed=False,selection_uses_throughput=False,
                storage_mode='compact')
    d.write(out/'manifest.json',new_manifest);d.write(out/'frozen_manifest.json',result)
    print('[FROZEN REPLAY] variants=%d no_search=True no_old_timing=True'%(len(variants)),flush=True)
    return result
