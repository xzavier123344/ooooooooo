#pragma once
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace fast_timing {
inline uint64_t now_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}
struct Sample { uint64_t operations=0, checksum=0; double seconds=0; };
inline std::vector<uint64_t> prefix_sums(const std::vector<uint64_t>& values) {
    std::vector<uint64_t> result(values.size()+1,0);
    for(size_t i=0;i<values.size();++i) result[i+1]=result[i]+values[i];
    return result;
}
inline uint64_t expected_checksum(const std::vector<uint64_t>& prefix,uint64_t count,uint64_t offset) {
    const auto size=prefix.size()-1;
    if(!size || offset>=size) throw std::runtime_error("Invalid checksum corpus/offset");
    uint64_t sum=(count/size)*prefix.back();
    const auto tail=count%size,first=std::min<uint64_t>(tail,size-offset);
    sum+=prefix[offset+first]-prefix[offset];
    if(tail>first) sum+=prefix[tail-first];
    return sum;
}
template<class Query, class Lookup>
Sample run(const std::vector<Query>& queries,double seconds,uint64_t offset,Lookup lookup) {
    if(queries.empty() || !std::isfinite(seconds) || seconds<0 || seconds>3600)
        throw std::runtime_error("Invalid bounded-time query declaration");
    Sample result;
    if(seconds==0) return result;
    size_t cursor=offset%queries.size();
    const auto start=now_ns();
    const auto deadline=start+uint64_t(seconds*1e9);
    // Time is checked each batch, NOT only after an entire query corpus.
    do {
        for(size_t j=0;j<1024;++j) {
            result.checksum+=lookup(queries[cursor]);
            if(++cursor==queries.size()) cursor=0;
        }
        result.operations+=1024;
    } while(now_ns()<deadline);
    result.seconds=double(now_ns()-start)/1e9;
    return result;
}
template<class Records,class Lookup>
uint64_t validate_physical_sample(const Records& values,Lookup lookup,bool& all_shadows) {
    constexpr size_t cap=65536;
    const size_t samples=std::min(cap,values.size());
    for(size_t i=0;i<samples;++i) {
        const size_t pos=samples>1 ? (uint64_t(i)*(values.size()-1))/(samples-1):0;
        bool found=false;auto value=lookup(values[pos].first,found);
        if(!found || value!=values[pos].second)
            throw std::runtime_error("Sampled physical payload validation failed");
    }
    size_t shadows=0;
    for(auto& value:values) if(value.second==0) ++shadows;
    all_shadows=shadows<=cap;
    if(all_shadows && values.size()>cap) {
        for(auto& record:values) if(record.second==0) {
            bool found=false;auto value=lookup(record.first,found);
            if(!found || value!=0) throw std::runtime_error("Shadow payload validation failed");
        }
    }
    return samples;
}
}
