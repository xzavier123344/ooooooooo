"""Regenerable candidate arrays with bounded lifetime, never dataset deletion."""
from contextlib import contextmanager
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

import numpy as np

from multi_sse_v5 import proposals


RESERVE_BYTES = 64*1024*1024


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def is_disk_full(error):
    seen=set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        if getattr(error,'errno',None) in (errno.ENOSPC,getattr(errno,'EDQUOT',122)):
            return True
        message=str(error).lower()
        if any(t in message for t in ('not enough free space','no space left on device','disk quota exceeded')):
            return True
        error=getattr(error,'__cause__',None) or getattr(error,'__context__',None)
    return False


def ensure_space(directory, bytes_required):
    directory=Path(directory).resolve()
    directory.mkdir(parents=True,exist_ok=True)
    available=shutil.disk_usage(directory).free
    required=int(bytes_required)+RESERVE_BYTES
    if available<required:
        raise OSError(errno.ENOSPC,
            'Insufficient disk space: need %d bytes including reserve, available %d on %s; experiment stopped before writing' %
            (required,available,directory))
    return available


def scratch_directory(a):
    root=Path(getattr(a,'scratch_dir','') or tempfile.gettempdir()).resolve()
    token=hashlib.sha256(str(Path(a.out).resolve()).encode()).hexdigest()[:20]
    directory=root/('learned_shadow_'+token)
    directory.mkdir(parents=True,exist_ok=True)
    owner=directory/'EXPERIMENT_OWNER.json'
    declaration={'output':str(Path(a.out).resolve()),'role':'regenerable candidate arrays only'}
    if owner.exists() and json.loads(owner.read_text(encoding='utf-8'))!=declaration:
        raise ValueError('Scratch owner mismatch: '+str(directory))
    if not owner.exists():
        owner.write_text(json.dumps(declaration,indent=2)+'\n',encoding='utf-8')
    return directory


@contextmanager
def temporary_array(values, expected_sha256, a):
    """Delete only the exact mkstemp file allocated by this invocation."""
    directory=scratch_directory(a)
    array=np.asarray(values,dtype='<u8')
    available=ensure_space(directory,array.nbytes)
    fd,name=tempfile.mkstemp(prefix='physical_',suffix='.bin',dir=str(directory))
    os.close(fd)
    path=Path(name)
    print('[SCRATCH WRITE] bytes=%d free=%d path=%s'%(array.nbytes,available,path),flush=True)
    try:
        array.tofile(path)
        if path.stat().st_size!=array.nbytes or digest(path)!=expected_sha256:
            raise ValueError('Temporary physical array integrity mismatch')
        yield path
    finally:
        if path.exists():
            path.unlink()
        print('[SCRATCH RELEASE]',path,flush=True)


@contextmanager
def materialized(row,a):
    """Frozen point/hash plans recreate a candidate before, never during timing."""
    if row.get('points_format')=='uint64_binary_v1' and row['k']:
        from population import binary
        with binary.materialized(row,a) as path:
            yield path
        return
    if row.get('storage_mode','retained')!='compact':
        yield Path(row['physical_path'])
        return
    source=Path(row['real_path'])
    if not row['k']:
        if digest(source)!=row['physical_sha256']:
            raise ValueError('Original candidate identity mismatch')
        yield source
        return
    plan=json.loads(Path(row['points_path']).read_text(encoding='utf-8'))
    if (plan['physical_sha256']!=row['physical_sha256'] or plan['k']!=row['k']
            or len(plan['points'])!=row['k']):
        raise ValueError('Frozen point plan identity mismatch')
    real=np.fromfile(source,dtype='<u8')
    if len(real)!=row['n0']:
        raise ValueError('Original candidate population changed')
    physical=proposals.merge(real,[int(x) for x in plan['points']])
    identity=hashlib.sha256(memoryview(physical).cast('B')).hexdigest()
    if identity!=row['physical_sha256']:
        raise ValueError('Regenerated candidate hash differs from frozen selection')
    with temporary_array(physical,identity,a) as path:
        yield path
