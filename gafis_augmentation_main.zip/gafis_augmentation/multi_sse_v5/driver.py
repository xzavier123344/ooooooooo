"""Atomic artifact I/O and source identity helpers."""
import csv
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import inputs
from multi_sse_v5 import storage
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SCHEMA="gafis_augmentation_v1"


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)

def append(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(value, allow_nan=False) + '\n').encode('utf-8')
    if path.exists() and path.stat().st_size:
        with path.open('rb') as stream:
            stream.seek(-1, 2)
            needs_separator = stream.read(1) != b'\n'
        if needs_separator:
            lines(path)
    with path.open('a+b') as stream:
        stream.seek(0, 2)
        if stream.tell():
            stream.seek(-1, 2)
            if stream.read(1) != b'\n':
                stream.write(b'\n')
        stream.write(payload)
        stream.flush()

def lines(path):
    path = Path(path)
    if not path.is_file():
        return []
    data = path.read_bytes()
    chunks = data.splitlines(keepends=True)
    (result, offset) = ([], 0)
    for (index, chunk) in enumerate(chunks):
        if chunk.strip():
            try:
                value = json.loads(chunk)
            except (ValueError, UnicodeError):
                if index != len(chunks) - 1 or chunk.endswith((b'\n', b'\r')):
                    raise
                if path.is_symlink():
                    raise ValueError('Refuse to repair a symlinked JSONL log: ' + str(path))
                identity = hashlib.sha256(chunk).hexdigest()
                quarantine = path.with_name(path.name + '.truncated-tail.' + identity[:16] + '.log')
                if quarantine.exists():
                    if quarantine.read_bytes() != chunk:
                        raise ValueError('JSONL tail quarantine identity mismatch')
                else:
                    quarantine.write_bytes(chunk)
                recovery = quarantine.with_suffix('.json')
                write(recovery, dict(schema='jsonl_trailing_append_recovery_v1', log=str(path), retained_bytes=offset, original_bytes=len(data), discarded_bytes=len(chunk), discarded_sha256=identity, quarantine=str(quarantine), action='truncate_incomplete_final_append_only'))
                if path.read_bytes() != data:
                    raise RuntimeError('JSONL changed while recovering its final append: ' + str(path))
                temporary = path.with_name(path.name + '.recovery.tmp')
                temporary.write_bytes(data[:offset])
                temporary.replace(path)
                return result
            result.append(value)
        offset += len(chunk)
    return result

def csvwrite(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, allow_nan=False) if isinstance(value, (dict, list)) else value for (key, value) in row.items()})
    temporary.replace(path)

def csvread(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def digest(path):
    return inputs.digest(Path(path))

def code_hashes():
    """Source, generated isolated headers and native binary identity.

    Metadata/docs/results are not executable dependencies. All source modules
    in this independent experiment are hashed, including its measurement code.
    """
    paths = [path for path in HERE.iterdir() if path.is_file() and path.suffix in ('.py', '.cpp', '.hpp', '.inc', '.sh')]
    for directory in (HERE / 'vendor', HERE / 'bin'):
        if directory.is_dir():
            paths.extend((path for path in directory.rglob('*') if path.is_file()))
    for path in (ROOT / 'inputs.py', ROOT / 'trace_metrics.hpp'):
        if path.is_file():
            paths.append(path)
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in sorted(set(paths))}

def key_write(path, values):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    array = np.asarray(values, dtype='<u8')
    storage.ensure_space(path.parent, array.nbytes)
    array.tofile(path)

def key_read(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size % 8:
        raise ValueError('Malformed raw UInt64 key array: ' + str(path))
    return np.fromfile(path, dtype='<u8')

def split_csv(value, cast=str):
    return [cast(part.strip()) for part in value.split(',') if part.strip()]
