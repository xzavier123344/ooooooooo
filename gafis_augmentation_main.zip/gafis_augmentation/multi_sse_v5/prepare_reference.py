"""Read the pinned Google archive into this experiment's own source directory."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from multi_index.prepare_google_btree import prepare

if __name__ == "__main__":
    archive = HERE.parent / "multi_index" / "cpp-btree-1.0.1.tar.gz"
    if not archive.is_file():
        raise FileNotFoundError("Pinned reference archive missing: " + str(archive))
    prepare(archive=archive, target=HERE / "vendor" / "google_btree")
    print("[REFERENCE PREPARED] isolated Google cpp-btree 1.0.1; no network/download")
