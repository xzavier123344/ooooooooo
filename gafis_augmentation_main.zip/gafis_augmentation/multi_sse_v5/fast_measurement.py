"""Post-selection single-threaded original-key throughput measurement."""
import argparse
from collections import defaultdict
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import random
import sys
import time
import numpy as np
from multi_sse_v5 import driver as d, measurement as old, storage
PROTOCOL='bounded_offset_v1'


def parse(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-out',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--query-count',type=int,default=1000000)
    parser.add_argument('--seed',type=int,default=1729)
    parser.add_argument('--repeats',type=int,default=6)
    parser.add_argument('--seconds',type=float,default=2)
    parser.add_argument('--warmup',type=float,default=.25)
    parser.add_argument('--cpu',default='auto')
    parser.add_argument('--scratch-dir',default='')
    parser.add_argument('--timeout',type=float,default=14400)
    parser.add_argument('--heartbeat',type=float,default=30)
    return parser.parse_args(argv)


def binary(index):
    path = d.HERE / 'bin' / ('fast_' + index + '_resident')
    if not path.is_file():
        path = path.with_suffix('.exe')
    if not path.is_file():
        raise FileNotFoundError('Build fast timing workers first: ' + str(path))
    return str(path.resolve())

def query_offset(case_id, repeat, repeats, count, seed):
    if count < 1 or not 0 <= repeat < repeats:
        raise ValueError('Invalid query offset declaration')
    initial = int(hashlib.sha256((str(seed) + ':' + case_id).encode()).hexdigest()[:16], 16) % count
    return (initial + repeat * count // repeats) % count

def prepare_queries(out, case, count, seed):
    """Stratified ranks span the ENTIRE original dataset; never a key window."""
    source = Path(case['real_path'])
    n = int(case['n0'])
    q = min(int(count), n)
    if q < 1 or source.stat().st_size != n * 8:
        raise ValueError('Original population/query count invalid')
    token = hashlib.sha256((case['real_sha256'] + ':' + str(seed) + ':' + str(q)).encode()).hexdigest()
    folder = Path(out) / 'timing_queries' / token
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / 'queries.bin'
    plan = folder / 'query_plan.json'
    declaration = dict(original_sha256=case['real_sha256'], original_count=n, query_count=q, requested_query_count=int(count), seed=int(seed), sampling='one uniform rank per equal-rank stratum, without replacement; shuffled globally', all_original_keys_indexed=True, querying_shadow_keys=False)
    if plan.is_file():
        info = d.read(plan)
        if any((info.get(k) != v for (k, v) in declaration.items())):
            raise ValueError('Frozen timing query declaration changed')
        if not target.is_file() or d.digest(target) != info['queries_sha256']:
            raise ValueError('Timing query file changed')
        return info
    derived = int(token[:16], 16)
    rng = np.random.default_rng(derived)
    bounds = np.arange(q + 1, dtype=np.int64) * n // q
    ranks = bounds[:-1] + rng.integers(0, bounds[1:] - bounds[:-1], size=q)
    rng.shuffle(ranks)
    real = np.memmap(source, dtype='<u8', mode='r', shape=(n,))
    try:
        queries = np.asarray(real[ranks], dtype='<u8')
    finally:
        real._mmap.close()
    storage.ensure_space(folder, queries.nbytes)
    temporary = target.with_suffix('.bin.tmp')
    queries.tofile(temporary)
    temporary.replace(target)
    info = dict(declaration, queries_path=str(target.resolve()), queries_sha256=d.digest(target), query_checksum=str(int(np.sum(ranks.astype(np.uint64) + 1, dtype=np.uint64))), ranks_sha256=hashlib.sha256(ranks.astype('<u8').tobytes()).hexdigest())
    d.write(plan, info)
    print('[TIMING QUERIES] original=%d queries=%d full_index=True path=%s' % (n, q, target), flush=True)
    return info

class BoundedWorker(old.Worker):

    def __init__(self, command, cpu=None, timeout=14400, label='worker', heartbeat=30):
        self.label = label
        self.heartbeat = float(heartbeat)
        print('[WORKER START]', label, Path(command[0]).name, flush=True)
        super().__init__(command, cpu, timeout)
        if self.ready.get('timing_protocol') != PROTOCOL:
            self.close()
            raise ValueError('Wrong native timing protocol: ' + label)
        print('[WORKER READY]', label, 'pid=' + str(self.process.pid), 'originals=' + str(self.ready.get('real_count')), 'queries=' + str(self.ready.get('query_count')), flush=True)

    def receive(self, prefix):
        start = time.monotonic()
        until = start + self.timeout
        next_heartbeat = start + self.heartbeat
        while True:
            now = time.monotonic()
            left = until - now
            if left <= 0:
                raise TimeoutError(self.label + ' timeout waiting for ' + prefix)
            try:
                line = self.queue.get(timeout=min(left, max(0.01, next_heartbeat - now)))
            except queue.Empty:
                now = time.monotonic()
                if now >= next_heartbeat:
                    print('[WORKER WAIT]', self.label, 'pid=' + str(self.process.pid), 'waiting=' + prefix, 'elapsed_s=' + str(round(now - start)), flush=True)
                    next_heartbeat = now + self.heartbeat
                continue
            if line is None:
                self.stderr.seek(0)
                raise RuntimeError(self.label + ' exited: ' + self.stderr.read().decode(errors='replace')[-4000:])
            if line.startswith(prefix + ' '):
                value = json.loads(line[len(prefix) + 1:])
                if value.get('success') is not True:
                    raise RuntimeError('Native worker reported failure: ' + self.label)
                return value

    def sample(self, seconds, warmup, offset):
        if not 0 <= offset < int(self.ready['query_count']):
            raise ValueError('Query offset outside shared corpus')
        print('[SAMPLE START]', self.label, 'offset=' + str(offset), flush=True)
        try:
            self.process.stdin.write('%s %s %d\n' % (seconds, warmup, offset))
            self.process.stdin.flush()
            value = self.receive('RESULT_JSON')
        except BaseException:
            self.close()
            raise
        if not math.isfinite(float(value['throughput'])) or value['throughput'] <= 0 or int(value.get('operations', 0)) < 1 or (int(value.get('start_offset', -1)) != offset) or (str(value.get('query_checksum')) != str(self.ready['query_checksum'])):
            raise ValueError('Invalid bounded sample identity/result: ' + self.label)
        print('[SAMPLE DONE]', self.label, 'seconds=' + str(round(value['elapsed_seconds'], 3)), 'operations=' + str(value['operations']), flush=True)
        return value

def check_ready(worker, case, queries):
    ready = worker.ready
    if ready.get('physical_samples_correct') is not True or ready.get('queries_correct') is not True or ready.get('has_structural_cost') is True or (int(ready.get('real_count', -1)) != case['n0']) or (int(ready.get('query_count', -1)) != queries['query_count']) or (str(ready.get('query_checksum')) != queries['query_checksum']):
        raise ValueError('Sampled correctness/query population gate failed: ' + worker.label)

def competing_processes(source_out, variants):
    """Read-only: never stop processes automatically or overwrite an active run."""
    proc = Path('/proc')
    if not proc.is_dir():
        return []
    inputs = {r[k] for r in variants for k in ('real_path', 'queries_path') if r.get(k)}
    result = []
    source = Path(source_out).resolve()
    for p in proc.iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        try:
            args = [x.decode(errors='replace') for x in (p / 'cmdline').read_bytes().split(b'\x00') if x]
            if not args:
                continue
            hit = False
            if '--out' in args and any((x.endswith(('driver.py', 'fast_measurement.py', 'cohort_measurement.py')) for x in args)):
                value = Path(args[args.index('--out') + 1])
                if not value.is_absolute():
                    value = (p / 'cwd').resolve() / value
                hit = value.resolve() == source
            if Path(args[0]).name.startswith(('occupancy_', 'fast_', 'cohort_')) and 'resident' in Path(args[0]).name and any((x in inputs for x in args)):
                hit = True
            if hit:
                result.append(dict(pid=int(p.name), command=' '.join(args)[:500]))
        except (OSError, IndexError):
            continue
    return result

def settings(a):
    if isinstance(a.repeats, bool) or a.repeats < 1 or a.query_count < 1 or (a.heartbeat <= 0) or (not math.isfinite(a.seconds)) or (a.seconds <= 0) or (not math.isfinite(a.warmup)) or (a.warmup < 0) or (not math.isfinite(a.timeout)) or (a.timeout <= 0) or (not math.isfinite(a.heartbeat)):
        raise ValueError('Positive finite measurement settings required')
    return dict(timing_protocol=PROTOCOL, repeats=a.repeats, seconds=a.seconds, warmup=a.warmup, cpu=a.cpu, query_count=a.query_count, query_seed=a.seed, timeout=a.timeout, heartbeat=a.heartbeat, scratch_dir=str(Path(a.scratch_dir).resolve()) if a.scratch_dir else None, full_dataset_indexed=True, complete_query_passes=False, all_repeats_retained=True, old_timing_imported=False, throughput_used_for_selection=False, correctness_scope='sampled_physical_and_all_query_corpus', query_sampling='stratified uniform original rank without replacement then shuffle', reference_reused_within_case=True, original_index_reused_within_case=True, offset_rule='case/seed hash plus floor(repeat*query_count/repeats), shared by all methods')

def _progress(a, fm, done, original_done, case_id, repeat):
    unique = {(r['case_id'], r['physical_sha256']) for r in fm['variants']}
    bases = {r['case_id']: r for r in fm['variants'] if r['method'] == 'original'}
    expected = len(unique) * a.repeats
    d.write(a.out / 'timing_progress.json', dict(completed_original_pairs=len(original_done), completed_candidate_pairs=len(done), planned_total_pairs=expected, case_id=case_id, repeat=repeat + 1, timing_protocol=PROTOCOL))

def measure(a):
    from multi_sse_v5 import fast_replay
    config = settings(a)
    source = Path(a.source_out).resolve()
    source_frozen = d.read(source / 'frozen_manifest.json')
    active = competing_processes(source, source_frozen['variants'])
    if active:
        raise RuntimeError('Old experiment/competing workers still active; verify and stop first: ' + json.dumps(active))
    fm = fast_replay.prepare(source, a.out, config)
    rows = fm['variants']
    bases = {r['case_id']: r for r in rows if r['method'] == 'original'}
    plans = {cid: prepare_queries(a.out, base, a.query_count, a.seed) for (cid, base) in bases.items()}
    query_manifest = a.out / 'timing_query_manifest.json'
    query_declaration = dict(protocol=PROTOCOL, cases=plans)
    if query_manifest.exists() and d.read(query_manifest) != query_declaration:
        raise ValueError('Timing query population changed')
    d.write(query_manifest, query_declaration)
    query_artifacts = {str(query_manifest): d.digest(query_manifest)}
    for info in plans.values():
        path = Path(info['queries_path'])
        query_artifacts[str(path)] = info['queries_sha256']
        query_artifacts[str(path.parent / 'query_plan.json')] = d.digest(path.parent / 'query_plan.json')
    if any((fm['artifact_hashes'].get(k) != v for (k, v) in query_artifacts.items())):
        if (a.out / 'timing_raw.jsonl').exists():
            raise ValueError('Cannot change timing query freeze after measurements started')
        fm['artifact_hashes'].update(query_artifacts)
        fm['timing_query_sampling_frozen_before_first_sample'] = True
        d.write(a.out / 'frozen_manifest.json', fm)
    run = dict(config, frozen_manifest_sha256=d.digest(a.out / 'frozen_manifest.json'), timing_query_manifest_sha256=d.digest(query_manifest), query_file_sha256={p['queries_path']: p['queries_sha256'] for p in plans.values()}, B_reference='Google cpp-btree 1.0.1', request_p99_latency_measured=False)
    runpath = a.out / 'measurement_run.json'
    if runpath.exists() and d.read(runpath) != run:
        raise ValueError('Timing settings/queries changed; use a NEW OUT')
    d.write(runpath, run)
    records = d.lines(a.out / 'timing_raw.jsonl')
    done = set()
    original_done = set()
    for r in records:
        if r.get('frozen_manifest_sha256') != run['frozen_manifest_sha256'] or r.get('timing_protocol') != PROTOCOL:
            raise ValueError('Mixed old/new timing records')
        if r.get('status') == 'ok':
            key = (r['case_id'], r['physical_sha256'], r['repeat'])
            target = original_done if r.get('kind') == 'original_baseline' else done
            if key in target:
                raise ValueError('Duplicate successful measurement')
            target.add(key)
    unique = {(r['case_id'], r['physical_sha256']): r for r in rows}
    print('[TIMING PLAN] policy_labels=%d unique_physical_states=%d repeats=%d full_index=True query_count<=%d' % (len(rows), len(unique), a.repeats, a.query_count), flush=True)
    cpu = old.resolve_cpu(a.cpu)
    common = dict(timing_protocol=PROTOCOL, frozen_manifest_sha256=run['frozen_manifest_sha256'], full_dataset_indexed=True, complete_query_passes=False, builds_outside_references=True, drifting_repeat_retained=True, all_repeats_retained=True)
    for (cid, base) in bases.items():
        query = plans[cid]
        base_sha = base['physical_sha256']
        current_kind = 'original_baseline'
        repeat = 0
        case_variants = [v for ((case_id, sha), v) in unique.items() if case_id == cid and sha != base_sha]
        random.Random(int(hashlib.sha256((str(a.seed) + ':' + cid).encode()).hexdigest()[:16], 16)).shuffle(case_variants)
        needed_original = [r for r in range(a.repeats) if (cid, base_sha, r) not in original_done]
        case_variants = [v for v in case_variants if any(((cid, v['physical_sha256'], r) not in done for r in range(a.repeats)))]
        if not needed_original and (not case_variants):
            continue
        print('[CASE START]', cid, 'candidate_states=' + str(len(case_variants)), flush=True)
        command = lambda physical: [binary(base['index']), '--real', base['real_path'], '--physical', str(physical), '--queries', query['queries_path'], '--mode', 'resident', '--execution', base.get('execution', 'bulk'), '--complete-passes', '0']

        def worker(stack, cmd, label):
            obj = stack.enter_context(BoundedWorker(cmd, cpu, a.timeout, label, a.heartbeat))
            d.append(a.out / 'worker_startups.jsonl', dict(case_id=cid, label=label, pid=obj.process.pid, executable=Path(cmd[0]).name, ready=obj.ready, timing_protocol=PROTOCOL))
            return obj
        try:
            with ExitStack() as persistent:
                basephysical = persistent.enter_context(storage.materialized(base, a))
                b = worker(persistent, [binary('google_btree'), '--real', base['real_path'], '--queries', query['queries_path']], cid + '.B-tree')
                original = worker(persistent, command(basephysical), cid + '.original')
                check_ready(b, base, query)
                check_ready(original, base, query)
                for repeat in needed_original:
                    offset = query_offset(cid, repeat, a.repeats, query['query_count'], a.seed)
                    print('[ORIGINAL PAIR]', cid, '%d/%d' % (repeat + 1, a.repeats), flush=True)
                    before = b.sample(a.seconds, a.warmup, offset)
                    native = original.sample(a.seconds, a.warmup, offset)
                    after = b.sample(a.seconds, a.warmup, offset)
                    bref = math.sqrt(before['throughput'] * after['throughput'])
                    record = dict(common, status='ok', kind='original_baseline', case_id=cid, index=base['index'], physical_sha256=base_sha, repeat=repeat, start_offset=offset, query_count=query['query_count'], queries_sha256=query['queries_sha256'], raw_original_throughput=native['throughput'], B_before=before['throughput'], B_after=after['throughput'], B_normalized_speedup=native['throughput'] / bref, reference_drift=max(before['throughput'], after['throughput']) / min(before['throughput'], after['throughput']) - 1, native_result=native, reference_results=[before, after], startup_correctness=dict(original=original.ready, reference=b.ready))
                    d.append(a.out / 'timing_raw.jsonl', record)
                    original_done.add((cid, base_sha, repeat))
                    _progress(a, fm, done, original_done, cid, repeat)
                    print('[PAIR DONE]', cid, 'original', '%d/%d' % (repeat + 1, a.repeats), flush=True)
                for (ordinal, v) in enumerate(case_variants, 1):
                    current_kind = 'variant_pair'
                    sha = v['physical_sha256']
                    missing = [r for r in range(a.repeats) if (cid, sha, r) not in done]
                    print('[CANDIDATE START]', cid, '%d/%d' % (ordinal, len(case_variants)), sha[:12], flush=True)
                    try:
                        with ExitStack() as candidate_stack:
                            physical = candidate_stack.enter_context(storage.materialized(v, a))
                            candidate = worker(candidate_stack, command(physical), cid + '.candidate.' + sha[:12])
                            check_ready(candidate, base, query)
                            for repeat in missing:
                                offset = query_offset(cid, repeat, a.repeats, query['query_count'], a.seed)
                                order = ('original', 'candidate') if repeat % 2 == 0 else ('candidate', 'original')
                                workers = dict(original=original, candidate=candidate)
                                refs = [b.sample(a.seconds, a.warmup, offset)]
                                native = {}
                                for role in order:
                                    native[role] = workers[role].sample(a.seconds, a.warmup, offset)
                                    refs.append(b.sample(a.seconds, a.warmup, offset))
                                (norms, ratio) = old.normalized_pair(native, refs, order)
                                bvalues = [r['throughput'] for r in refs]
                                record = dict(common, status='ok', kind='variant_pair', case_id=cid, index=v['index'], physical_sha256=sha, repeat=repeat, start_offset=offset, query_count=query['query_count'], queries_sha256=query['queries_sha256'], raw_throughput=native['candidate']['throughput'], original_raw_throughput=native['original']['throughput'], B_normalized_speedup=norms['candidate'], original_B_normalized_speedup=norms['original'], paired_original_gain_ratio=ratio, raw_original_gain_ratio=native['candidate']['throughput'] / native['original']['throughput'], reference_throughputs=bvalues, reference_drift=max(bvalues) / min(bvalues) - 1, timing_order=list(order), native_results=native, reference_results=refs, persistent_reference=True, persistent_original=True, startup_correctness=dict(candidate=candidate.ready))
                                d.append(a.out / 'timing_raw.jsonl', record)
                                done.add((cid, sha, repeat))
                                _progress(a, fm, done, original_done, cid, repeat)
                                print('[PAIR DONE]', cid, sha[:12], '%d/%d' % (repeat + 1, a.repeats), 'paired_ratio=' + str(round(ratio, 6)), flush=True)
                    except (OSError, RuntimeError, ValueError, TimeoutError) as error:
                        d.append(a.out / 'timing_raw.jsonl', dict(common, status='failed', kind='variant_pair', case_id=cid, index=v['index'], physical_sha256=sha, repeat=repeat, error=str(error)))
                        print('[CANDIDATE FAILED]', cid, sha[:12], str(error), flush=True)
                        if storage.is_disk_full(error) or b.process.poll() is not None or original.process.poll() is not None:
                            raise
        except (OSError, RuntimeError, ValueError, TimeoutError) as error:
            d.append(a.out / 'timing_raw.jsonl', dict(common, status='failed', kind='case_failure', case_id=cid, index=base['index'], physical_sha256=base_sha, repeat=repeat, error=str(error)))
            print('[CASE FAILED]', cid, str(error), flush=True)
            if storage.is_disk_full(error):
                raise
    report(a)

def report(a):
    old.report(a)
    fields = dict(timing_protocol=PROTOCOL, full_dataset_indexed=True, each_sample_queries_entire_original_dataset=False, complete_query_passes=False, query_count_requested=a.query_count, query_seed=a.seed, correctness_scope='sampled_physical_and_all_query_corpus')
    for name in ('timing_summary.csv', 'weight_comparison.csv', 'weight_summary.csv', 'raw_vs_trunc_comparison.csv', 'empirical_throughput_space_frontier.csv', 'original_ratio_rows.csv', 'plafi_ratio_correlations.csv', 'space_efficiency.csv', 'equal_extra_space_comparisons.csv', 'incremental_space_throughput_frontier.csv', 'mechanism_comparison.csv'):
        path = a.out / name
        if path.is_file() and path.stat().st_size > 2:
            d.csvwrite(path, [dict(row, **fields) for row in d.csvread(path)])
    summary = d.read(a.out / 'timing_summary.json')
    summary.update(fields)
    d.write(a.out / 'timing_summary.json', summary)
    fm = d.read(a.out / 'frozen_manifest.json')
    records = d.lines(a.out / 'timing_raw.jsonl')
    unique = {(r['case_id'], r['physical_sha256']) for r in fm['variants']}
    ok = {(r['case_id'], r['physical_sha256'], r['repeat']) for r in records if r.get('status') == 'ok'}
    expected = {(cid, sha, repeat) for (cid, sha) in unique for repeat in range(a.repeats)}
    status = dict(fields, complete=ok == expected, successful_pairs=len(ok), planned_pairs=len(expected), missing_pairs=[dict(case_id=c, physical_sha256=s, repeat=r) for (c, s, r) in sorted(expected - ok)], old_timing_imported=False, selection_or_weight_changes=False)
    d.write(a.out / 'fast_measurement_status.json', status)
    print('[FAST TIMING COMPLETE]' if status['complete'] else '[FAST TIMING INCOMPLETE]', '%d/%d pairs' % (len(ok), len(expected)), flush=True)
