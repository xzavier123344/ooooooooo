// Root-occupancy diagnostic for native LIPP and official AFLI. Original key
// payloads remain stable; shadow keys carry payload 0, never an original hit.
#include <algorithm>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include "cost_hooks.hpp"

namespace op_ledger {
struct alignas(std::max_align_t) Header { size_t bytes; bool counted; };
inline bool enabled=false;
inline size_t live=0,peak=0;
}
void* operator new(std::size_t n) {
    if(n>std::numeric_limits<size_t>::max()-sizeof(op_ledger::Header)) throw std::bad_alloc();
    auto* h=static_cast<op_ledger::Header*>(std::malloc(sizeof(op_ledger::Header)+std::max<size_t>(n,1)));
    if(!h) throw std::bad_alloc();
    h->bytes=n;h->counted=op_ledger::enabled;
    if(h->counted) {op_ledger::live+=n;op_ledger::peak=std::max(op_ledger::peak,op_ledger::live);}
    return h+1;
}
void operator delete(void* p) noexcept {
    if(!p) return;
    auto* h=static_cast<op_ledger::Header*>(p)-1;
    if(h->counted) op_ledger::live-=h->bytes;
    std::free(h);
}
void* operator new[](size_t n) {return ::operator new(n);}
void operator delete[](void* p) noexcept {::operator delete(p);}
void operator delete(void* p,size_t) noexcept {::operator delete(p);}
void operator delete[](void* p,size_t) noexcept {::operator delete(p);}

#if defined(OP_LIPP)
#include "lipp.h"
#elif defined(OP_AFLI)
#include "afli/afli.h"
#elif defined(OP_ALEX)
#include "alex/alex.h"
#elif defined(OP_PGM)
#include "pgm/pgm_index.hpp"
#else
#error Select OP_LIPP or OP_AFLI
#endif

using Key=uint64_t;
using Record=std::pair<Key,uint64_t>;
using Args=std::map<std::string,std::string>;
static std::string get(const Args& a,const std::string& k,const std::string& fallback) {
    auto i=a.find(k);return i==a.end()?fallback:i->second;
}
static uint64_t now_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
static std::vector<Key> load(const std::string& path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    if(!f) throw std::runtime_error("Cannot open raw UInt64 file: "+path);
    auto bytes=f.tellg();
    if(bytes<0 || bytes%8) throw std::runtime_error("Raw UInt64 file byte length invalid");
    std::vector<Key> result(size_t(bytes)/8);f.seekg(0);
    f.read(reinterpret_cast<char*>(result.data()),std::streamsize(bytes));
    if(!f) throw std::runtime_error("Raw UInt64 read failed");
    return result;
}
static void validate(const std::vector<Key>& keys) {
    if(keys.size()<3 || keys.size()>size_t(INT32_MAX/6) || keys.back()==UINT64_MAX ||
       !std::is_sorted(keys.begin(),keys.end()) || std::adjacent_find(keys.begin(),keys.end())!=keys.end())
        throw std::runtime_error("Key files require at least 3 sorted unique UInt64 keys, no UINT64_MAX, and safe native count");
}
static std::vector<Record> records(const std::vector<Key>& physical,const std::vector<Key>& real) {
    std::vector<Record> values;values.reserve(physical.size());size_t rank=0;
    for(auto key:physical) {
        uint64_t value=0;
        if(rank<real.size() && key==real[rank]) {value=rank+1;++rank;}
        values.emplace_back(key,value);
    }
    if(rank!=real.size()) throw std::runtime_error("Physical key file omitted an original key");
    return values;
}
class Native {
public:
#ifdef OP_LIPP
    LIPP<Key,uint64_t> index;
    static constexpr const char* name="lipp";
    Key origin=0;
    explicit Native(const std::vector<Record>& values):index(0,true,0) {
        index.bulk_load(values.data(),int(values.size()));
    }
    uint64_t lookup(Key key,bool& found,size_t* visits=nullptr) {
        uint64_t value=0;found=index.hhh_lookup(key,value,visits);return value;
    }
    bool has_model() const {return true;}
    int64_t slot(Key key) const {return index.op_root_slot(key);}
    uint64_t capacity() const {return index.op_root_capacity();}
    double slope() const {return index.op_root_slope();}
    long double intercept() const {return index.op_root_intercept();}
    uint64_t nodes() const {return index.hhh_nodes();}
    uint64_t reported_bytes() const {return index.op_reported_bytes();}
    std::vector<uint64_t> path(Key key) const {return index.op_path(key);}
#elif defined(OP_AFLI)
    nfl::AFLI<Key,uint64_t> index;
    static constexpr const char* name="afli";
    Key origin;
    explicit Native(const std::vector<Record>& values):origin(values.front().first) {
        std::vector<Record> translated;translated.reserve(values.size());
        for(auto value:values) translated.emplace_back(value.first-origin,value.second);
        index.bulk_load(translated.data(),uint32_t(translated.size()),-1,0);
    }
    uint64_t lookup(Key key,bool& found,size_t* visits=nullptr) {
        if(key<origin) {found=false;return 0;}
        auto it=index.find(key-origin);found=!it.is_end();
        (void)visits;return found?it.value():0;
    }
    bool has_model() const {return index.op_root_has_model();}
    int64_t slot(Key key) const {return key<origin?0:index.op_root_slot(key-origin);}
    uint64_t capacity() const {return index.op_root_capacity();}
    double slope() const {return index.op_root_slope();}
    long double intercept() const {return index.op_root_intercept();}
    uint64_t nodes() const {return index.op_node_count();}
    uint64_t reported_bytes() {return index.index_size();}
    std::vector<uint64_t> path(Key key) const {return index.op_path(key-origin);}
#elif defined(OP_ALEX)
    using Index=alex::Alex<Key,uint64_t,alex::AlexCompare,std::allocator<Record>,false>;
    Index index;
    static constexpr const char* name="alex";
    Key origin=0;
    uint64_t height_cache=0,reported_cache=0;
    explicit Native(const std::vector<Record>& values) {
        index.bulk_load(values.data(),int(values.size()));
        height_cache=index.op_height();reported_cache=index.model_size()+index.data_size();
    }
    uint64_t lookup(Key key,bool& found,size_t* visits=nullptr) {
        auto* value=key==UINT64_MAX?nullptr:index.get_payload(key);
        found=value!=nullptr;(void)visits;return found?*value:0;
    }
    bool has_model() const {return true;}
    uint64_t capacity() const {
        return index.root_node_->is_leaf_?static_cast<Index::data_node_type*>(index.root_node_)->data_capacity_:
            static_cast<Index::model_node_type*>(index.root_node_)->num_children_;
    }
    int64_t slot(Key key) const {
        const double value=index.root_node_->model_.predict_double(key);
        return value<=0?0:value>=double(capacity()-1)?int64_t(capacity()-1):int64_t(value);
    }
    double slope() const {return index.root_node_->model_.a_;}
    long double intercept() const {return index.root_node_->model_.b_;}
    uint64_t nodes() const {return index.num_nodes();}
    uint64_t reported_bytes() const {return reported_cache;}
    std::vector<uint64_t> path(Key key) const {return index.op_path(key);}
#elif defined(OP_PGM)
    using Index=pgm::PGMIndex<Key,64,4>;
    std::vector<Record> data;
    Index index;
    static constexpr const char* name="pgm";
    Key origin=0;
    static std::vector<Key> keys_of(const std::vector<Record>& values) {
        std::vector<Key> keys;keys.reserve(values.size());for(const auto& row:values)keys.push_back(row.first);return keys;
    }
    explicit Native(const std::vector<Record>& values):data(values),index(keys_of(data)) {}
    uint64_t lookup(Key key,bool& found,size_t* visits=nullptr) {
        auto range=index.search(key);
        auto it=std::lower_bound(data.begin()+range.lo,data.begin()+range.hi,key,
            [](const Record& row,Key value){return mi_cost::correction_compare(row.first<value);});
        found=it!=data.end()&&mi_cost::final_compare(it->first==key);
        (void)visits;return found?it->second:0;
    }
    bool has_model() const {return false;} // No meaningful single root-slot occupancy diagnostic.
    uint64_t capacity() const {return 0;}
    int64_t slot(Key) const {return -1;}
    double slope() const {return 0;}
    long double intercept() const {return 0;}
    uint64_t nodes() const {return index.op_model_segments();}
    uint64_t reported_bytes() const {return data.capacity()*sizeof(Record)+index.size_in_bytes();}
    std::vector<uint64_t> path(Key key) const {return {index.op_leaf_id(key)+1};}
#endif
    double probe(Key key,uint64_t expected,double& route,double& local,uint64_t& visits) {
        bool found=false;
#ifdef OP_LIPP
        size_t depth=0;auto value=lookup(key,found,&depth);visits=depth;route=double(depth);local=0;
#elif defined(OP_ALEX)
        fa::reset();auto value=lookup(key,found);auto m=fa::finish();
        route=m.route_ops();local=m.local_ops();visits=uint64_t(m.route_models)+1;
#else
        mi_cost::reset();auto value=lookup(key,found);auto m=mi_cost::finish();
        route=m.route_ops;local=m.local_ops;visits=m.node_visits;
#ifdef OP_PGM
        visits=m.model_evals;
#endif
#endif
        if(!found || value!=expected) throw std::runtime_error("Original query payload validation failed");
        return route+local;
    }
};
template<class T> static void array(const std::vector<T>& values) {
    std::cout<<'[';for(size_t i=0;i<values.size();++i) {if(i) std::cout<<',';std::cout<<values[i];}std::cout<<']';
}
static std::vector<int64_t> root_slots(const Native& index,const std::vector<Key>& keys) {
    std::vector<int64_t> out;if(!index.has_model()) return out;out.reserve(keys.size());
    for(auto key:keys) out.push_back(index.slot(key));
    if(!std::is_sorted(out.begin(),out.end())) throw std::runtime_error("Native root slots not monotone");
    return out;
}
struct Region {size_t begin=SIZE_MAX,end=0,physical_count=0,original_count=0;double work_mass=0;};
using Regions=std::map<std::vector<uint64_t>,Region>;
struct RegionMetadata {
    bool bounded=false,prefix_budget_reached=false,depth_censored=false;
    size_t sampled_positions=0,prefix_budget=SIZE_MAX,discovered_prefix_count=0,reported_prefix_count=0;
};
static void phase(const char* stage,size_t count=0) {
    std::cerr<<"[NATIVE PHASE] index="<<Native::name<<" stage="<<stage
             <<" count="<<count<<" monotonic_ns="<<now_ns()<<'\n'<<std::flush;
}
struct PhaseProgress {
    const char* stage;size_t total,next,stride;
    PhaseProgress(const char* name,size_t count):stage(name),total(count),
        next(std::max<size_t>(1,(count+9)/10)),stride(next) {phase(stage,0);}
    void tick(size_t done) {
        if(done>=next||done==total) {
            phase(stage,done);
            next=done+stride;
        }
    }
};
static Regions collect_regions(const Native& index,const std::vector<Key>& physical,
                              const std::vector<Key>& queries,const std::vector<double>& work,size_t depth_limit=SIZE_MAX,
                              size_t prefix_budget=SIZE_MAX,size_t discovery_samples=0,RegionMetadata* metadata=nullptr) {
    Regions result;
    RegionMetadata info;info.bounded=prefix_budget!=SIZE_MAX;info.prefix_budget=prefix_budget;
    if(depth_limit==0||prefix_budget==0)throw std::runtime_error("Region depth/prefix budget must be positive");
    if(info.bounded) {
        // Discovery selects native paths, NOT the dataset or evaluation queries.
        // Once selected, their physical/query/work counts below are exact full
        // population counts. Bounded discovery avoids an O(all tree nodes) map.
        result.emplace(std::vector<uint64_t>{},Region{});
        const size_t samples=std::min(physical.size(),std::max<size_t>(1,discovery_samples));
        size_t stride=std::max<size_t>(1,static_cast<size_t>(samples*.6180339887498949L));
        while(std::gcd(stride,samples)!=1)++stride;
        size_t slot=0;
        for(size_t sample=0;sample<samples;++sample) {
            // Coprime cell order spreads early discovery over the key domain,
            // even when the prefix budget is reached before all cells are seen.
            const size_t position=static_cast<size_t>((static_cast<long double>(slot)+.5L)*physical.size()/samples);
            auto path=index.path(physical[std::min(position,physical.size()-1)]);
            info.depth_censored=info.depth_censored||path.size()+1>depth_limit;
            std::vector<uint64_t> prefix;
            for(size_t depth=0;depth<=path.size()&&depth<depth_limit;++depth) {
                if(!result.count(prefix)) {
                    if(result.size()<prefix_budget)result.emplace(prefix,Region{});
                    else info.prefix_budget_reached=true;
                }
                if(depth<path.size())prefix.push_back(path[depth]);
            }
            ++info.sampled_positions;
            slot=(slot+stride)%samples;
        }
        phase("region_discovered_prefixes",result.size());
    }
    PhaseProgress physical_progress("region_physical_paths",physical.size());
    for(size_t i=0;i<physical.size();++i) {
        auto path=index.path(physical[i]);std::vector<uint64_t> prefix;
        info.depth_censored=info.depth_censored||path.size()+1>depth_limit;
        for(size_t depth=0;depth<=path.size()&&depth<depth_limit;++depth) {
            auto it=result.find(prefix);
            if(it==result.end()&&!info.bounded)it=result.emplace(prefix,Region{}).first;
            if(it!=result.end()) {
                auto& r=it->second;r.begin=std::min(r.begin,i);r.end=std::max(r.end,i+1);++r.physical_count;
            }
            if(depth<path.size()) prefix.push_back(path[depth]);
        }
        physical_progress.tick(i+1);
    }
    PhaseProgress query_progress("region_query_work",queries.size());
    for(size_t i=0;i<queries.size();++i) {
        auto path=index.path(queries[i]);std::vector<uint64_t> prefix;
        double query_cost=0;
        if(!work.empty()) query_cost=work.at(i);
        else {
            bool found=false;auto value=const_cast<Native&>(index).lookup(queries[i],found);
            if(!found)throw std::runtime_error("Compact probe query absent");
            double route=0,local=0;uint64_t visits=0;
            query_cost=const_cast<Native&>(index).probe(queries[i],value,route,local,visits);
        }
        for(size_t depth=0;depth<=path.size()&&depth<depth_limit;++depth) {
            auto it=result.find(prefix);
            if(it!=result.end()) {auto& r=it->second;++r.original_count;r.work_mass+=query_cost;}
            else if(!info.bounded)throw std::runtime_error("Original query native region absent");
            if(depth<path.size()) prefix.push_back(path[depth]);
        }
        query_progress.tick(i+1);
    }
    for(const auto& pair:result) if(pair.second.end-pair.second.begin!=pair.second.physical_count)
        throw std::runtime_error("Native subtree keys not contiguous; cannot propose an SSE region");
    info.discovered_prefix_count=result.size();
    if(metadata)*metadata=info;
    return result;
}
static void trim_regions(Regions& regions,size_t limit,size_t min_keys,size_t max_keys) {
    // Reporting only: query work was computed over EVERY original query before
    // this metadata filter. Keep root even if it exceeds the proposal size cap.
    if(limit==SIZE_MAX&&min_keys==0&&max_keys==SIZE_MAX)return;
    using Iterator=Regions::const_iterator;
    std::vector<Iterator> candidates;
    for(auto it=regions.cbegin();it!=regions.cend();++it) {
        const auto& r=it->second;
        if(!it->first.empty()&&r.original_count&&r.physical_count>=min_keys&&r.physical_count<=max_keys)
            candidates.push_back(it);
    }
    auto order=[](Iterator a,Iterator b) {
        if(a->second.work_mass!=b->second.work_mass)return a->second.work_mass>b->second.work_mass;
        if(a->first.size()!=b->first.size())return a->first.size()>b->first.size();
        if(a->second.begin!=b->second.begin)return a->second.begin<b->second.begin;
        if(a->second.end!=b->second.end)return a->second.end<b->second.end;
        return a->first<b->first;
    };
    const size_t keep=std::min(limit,candidates.size());
    if(keep<candidates.size())std::partial_sort(candidates.begin(),candidates.begin()+keep,candidates.end(),order);
    else std::sort(candidates.begin(),candidates.end(),order);
    Regions retained;
    const auto root=regions.find(std::vector<uint64_t>{});
    if(root!=regions.end())retained.insert(*root);
    for(size_t i=0;i<keep;++i)retained.insert(*candidates[i]);
    phase("region_report_before_trim",regions.size());
    regions.swap(retained);
    phase("region_report_after_trim",regions.size());
}
static void emit_regions(const Regions& regions) {
    std::cout<<'[';bool first=true;
    for(const auto& pair:regions) {
        if(!first)std::cout<<',';first=false;
        std::cout<<"{\"id\":\"root";
        for(auto slot:pair.first)std::cout<<'/'<<slot;
        std::cout<<"\",\"depth\":"<<pair.first.size()+1<<",\"begin\":"<<pair.second.begin
                 <<",\"end\":"<<pair.second.end<<",\"original_count\":"<<pair.second.original_count
                 <<",\"work_mass\":"<<pair.second.work_mass<<'}';
    }
    std::cout<<']';
}
int main(int argc,char** argv) {
    try {
        if(argc%2!=1) throw std::runtime_error("Options require --name value pairs");
        Args args;for(int i=1;i<argc;i+=2) {
            if(std::string(argv[i]).rfind("--",0)!=0 || !args.emplace(argv[i],argv[i+1]).second)
                throw std::runtime_error("Duplicate or invalid option");
        }
        auto mode=get(args,"--mode","inspect");
#ifdef OP_INSPECT
        if(mode!="inspect") throw std::runtime_error("Use occupancy_*_resident for uninstrumented resident timing");
#else
        if(mode!="resident") throw std::runtime_error("Use occupancy_*_inspect for structural root inspection");
#endif
        phase("load_start");
        auto real=load(args.at("--real")),physical=load(get(args,"--physical",args.at("--real")));
        validate(real);validate(physical);
        auto values=records(physical,real);
        auto queries=args.count("--queries")?load(args.at("--queries")):real;
        phase("load_complete",physical.size());
        const size_t original_count=real.size(),physical_count=physical.size();
        const bool complete_passes=get(args,"--complete-passes","0")=="1";
        if(queries.empty()) throw std::runtime_error("No original queries");
        std::vector<uint64_t> expected;expected.reserve(queries.size());
        phase("query_payloads_start",queries.size());
        if(!args.count("--queries")) {
            // The implicit query corpus is exactly sorted `real`; avoid n
            // redundant binary searches without changing rank+1 payloads.
            for(size_t i=0;i<queries.size();++i)expected.push_back(uint64_t(i)+1);
        } else for(auto key:queries) {
            auto it=std::lower_bound(real.begin(),real.end(),key);
            if(it==real.end() || *it!=key) throw std::runtime_error("Queries must be original keys, not shadow keys");
            expected.push_back(uint64_t(it-real.begin())+1);
        }
        phase("query_payloads_complete",queries.size());
        phase("build_start",values.size());
        const auto build_start=now_ns();op_ledger::enabled=true;
        auto execution=get(args,"--execution","bulk");
        if(execution!="bulk"&&execution!="local") throw std::runtime_error("Invalid execution backend");
        std::unique_ptr<Native> index;
        size_t local_repairs=0;
        if(execution=="local") {
#if defined(OP_LIPP) || defined(OP_ALEX)
            index=std::make_unique<Native>(records(real,real));
            std::vector<Record> shadows;
            for(auto value:values)if(value.second==0)shadows.push_back(value);
            local_repairs=index->index.op_local_replace(shadows);
#ifdef OP_ALEX
            index->height_cache=index->index.op_height();
            index->reported_cache=index->index.model_size()+index->index.data_size();
#endif
#else
            throw std::runtime_error("Local subtree replacement currently supports LIPP/ALEX only; no bulk fallback");
#endif
        } else index=std::make_unique<Native>(values);
        op_ledger::enabled=false;
        auto build_ns=now_ns()-build_start;
        const auto retained_bytes=op_ledger::live,peak_build_bytes=op_ledger::peak;
        phase("build_complete",values.size());
        PhaseProgress validation_progress("validate_physical_payloads",values.size());
        size_t validated_records=0;
        for(auto record:values) {
            bool found=false;auto value=index->lookup(record.first,found);
            if(!found || value!=record.second) throw std::runtime_error("Physical original/shadow payload validation failed");
            validation_progress.tick(++validated_records);
        }
        double cost=0,route=0,local=0,node_visits=0,throughput=0,elapsed_seconds=0;
        uint64_t checksum=0,operations=0;
        std::vector<double> query_work;
        Regions regions;RegionMetadata region_metadata;
        struct ProposalTile {size_t begin,end;double work=0,route=0,local=0;};
        std::vector<ProposalTile> proposal_tiles;
        std::vector<uint64_t> query_nodes;
        std::vector<int64_t> slots,frozen_slots;
        bool frozen_has_model=false;uint64_t frozen_capacity=0;
        if(mode=="inspect") {
            const bool per_query=get(args,"--emit-per-query","0")=="1";
            const size_t tile_keys=std::stoull(get(args,"--proposal-tile-keys","0"));
            if(tile_keys && args.count("--queries"))
                throw std::runtime_error("Exact proposal tiles require the implicit full original-key corpus");
            if(tile_keys) for(size_t begin=0;begin<queries.size();) {
                const size_t end=begin+std::min(tile_keys,queries.size()-begin);
                proposal_tiles.push_back({begin,end});begin=end;
            }
            if(per_query) {query_work.reserve(queries.size());query_nodes.reserve(queries.size());}
            PhaseProgress probe_progress("probe_original_queries",queries.size());
            for(size_t i=0;i<queries.size();++i) {
                double r=0,l=0;uint64_t v=0;double c=index->probe(queries[i],expected[i],r,l,v);
                cost+=c;route+=r;local+=l;node_visits+=v;
                if(tile_keys) {auto& tile=proposal_tiles[i/tile_keys];tile.work+=c;tile.route+=r;tile.local+=l;}
                if(per_query) {query_work.push_back(c);query_nodes.push_back(v);}
                probe_progress.tick(i+1);
            }
            cost/=queries.size();route/=queries.size();local/=queries.size();node_visits/=queries.size();
            if(per_query || get(args,"--emit-regions","0")=="1") {
                const size_t region_limit=std::stoull(get(args,"--region-report-limit",std::to_string(SIZE_MAX)));
                const size_t region_min=std::stoull(get(args,"--region-min-keys","0"));
                const size_t region_max=std::stoull(get(args,"--region-max-keys",std::to_string(SIZE_MAX)));
                if(region_min>region_max)throw std::runtime_error("Region minimum exceeds maximum");
                auto multiple=[](size_t n,size_t factor) {return n>SIZE_MAX/factor?SIZE_MAX:n*factor;};
                const size_t default_budget=region_limit==SIZE_MAX?SIZE_MAX:std::max<size_t>(64,multiple(region_limit,16));
                const size_t default_samples=region_limit==SIZE_MAX?0:std::max<size_t>(64,multiple(region_limit,4));
                regions=collect_regions(*index,physical,queries,query_work,
                    std::stoull(get(args,"--region-depth-limit",std::to_string(SIZE_MAX))),
                    std::stoull(get(args,"--region-prefix-budget",std::to_string(default_budget))),
                    std::stoull(get(args,"--region-discovery-samples",std::to_string(default_samples))),&region_metadata);
                trim_regions(regions,region_limit,region_min,region_max);
                region_metadata.reported_prefix_count=regions.size();
            }
            if(get(args,"--omit-root-slots","0")!="1")slots=root_slots(*index,physical);
            auto reference=get(args,"--frozen-slots-from",get(args,"--reference-physical",""));
            if(!reference.empty()) {
                auto reference_keys=load(reference);validate(reference_keys);
                // Frozen diagnostics require the same original-key population;
                // reference can contain other shadows but cannot omit originals.
                auto ref_values=records(reference_keys,real);
                Native fixed(ref_values);frozen_has_model=fixed.has_model();frozen_capacity=fixed.capacity();
                frozen_slots=root_slots(fixed,physical);
            }
        }
        auto measure=[&](double seconds,double warmup) {
            if(!std::isfinite(seconds) || seconds<=0 || !std::isfinite(warmup) || warmup<0)
                throw std::runtime_error("Invalid resident measurement seconds");
            auto loop=[&](double duration,bool measured) {
                const auto start=now_ns(),end=start+uint64_t(duration*1e9);size_t cursor=0;uint64_t count=0,sum=0;
                if(complete_passes&&(measured||duration>0)) {
                    do {
                        for(size_t i=0;i<queries.size();++i) {
                            bool found=false;auto value=index->lookup(queries[i],found);sum+=value;
                        }
                        count+=queries.size();
                    }while(now_ns()<end);
                    if(measured){operations=count;checksum=sum;elapsed_seconds=double(now_ns()-start)/1e9;}
                    return;
                }
                while(now_ns()<end) {
                    for(size_t j=0;j<256;++j) {
                        bool found=false;auto value=index->lookup(queries[cursor],found);
                        sum+=value;if(++cursor==queries.size()) cursor=0;
                    }
                    count+=256;
                }
                if(measured) {operations=count;checksum=sum;elapsed_seconds=double(now_ns()-start)/1e9;}
            };
            loop(warmup,false);loop(seconds,true);throughput=double(operations)/elapsed_seconds;
        };
        uint64_t population_checksum=0;for(auto value:expected) population_checksum+=value;
        if(mode=="resident") {
            // Timed lookups need only the native index and shuffled queries.
            std::vector<Record>().swap(values);std::vector<Key>().swap(real);
            std::vector<Key>().swap(physical);std::vector<uint64_t>().swap(expected);
        }
        auto emit=[&](const char* prefix) {
        std::cout<<std::setprecision(17)<<prefix<<" {\"success\":true,\"index\":\""<<Native::name<<"\",\"mode\":\""<<mode
                 <<"\",\"real_count\":"<<original_count<<",\"physical_count\":"<<physical_count<<",\"shadow_count\":"<<physical_count-original_count
                 <<",\"n0\":"<<original_count<<",\"queries_correct\":true,\"all_real_correct\":true,\"all_shadow_correct\":true"
                 <<",\"query_checksum\":\""<<population_checksum<<"\""
                 <<",\"query_count\":"<<queries.size()<<",\"root_capacity\":"<<index->capacity()
                 <<",\"root_has_model\":"<<(index->has_model()?"true":"false")
                 <<",\"root_model\":{\"slope\":\""<<index->slope()<<"\",\"intercept\":\""
                 <<std::setprecision(std::numeric_limits<long double>::max_digits10)<<index->intercept()<<"\"}"
                 <<std::setprecision(17)<<",\"key_origin\":\""<<index->origin<<"\",\"cost_work\":"<<cost
                 <<",\"route_work\":"<<route<<",\"local_work\":"<<local<<",\"mean_node_visits\":"<<node_visits
                 <<",\"total_bytes\":"<<retained_bytes<<",\"native_reported_bytes\":"<<index->reported_bytes()
                 <<",\"peak_build_bytes\":"<<peak_build_bytes<<",\"node_count\":"<<index->nodes()
                 <<",\"build_time_ms\":"<<double(build_ns)/1e6
                 <<",\"execution\":\""<<execution<<"\",\"local_replacements\":"<<local_repairs
                 <<",\"memory_scope\":\"retained native requested allocation bytes, includes native wrapper/index object; excludes input arrays, allocator overhead\""
                 <<",\"capacity_only_control_supported\":false,\"physical_correctness\":true"
                 <<",\"has_structural_cost\":"<<(mode=="inspect"?"true":"false")
                 <<",\"throughput\":"<<throughput<<",\"operations\":"<<operations<<",\"elapsed_seconds\":"<<elapsed_seconds
                 <<",\"complete_passes_required\":"<<(complete_passes?"true":"false")
                 <<",\"completed_query_passes\":"<<operations/queries.size()
                 <<",\"all_queries_covered\":"<<(operations>=queries.size()?"true":"false")
                 <<",\"checksum\":\""<<checksum<<"\",\"root_slots\":";array(slots);
        std::cout<<",\"query_work\":";array(query_work);std::cout<<",\"query_node_visits\":";array(query_nodes);
#ifdef OP_PGM
        std::cout<<",\"index_variant\":\"static_PGM_e64_recursive4_sorted_record_array\",\"pgm_epsilon\":64,\"pgm_epsilon_recursive\":4"
                 <<",\"index_height\":"<<index->index.height()<<",\"leaf_segments\":"<<index->index.segments_count();
#elif defined(OP_ALEX)
        std::cout<<",\"index_variant\":\"GRE_ALEX_native_defaults\",\"index_height\":"<<index->height_cache;
#endif
        std::cout<<",\"regions\":";emit_regions(regions);
        std::cout<<",\"proposal_tiles\":[";
        for(size_t i=0;i<proposal_tiles.size();++i) {
            const auto& tile=proposal_tiles[i];if(i)std::cout<<',';
            std::cout<<"{\"id\":\"tile:"<<tile.begin<<':'<<tile.end
                     <<"\",\"begin\":"<<tile.begin<<",\"end\":"<<tile.end
                     <<",\"left\":\""<<queries[tile.begin]<<"\",\"right\":\""<<queries[tile.end-1]
                     <<"\",\"original_count\":"<<tile.end-tile.begin
                     <<",\"work_mass\":"<<tile.work<<",\"route_mass\":"<<tile.route
                     <<",\"local_mass\":"<<tile.local
                     <<",\"kind\":\"original_rank_proposal_tile\",\"counts_scope\":\"all_original_queries\"}";
        }
        std::cout<<']';
        std::cout<<",\"region_metadata\":{\"discovery\":\""
                 <<(region_metadata.bounded?"rank_stratified_bounded_native_prefixes":"all_native_prefixes")
                 <<"\",\"censored\":"<<((region_metadata.bounded||region_metadata.depth_censored||
                     region_metadata.reported_prefix_count<region_metadata.discovered_prefix_count)?"true":"false")
                 <<",\"sampled_positions\":"<<region_metadata.sampled_positions
                 <<",\"prefix_budget\":"<<region_metadata.prefix_budget
                 <<",\"prefix_budget_reached\":"<<(region_metadata.prefix_budget_reached?"true":"false")
                 <<",\"depth_censored\":"<<(region_metadata.depth_censored?"true":"false")
                 <<",\"discovered_prefix_count\":"<<region_metadata.discovered_prefix_count
                 <<",\"reported_prefix_count\":"<<region_metadata.reported_prefix_count
                 <<",\"counts_scope\":\"all physical keys and original queries; discovery only selects reportable regions\"}";
        std::cout<<",\"frozen_root_has_model\":"<<(frozen_has_model?"true":"false")<<",\"frozen_root_capacity\":"<<frozen_capacity
                 <<",\"frozen_root_slots\":";array(frozen_slots);std::cout<<"}\n"<<std::flush;
        };
        if(mode=="inspect") emit("RESULT_JSON");
        else if(args.count("--seconds")) {
            measure(std::stod(args.at("--seconds")),std::stod(get(args,"--warmup","0.25")));
            emit("RESULT_JSON");
        } else {
            emit("READY_JSON");
            std::string line;
            while(std::getline(std::cin,line)) {
                if(line=="quit" || line=="QUIT") break;
                std::istringstream command(line);double seconds=0,warmup=0;std::string extra;
                if(!(command>>seconds>>warmup) || command>>extra)
                    throw std::runtime_error("Resident command must be '<seconds> <warmup>' or quit");
                measure(seconds,warmup);emit("RESULT_JSON");
            }
        }
        return 0;
    } catch(const std::exception& e) {std::cerr<<"FAILED: "<<e.what()<<'\n';return 8;}
}
