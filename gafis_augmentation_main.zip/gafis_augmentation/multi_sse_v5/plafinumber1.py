"""Canonical full-population input preparation."""
import hashlib
from pathlib import Path
import numpy as np
from multi_sse_v5 import driver as d, storage
REAL15=('books','covid','eth','fb','genome','gnomad','history','libio','osm','planet','planetways','rev','stack','wiki','wise')


def header_info(path):
    path = Path(path).resolve()
    stat = path.stat()
    if stat.st_size < 8 or (stat.st_size - 8) % 8:
        raise ValueError('Invalid GRE UInt64 count-header file: ' + str(path))
    with path.open('rb') as handle:
        count = int.from_bytes(handle.read(8), 'little')
    available = (stat.st_size - 8) // 8
    if not 0 < count <= available:
        raise ValueError('Truncated/invalid GRE count header: ' + str(path))
    return dict(path=str(path), bytes=stat.st_size, mtime_ns=stat.st_mtime_ns, declared_keys=count, available_records=available, ignored_tail_records=available - count)

def input_directory(out, scratch, dataset):
    root = Path(scratch).resolve() / ('plafinumber1_' + hashlib.sha256(str(Path(out).resolve()).encode()).hexdigest()[:20])
    owner = root / 'OWNER.json'
    expected = dict(batch_out=str(Path(out).resolve()), role='regenerable full-key inputs only')
    if owner.exists() and d.read(owner) != expected:
        raise ValueError('Input scratch owner mismatch')
    d.write(owner, expected)
    folder = (root / dataset).resolve()
    if folder.parent != root or dataset not in REAL15:
        raise ValueError('Invalid owned input target')
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def prepare_input(job):
    import inputs
    out = Path(job['batch_out'])
    cfg = job['config']
    dataset = job['dataset']
    folder = input_directory(out, cfg['scratch_dir'], dataset)
    record_path = out / 'input_records' / (dataset + '.json')
    raw = folder / 'original.bin'
    expected = d.read(record_path) if record_path.exists() else None
    if header_info(job['source_header']['path']) != job['source_header']:
        raise ValueError('Source dataset changed after planning')
    if raw.is_file() and expected:
        if raw.stat().st_size == expected['unique_count'] * 8 and d.digest(raw) == expected['original_sha256']:
            print('[INPUT REUSE]', dataset, 'n=' + str(expected['unique_count']), flush=True)
            return expected
        raise ValueError('Generated canonical input changed')
    print('[INPUT CANONICALIZE]', dataset, 'full_count=' + str(job['source_header']['declared_keys']), flush=True)
    (values, origin) = inputs.ordered_source(job['source_header']['path'], cache_dir=folder / 'sort_cache')
    temporary = folder / 'original.partial'
    storage.ensure_space(folder, len(values) * 8)
    hasher = hashlib.sha256()
    count = 0
    previous = None
    with temporary.open('wb') as handle:
        for begin in range(0, len(values), 1000000):
            block = np.asarray(values[begin:begin + 1000000], dtype='<u8')
            keep = np.empty(len(block), dtype=bool)
            keep[0] = previous is None or int(block[0]) != previous
            keep[1:] = block[1:] != block[:-1]
            chunk = block[keep]
            if len(chunk) and int(chunk[-1]) == 2 ** 64 - 1:
                raise ValueError('Dataset contains reserved UINT64_MAX sentinel; no silent key removal')
            chunk.tofile(handle)
            hasher.update(memoryview(chunk).cast('B'))
            count += len(chunk)
            previous = int(block[-1])
    if hasattr(values, '_mmap'):
        values._mmap.close()
    if count < 3:
        raise ValueError('Fewer than three unique supported original keys')
    temporary.replace(raw)
    info = dict(dataset=dataset, source_header=job['source_header'], unique_count=count, original_path=str(raw), original_sha256=hasher.hexdigest(), input_semantics='all declared keys sorted and deduplicated; no window or thinning', ignored_tail_records=job['source_header']['ignored_tail_records'], source_order=origin['source_order'], canonicalization=origin['canonicalization'], untimed_queries='same canonical array, every original key once', timed_queries='separately frozen sampled original-key cohorts')
    if expected and expected != info:
        raise ValueError('Regenerated full input/provenance changed')
    d.write(record_path, info)
    print('[INPUT READY]', dataset, 'unique_keys=' + str(count), 'no shuffled full-query copy', flush=True)
    return info

def is_within_directory(path, directory):
    """Resolved containment without Path.is_relative_to (Python >=3.9).

    relative_to raises for a different directory/drive. A string prefix check
    would incorrectly accept sibling paths such as books_other under books.
    """
    try:
        Path(path).resolve().relative_to(Path(directory).resolve())
    except ValueError:
        return False
    return True

def cleanup_generated_inputs(a, dataset):
    if a.keep_generated_inputs:
        return
    out = a.out.resolve()
    folder = input_directory(out, a.scratch_dir, dataset)
    root = folder.parent
    owner = d.read(root / 'OWNER.json')
    if owner.get('batch_out') != str(out) or folder.parent != root or dataset not in REAL15:
        raise ValueError('Refuse cleanup outside exact owned dataset scratch')
    removed = []
    paths = [folder / 'original.bin', folder / 'original.partial']
    cache = folder / 'sort_cache'
    if cache.is_dir():
        paths += list(cache.iterdir())
    for path in paths:
        if path.is_symlink():
            raise ValueError('Refuse generated-input symlink cleanup')
        if path.is_file():
            if not is_within_directory(path, folder):
                raise ValueError('Refuse generated-input cleanup outside owned directory')
            if path.parent not in (folder, cache):
                raise ValueError('Unexpected cleanup path')
            size = path.stat().st_size
            path.unlink()
            removed.append(dict(path=str(path), bytes=size))
    d.append(out / 'input_cleanup.jsonl', dict(dataset=dataset, files=removed, deleted_original_dataset=False, recoverable_by_exact_regeneration=True))
    print('[INPUT RELEASE]', dataset, 'bytes=' + str(sum((r['bytes'] for r in removed))), 'generated arrays only; datasets and results retained', flush=True)
