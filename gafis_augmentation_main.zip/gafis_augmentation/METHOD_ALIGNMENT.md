# Correspondence with the method and algorithm

| Manuscript mechanism | Implementation |
|---|---|
| Three-term global J with original n-2 | `costsearch/weights.py` |
| Fixed stratified native operation counts | `finalopt/native.cpp`, `sampling.py`, `cost.py` |
| Original-index positive calibration and held-out blocks | `finalopt/calibration.py` |
| Shared weight pool and full-pool champions | `costsearch/search.py:select_parents` |
| Parent batch fixed before each round | `costsearch/search.py:adaptive_search` |
| Native routing-prefix region boundaries | `finalopt/native.cpp`, `prepare_native.py` |
| Left-endpoint gap ownership and bounded allocation | `finalopt/proposals.py` |
| Add / Remove / Reallocate / Relocate | `costsearch/search.py:proposal_recipes`, `OperationEngine` |
| Feasible, uncached candidates receive full construction | `finalopt/driver.py:CaseSearch.trial` |
| Every valid state retained, including non-improving states | `CaseSearch.trial`, `adaptive_search` |
| Exhausted champions / no new valid state / resource limits | `adaptive_search` |
| Minimum J per weight after search | `record_policies` |
| Final correctness and timing separate from search | `costsearch/measurement.py` |

## Small manuscript corrections needed

1. The supplied pseudocode marks a parent in X before expansion, but the prose
   defines X as completed expansions. Move that line after the parent's recipe
   loop. The supplied `algorithm.tex` makes this single consistency correction.
   An interrupted batch remains pending; completed native evaluations are reused.

2. The implemented estimator is exclusively the calibrated native-operation
   estimator. Replace the mixed operation/structural-estimator description with:

   > Lookup cost is estimated from index-specific native operation counts. Positive
   > execution costs are initialized by independent microbenchmarks and fitted to
   > original-index lookup blocks with a fixed penalty toward those costs.
   > Held-out blocks assess calibration error. The resulting coefficients remain
   > fixed throughout the search.

   PGM uses three groups of tied prices to reduce confounding among correlated
   counts; the per-key cost remains an eight-counter weighted sum. For validation
   fixtures with too few independent calibration blocks, the measured prior costs
   are retained and the fallback is explicitly recorded.

3. After removing distribution-based refinement, regional GaFiS attribution is
   unnecessary. Use this implementation wording:

   > Merging sorted original and auxiliary keys computes U in O(n+|V'|) time with
   > an O(1) global accumulator. Regional lookup profiles and allocation metadata
   > use O(|P_j|) space; coordinate generation requires additional working arrays.

4. Feasibility screening checks legality and duplication only. It does not compute
   a proposal objective, rank candidates, reserve a shortlist, or reject a valid
   candidate because its estimated benefit is poor.

5. GaFiS acts through J and the resulting weight-wise parent choices. Regional
   allocation and Gap/SSE coordinate generation do not contain an additional
   GaFiS refinement term. Final native cost/profile feedback closes the loop.

The structural routing profile is retained for partitioning and candidate
construction. This is distinct from a structural predictor of lookup cost.

## Main-experiment measurement scope

The ordered 45-pair grid remains active during search. Measurement fixes the
original index and the designated minimum-J endpoint before any timing.
Other weight endpoints are recorded but are not timed. The designated weight
pairs are unchanged from the source package. There are no separate ablation,
structural-estimator, correlation, or placement-control benchmark runs.
