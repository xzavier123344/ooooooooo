"""Validate the artifact on a generated fixture, not a performance benchmark."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-build',action='store_true')
    parser.add_argument('--compiler')
    options=parser.parse_args()
    if not options.skip_build:
        command=[sys.executable,'build.py','--indices','alex,lipp,pgm']
        if options.compiler: command+=['--compiler',options.compiler]
        subprocess.run(command,cwd=ROOT,check=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-t','.','-v'],cwd=ROOT,check=True)
    with tempfile.TemporaryDirectory(prefix='gafis_verify_') as directory:
        work=Path(directory);n=32768
        rng=np.random.default_rng(1729)
        keys=np.cumsum(rng.integers(2,50,n,dtype=np.uint64),dtype=np.uint64)+np.uint64(100)
        np.r_[np.uint64(n),keys].astype('<u8').tofile(work/'keys.bin')
        (work/'datasets.csv').write_text('dataset,path\nbooks,keys.bin\n',encoding='utf-8')
        command=[sys.executable,'-m','costsearch.search','run','--out',str(work/'output'),
            '--datasets-file',str(work/'datasets.csv'),'--scratch-dir',str(work/'scratch'),
            '--indices','alex,lipp,pgm','--rounds','2','--parents','2','--native-cap','12',
            '--sample-count','24576','--validation-count','1024','--strata','16',
            '--region-max-keys','2048','--calibration-mib','1','--builds','1','--repeats','2',
            '--seconds','0.05','--warmup','0.01','--query-count','1024','--policy-timing-limit','1',
            '--case-seconds','300','--timeout','120','--proposal-timeout','60']
        subprocess.run(command,cwd=ROOT,check=True)
        checks={}
        presets=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))['indices']
        for index,preset in presets.items():
            pairs=len(preset['space_grid'])*len(preset['gafis_grid'])
            folder=work/'output'/'books'/index
            policies=json.loads((folder/'parameter_selections.json').read_text())
            calibration=json.loads((folder/'index_calibration.json').read_text())
            summary=json.loads((folder/'timing'/'independent_build_summary.json').read_text())
            assert len(policies)==pairs
            assert all(row['J']<=1e-12 for row in policies)
            assert calibration['original_index_only'] is True
            assert summary['all_builds_complete'] is True
            assert summary['full_validation']['all_original_keys_verified'] is True
            checks[index]=dict(weight_pairs=pairs,original_calibration=True,full_correctness=True,independent_timing=True)
        print(json.dumps(dict(validation_only=True,checks=checks),indent=2))


if __name__=='__main__': main()
