"""Shared-pool selection and exact fixed-space GaFiS-weight choice intervals."""
import math


def _number(value, name, positive=False):
    value = float(value)
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError("Invalid " + name)
    return value


def _cost(row, cost_key):
    return _number(row[cost_key], "query cost", positive=True)


def fixed_score(row):
    if "plafi_raw_fixed" in row:
        score = _number(row["plafi_raw_fixed"], "fixed GaFiS")
    elif "gafis_fixed" in row:
        score = _number(row["gafis_fixed"], "fixed GaFiS")
    else:
        n = int(row["n0"])
        if n < 3:
            raise ValueError("Original population must contain at least three keys")
        score = _number(row.get("gafis_u", row.get("unnormalized_u")), "U")/(n-2)
    if score < 0:
        raise ValueError("GaFiS is nonnegative")
    return score


def components(row, base, cost_key="estimated_cost_ns"):
    return dict(query_component=math.log(_cost(row, cost_key)/_cost(base, cost_key)),
                space_component=math.log(_number(row["total_bytes"], "space", True)/
                                         _number(base["total_bytes"], "baseline space", True)),
                gafis_component=math.log1p(fixed_score(row))-math.log1p(fixed_score(base)))


def score(row, base, gamma_space, gamma_gafis, cost_key="estimated_cost_ns"):
    gs, gg = _number(gamma_space, "gamma_space"), _number(gamma_gafis, "gamma_gafis")
    if gs < 0 or gg < 0:
        raise ValueError("Tradeoff weights must be nonnegative")
    terms = components(row, base, cost_key)
    terms.update(weighted_space=gs*terms["space_component"],
                 weighted_gafis=gg*terms["gafis_component"],
                 gamma_space=gs, gamma_gafis=gg)
    terms["J"] = terms["query_component"]+terms["weighted_space"]+terms["weighted_gafis"]
    return terms


def _identity(row):
    return str(row.get("state_id", row.get("candidate_id", "")))


def choose(rows, base, gamma_space, gamma_gafis, cost_key="estimated_cost_ns"):
    if not rows:
        raise ValueError("Candidate pool is empty")
    return min(rows, key=lambda row: (score(row, base, gamma_space, gamma_gafis, cost_key)["J"],
                                      int(row["total_bytes"]), int(row["k"]), _identity(row)))


def grid_selections(rows, base, gamma_space, gamma_gafis, cost_key="estimated_cost_ns"):
    result = []
    for gs in gamma_space:
        for gg in gamma_gafis:
            selected = choose(rows, base, gs, gg, cost_key)
            result.append(dict(state_id=_identity(selected),
                               physical_sha256=selected.get("physical_sha256"),
                               k=int(selected["k"]), cost_model=cost_key,
                               **score(selected, base, gs, gg, cost_key)))
    return result


def winner_intervals(rows, base, gamma_space, max_gamma_gafis=32.0,
                     cost_key="estimated_cost_ns"):
    """Open-interval interiors of the lower envelope, with explicit boundaries.

    At a switching boundary choose() applies space/count/state tie-breaking.
    Isolated zero-width choices are omitted and not called robust intervals.
    """
    gs = _number(gamma_space, "gamma_space")
    maximum = _number(max_gamma_gafis, "max_gamma_gafis", True)
    if gs < 0:
        raise ValueError("gamma_space must be nonnegative")
    prepared = [(r, components(r, base, cost_key)) for r in rows]
    result = []
    for row, term in prepared:
        low, high = 0., maximum
        intercept = term["query_component"]+gs*term["space_component"]
        for other, t in prepared:
            slope = term["gafis_component"]-t["gafis_component"]
            bound = t["query_component"]+gs*t["space_component"]-intercept
            if abs(slope) < 1e-14:
                if bound < -1e-12:
                    high = -1.
                    break
            elif slope > 0:
                high = min(high, bound/slope)
            else:
                low = max(low, bound/slope)
            if low > high:
                break
        if high-low <= 1e-10:
            continue
        selected = choose(rows, base, gs, (low+high)/2, cost_key)
        if _identity(selected) != _identity(row):
            continue
        result.append(dict(state_id=_identity(row), k=int(row["k"]), gamma_space=gs,
                           gamma_gafis_low=low, gamma_gafis_high=high,
                           cost_model=cost_key, **term))
    return sorted(result, key=lambda r: r["gamma_gafis_low"])


def net_space_efficiency(throughput_ratio, space_ratio, min_extra_ratio=1e-9):
    """Normalized throughput gain per normalized added retained space."""
    throughput = _number(throughput_ratio, "throughput ratio", True)
    space = _number(space_ratio, "space ratio", True)
    extra = space-1
    dominance = throughput > 1 and space <= 1
    if extra <= min_extra_ratio:
        return dict(value=None, reason="nonpositive_or_negligible_added_space",
                    faster_and_no_larger=dominance)
    return dict(value=(throughput-1)/extra, reason=None,
                faster_and_no_larger=False)


def relative_efficiency(own_throughput, own_space, control_throughput, control_space):
    own = net_space_efficiency(own_throughput, own_space)
    control = net_space_efficiency(control_throughput, control_space)
    if own["value"] is None or control["value"] is None:
        return dict(relative_gain=None, reason="added_space_not_comparable")
    if own["value"] <= 0 or control["value"] <= 0:
        return dict(relative_gain=None, reason="nonpositive_gain_efficiency")
    return dict(relative_gain=own["value"]/control["value"]-1, reason=None)
