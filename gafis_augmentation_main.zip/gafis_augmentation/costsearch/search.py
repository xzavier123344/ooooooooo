"""Shared-weight adaptive augmentation using frozen native operation counts."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

import numpy as np
from finalopt import driver as core, proposals
from multi_sse_v5 import driver as io, plafinumber1 as inputs
from . import weights, measurement

ROOT = Path(__file__).resolve().parents[1]
PRESETS = {
    'alex': dict(space_grid=[0,.025,.05,.1,.5], gafis_grid=[0,.005,.025,.05,.1,.2,.4,1,1.5], primary=[.1,.2], sample_count=2097152, query_count=10000000),
    'lipp': dict(space_grid=[0,.025,.05,.1,.5], gafis_grid=[0,.005,.025,.05,.1,.2,.4,1,1.5], primary=[.025,.2], sample_count=1048576, query_count=4000000),
    'pgm': dict(space_grid=[0,.025,.05,.1,.5], gafis_grid=[0,.005,.025,.05,.1,.2,.4,1,1.5], primary=[.025,.025], sample_count=1048576, query_count=4000000),
}


def grid_for(preset):
    return [(float(s),float(g)) for s in preset['space_grid'] for g in preset['gafis_grid']]


def priority_weights(grid, primary):
    result=[]
    for pair in [tuple(primary),(primary[0],0.),(0.,0.)]+list(grid):
        pair=tuple(map(float,pair))
        if pair in grid and pair not in result: result.append(pair)
    return result


def select_parents(rows,base,grid,primary,expanded,limit):
    """Find full-pool champions, then skip expanded/duplicate champions."""
    parents=[]; seen=set(); decisions=[]
    for pair in priority_weights(grid,primary):
        champion=weights.choose(rows,base,*pair); sid=champion['state_id']
        action='expanded' if sid in expanded else 'duplicate' if sid in seen else 'eligible'
        decisions.append(dict(weights=list(pair),state_id=sid,action=action))
        if action=='eligible':
            seen.add(sid)
            if len(parents)<limit: parents.append(dict(state_id=sid,weights=list(pair)))
    return parents,decisions


def proposal_recipes(parent,n,ceiling,seed):
    """A fixed, bounded schedule; k always denotes the TOTAL auxiliary count."""
    k=int(parent['k']); generator=parent.get('recipe',{}).get('generator','gap')
    planned=[]
    def make(target,action,gen=generator,allocation='marginal',**extra):
        return dict(parent=parent['state_id'],target_k=int(target),action=action,
                    generator=gen,scope='hybrid',allocation=allocation,proposal_seed=seed,**extra)
    if k:
        planned.append(make(k,'relocate','sse' if generator=='gap' else 'gap','parent',preserve_regional_counts=True))
        planned.append(make(k,'reallocate',allocation='equal'))
    targets=(min(ceiling,k+max(1,int(.05*n))),min(ceiling,max(1,2*k)),k//2)
    for target in targets:
        if target==k: continue
        planned.append(make(target,'remove' if target<k else 'add'))
    seen=set();result=[]
    for item in planned:
        key=json.dumps(item,sort_keys=True)
        if key not in seen: seen.add(key);result.append(item)
    return result


class OperationEngine(core.CaseSearch):
    """A candidate is generated, checked and deduplicated before native build."""
    def generate(self,recipe,dest):
        if recipe.get('preserve_regional_counts'):
            parent=self.by_id[recipe['parent']]
            regions=io.read(parent['regions_path'])
            parts=proposals.segments(self.case['real_path'],regions,'hybrid')
            original=np.memmap(self.case['real_path'],dtype='<u8',mode='r')
            old=np.memmap(self.ensure_points(parent),dtype='<u8',mode='r')
            try:
                counts=[int(np.searchsorted(old,original[p['gap_end']],side='left')-
                            np.searchsorted(old,original[p['gap_begin']],side='left')) for p in parts]
            finally:
                original._mmap.close();old._mmap.close()
            if sum(counts)!=int(recipe['target_k']): raise ValueError('Relocate changed total count')
            report=proposals.generate(self.case['real_path'],regions,recipe['target_k'],Path(dest)/'proposal',
                generator=recipe['generator'],scope='hybrid',allocation='marginal',
                regional_counts=counts,timeout=self.a.proposal_timeout,seed=recipe['proposal_seed'])
            out=Path(dest)/'shadows.bin';Path(report['points_path']).replace(out)
            return out
        return super().generate(recipe,dest)

    def trial(self,recipe,role):
        if recipe.get('action')!='original' and int(recipe['target_k'])==0:
            return next(r for r in self.rows if r['role']=='original')
        row=super().trial(recipe,role)
        if row:
            Path(row['costs_path']).unlink(missing_ok=True)
        return row


def adaptive_search(engine,a,grid,primary):
    """Checkpoint each recipe; freeze the round's parents before expansion."""
    path=engine.folder/'search_checkpoint.json'
    identity=dict(grid=[list(p) for p in grid],primary=list(primary),rounds=a.rounds,
                  parents=a.parents,max_fraction=a.max_fraction,seed=a.seed)
    checkpoint=io.read(path) if path.exists() else dict(identity=identity,round=0,expanded=[],current=None,trace=[],finished=False)
    if checkpoint['identity']!=identity: raise ValueError('Search settings changed; use a new output')
    if checkpoint['finished']: return checkpoint['status']
    expanded=set(checkpoint['expanded']); stop=None
    base=next(r for r in engine.rows if r['role']=='original')
    def save():
        checkpoint['expanded']=sorted(expanded);io.write(path,checkpoint)
        io.write(engine.folder/'search_clock.json',dict(elapsed_seconds=engine.prior_elapsed+time.monotonic()-engine.started))
    while checkpoint['round']<a.rounds:
        turn=checkpoint['round']
        if checkpoint['current'] is None:
            parents,decisions=select_parents(engine.rows,base,grid,primary,expanded,a.parents)
            if not parents: stop='no_unexpanded_weight_champion';break
            if not engine.allowed(): stop='resource_limit';break
            checkpoint['current']=dict(parents=parents,decisions=decisions,pool_before=len(engine.rows),
                                       parent_index=0,recipes=None,recipe_index=0)
            save()
        current=checkpoint['current']
        while current['parent_index']<len(current['parents']):
            context=current['parents'][current['parent_index']]
            parent=engine.by_id[context['state_id']]
            if current['recipes'] is None:
                current['recipes']=proposal_recipes(parent,int(engine.case['n0']),int(a.max_fraction*engine.case['n0']),a.seed)
                current['recipe_index']=0;save()
            while current['recipe_index']<len(current['recipes']):
                if not engine.allowed(): stop='resource_limit';break
                recipe=current['recipes'][current['recipe_index']]
                engine.trial(recipe,'adaptive_round_'+str(turn))
                current['recipe_index']+=1;save()
            if stop: break
            # X records COMPLETED bounded expansions; interrupted work is pending.
            expanded.add(parent['state_id'])
            current['parent_index']+=1;current['recipes']=None;save()
        if stop: break
        checkpoint['trace'].append(dict(round=turn,parents=current['parents'],champion_decisions=current['decisions'],
                                        new_valid_states=len(engine.rows)-current['pool_before']))
        checkpoint['round']+=1;checkpoint['current']=None;save()
        if len(engine.rows)==current['pool_before']: stop='no_new_valid_evaluated_state';break
    if stop is None: stop='round_limit'
    native=[r['native_summary'] for r in engine.rows]
    events=io.lines(engine.folder/'overhead_events.jsonl')
    status=dict(stop=stop,rounds_completed=checkpoint['round'],expanded_states=sorted(expanded),
        evaluated_states=len(engine.rows),native_attempts=engine.attempts,
        elapsed_search_seconds=engine.prior_elapsed+time.monotonic()-engine.started,
        proposal_generation_seconds=sum(float(e['seconds']) for e in events if e['phase']=='proposal_generation'),
        feasibility_and_identity_seconds=sum(float(e['seconds']) for e in events if e['phase']=='feasibility_and_identity'),
        successful_build_seconds=sum(float(r.get('build_time_ms',0))/1000 for r in native),
        successful_profile_seconds=sum((float(r.get('region_extract_ns',0))+float(r.get('counter_features_ns',0)))/1e9 for r in native),
        cost_estimator='frozen_stratified_native_operation_counts',candidate_throughput_used=False,
        parent_selection='full_pool_weight_champions',expansion_definition='completed_bounded_recipe_batch')
    checkpoint.update(finished=True,status=status);save()
    io.write(engine.folder/'search_status.json',status);io.write(engine.folder/'search_trace.json',checkpoint['trace'])
    return status


def parse(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=('check','plan','search','measure','run','report','bundle'))
    p.add_argument('--out',type=Path,default=ROOT/'outputs/experiment')
    p.add_argument('--config',type=Path,default=ROOT/'config.json')
    p.add_argument('--datasets-file',type=Path,default=ROOT/'datasets.csv')
    p.add_argument('--datasets',default='')
    p.add_argument('--indices',default='alex,lipp,pgm')
    p.add_argument('--scratch-dir',type=Path,default=ROOT/'scratch')
    p.add_argument('--cpu',default='auto');p.add_argument('--seed',type=int,default=1729)
    p.add_argument('--rounds',type=int,default=3);p.add_argument('--parents',type=int,default=3)
    p.add_argument('--native-cap',type=int,default=64);p.add_argument('--max-fraction',type=float,default=.5)
    p.add_argument('--case-seconds',type=float,default=21600)
    p.add_argument('--timeout',type=float,default=7200);p.add_argument('--proposal-timeout',type=float,default=1800)
    p.add_argument('--region-max-keys',type=int,default=1000000)
    p.add_argument('--sample-count',type=int,default=0);p.add_argument('--validation-count',type=int,default=0)
    p.add_argument('--strata',type=int,default=4096);p.add_argument('--calibration-mib',type=int,default=128)
    p.add_argument('--builds',type=int,default=3);p.add_argument('--repeats',type=int,default=6)
    p.add_argument('--seconds',type=float,default=2);p.add_argument('--warmup',type=float,default=.25)
    p.add_argument('--query-count',type=int,default=0);p.add_argument('--policy-timing-limit',type=int,choices=(1,),default=1)
    p.add_argument('--validate-all',type=int,choices=(0,1),default=1)
    return p.parse_args(argv)


def validate(a):
    for field in ('out','config','datasets_file','scratch_dir'): setattr(a,field,getattr(a,field).resolve())
    for field in ('parents','native_cap','region_max_keys','strata','calibration_mib','builds','repeats','policy_timing_limit'):
        if getattr(a,field)<1: raise ValueError('Positive '+field+' required')
    if min(a.rounds,a.sample_count,a.validation_count,a.query_count,a.seed)<0: raise ValueError('Negative count or seed')
    for field in ('case_seconds','timeout','proposal_timeout','seconds','max_fraction','warmup'):
        value=getattr(a,field)
        if not math.isfinite(value) or value<0: raise ValueError('Invalid '+field)
    if not 0<a.max_fraction<=.5 or min(a.case_seconds,a.timeout,a.proposal_timeout,a.seconds)<=0: raise ValueError('Invalid resource limits')
    names=io.split_csv(a.indices)
    if not names or len(names)!=len(set(names)) or set(names)-set(PRESETS): raise ValueError('Invalid indices')
    return a


def configuration(a):
    config=io.read(a.config)
    for index in io.split_csv(a.indices):
        preset=config['indices'][index]
        for field in ('space_grid','gafis_grid'):
            values=preset[field]
            if not values or len(values)!=len(set(values)) or any(not math.isfinite(float(x)) or x<0 for x in values): raise ValueError('Invalid weight grid')
        if tuple(preset['primary']) not in grid_for(preset): raise ValueError('Designated weights absent from grid')
        if preset['sample_count']<1 or preset['query_count']<1: raise ValueError('Invalid query count')
    return config


def plan(a):
    rows=io.csvread(a.datasets_file)
    if not rows: raise ValueError('Populate datasets.csv before planning experiments')
    sources={r['dataset']:(a.datasets_file.parent/r['path']).resolve() for r in rows}
    if len(sources)!=len(rows): raise ValueError('Duplicate dataset names')
    names=io.split_csv(a.datasets) if a.datasets else list(sources)
    if not names or len(names)!=len(set(names)) or any(not re.fullmatch(r'[A-Za-z0-9_-]+',n) or n not in sources for n in names): raise ValueError('Invalid dataset selection')
    headers={name:inputs.header_info(sources[name]) for name in names}
    for source in sources.values():
        if a.out==source or a.out in source.parents: raise ValueError('Inputs must be outside output directory')
    settings={k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items() if k!='stage'}
    content=dict(settings=settings,configuration=configuration(a),headers=headers,source_hashes=source_hashes(),
                 binary_hashes=binary_hashes(io.split_csv(a.indices)),
                 cost_estimator='frozen_stratified_native_operation_counts',full_population_indexed=True,
                 parent_selection='full_pool_weight_champions',candidate_timing_used_for_selection=False)
    target=a.out/'experiment_plan.json'
    if target.exists() and io.read(target)!=content: raise ValueError('Frozen source or settings changed; use a new output')
    if not target.exists() and a.out.exists() and any(p.name!='RUNNING.lock' for p in a.out.iterdir()): raise ValueError('Output has no matching ownership plan')
    io.write(target,content);return content


def source_hashes():
    return {p.relative_to(ROOT).as_posix():io.digest(p) for p in sorted(ROOT.rglob('*'))
            if p.is_file() and p.suffix in {'.py','.cpp','.hpp','.h','.inc','.json','.sh'}
            and not any(x in p.relative_to(ROOT).parts for x in ('outputs','scratch','bin','__pycache__','build_logs','vendor'))}


def binary_hashes(indices):
    paths=[core.executable('finalopt_'+name) for name in indices]
    paths += [core.executable('operation_calibration'),core.executable('proposal_stream')]
    paths += [str(ROOT/'population'/'bin'/('population_stream'+('.exe' if os.name=='nt' else '')))]
    paths += [str(ROOT/'multi_sse_v5'/'bin'/('fast_'+name+'_resident'+('.exe' if os.name=='nt' else '')))
              for name in list(indices)+['google_btree']]
    return {Path(p).relative_to(ROOT).as_posix():io.digest(p) for p in paths}


def setup_engine(a,info,index,folder,preset,calibration):
    folder.mkdir(parents=True,exist_ok=True)
    sample_count=a.sample_count or preset['sample_count']
    sample=core.sampling.prepare(info['original_path'],folder/'queries',sample_count,a.validation_count or sample_count,a.strata,a.seed)
    source=folder/'source.json';io.write(source,info)
    case=dict(case_id=info['dataset']+'.'+index+'.s'+str(a.seed),dataset=info['dataset'],index=index,seed=a.seed,
        n0=info['unique_count'],real_path=info['original_path'],real_sha256=info['original_sha256'],
        queries_path=info['original_path'],queries_sha256=info['original_sha256'],query_population_sha256=info['original_sha256'],
        source_info_path=str(source.resolve()),execution='bulk',source_population_full=True)
    return OperationEngine(a,case,folder,sample,calibration)


def evaluate_seeds(engine,a):
    base=engine.trial(dict(action='original',target_k=0),'original')
    if base is None: raise RuntimeError('Original index evaluation failed')
    sizes=sorted(set(int(engine.case['n0']*f) for f in (.01,.1,a.max_fraction) if f<=a.max_fraction))
    for k in sizes:
        if k<1: continue
        for generator in ('gap','sse'):
            if not engine.allowed(): return base
            recipe=core.recipe(base,k,generator=generator)
            recipe['proposal_seed']=a.seed
            engine.trial(recipe,'seed')
    return base


def record_policies(engine,base,grid,primary):
    policies=[]
    for gs,gg in grid:
        row=weights.choose(engine.rows,base,gs,gg)
        policies.append(dict(state_id=row['state_id'],physical_sha256=row['physical_sha256'],k=row['k'],
                             is_primary=(gs,gg)==tuple(primary),**weights.score(row,base,gs,gg)))
    io.write(engine.folder/'parameter_selections.json',policies)
    io.csvwrite(engine.folder/'parameter_selections.csv',policies)
    return policies


def run_search(a):
    declaration=plan(a);a.scratch_dir.mkdir(parents=True,exist_ok=True)
    calibration_args=argparse.Namespace(**vars(a));calibration_args.calibration_file=None
    calibration=core.calibrate(calibration_args)
    for dataset,header in declaration['headers'].items():
        info=inputs.prepare_input(dict(batch_out=str(a.out),dataset=dataset,source_header=header,config=dict(scratch_dir=str(a.scratch_dir))))
        for index in io.split_csv(a.indices):
            folder=a.out/dataset/index
            preset=declaration['configuration']['indices'][index]
            engine=setup_engine(a,info,index,folder,preset,calibration)
            try:
                base=evaluate_seeds(engine,a)
                status=adaptive_search(engine,a,grid_for(preset),preset['primary'])
                record_policies(engine,base,grid_for(preset),preset['primary'])
                io.write(folder/'search_complete.json',dict(complete=True,stop=status['stop']))
            finally: engine.release_shadows()


def saved_arguments(out):
    values=io.read(out/'experiment_plan.json')['settings']
    a=argparse.Namespace(**values)
    for field in ('out','config','datasets_file','scratch_dir'): setattr(a,field,Path(getattr(a,field)))
    return a


def measurement_endpoints(rows, base, primary):
    """The main experiment times only the original and designated endpoint."""
    selected = weights.choose(rows, base, *primary)
    if selected['physical_sha256'] == base['physical_sha256']:
        return [base]
    return [base, selected]


def run_measurement(a):
    declaration=io.read(a.out/'experiment_plan.json')
    if declaration['source_hashes']!=source_hashes() or declaration['binary_hashes']!=binary_hashes(io.split_csv(a.indices)):
        raise ValueError('Sources or native binaries changed since search; use the frozen submission version')
    for dataset in declaration['headers']:
        info=io.read(a.out/'input_records'/(dataset+'.json'))
        if not Path(info['original_path']).is_file(): raise FileNotFoundError('Canonical input missing; rerun search to regenerate it')
        for index in io.split_csv(a.indices):
            folder=a.out/dataset/index
            if not (folder/'search_complete.json').exists(): raise ValueError('Search must finish before measurement')
            preset=declaration['configuration']['indices'][index]
            calibration=io.read(folder/'index_calibration.json')
            engine=setup_engine(a,info,index,folder,preset,calibration)
            policies=io.read(folder/'parameter_selections.json')
            base=next(r for r in engine.rows if r['role']=='original')
            endpoints=measurement_endpoints(engine.rows,base,preset['primary'])
            timing_args=argparse.Namespace(**vars(a));timing_args.query_count=a.query_count or preset['query_count']
            status=io.read(folder/'search_status.json')
            measurement.freeze_and_measure(engine,timing_args,endpoints,policies,status['stop'])
            io.write(folder/'measurement_complete.json',dict(complete=True,measured_physical_states=len(endpoints)))


def report(out):
    policies=[];overheads=[];timings=[]
    for path in sorted(out.glob('*/*/parameter_selections.csv')):
        for row in io.csvread(path): policies.append(dict(row,dataset=path.parents[1].name,index=path.parent.name))
    for path in sorted(out.glob('*/*/search_status.json')):
        overheads.append(dict(io.read(path),dataset=path.parents[1].name,index=path.parent.name))
    for path in sorted(out.glob('*/*/timing/independent_build_summary.csv')):
        for row in io.csvread(path): timings.append(dict(row,dataset=path.parents[2].name,index=path.parents[1].name))
    io.csvwrite(out/'all_weight_selections.csv',policies)
    io.csvwrite(out/'search_overhead.csv',overheads)
    io.csvwrite(out/'lookup_results.csv',timings)


@contextmanager
def lock(out):
    out.mkdir(parents=True,exist_ok=True);handle=(out/'RUNNING.lock').open('a+b')
    try:
        if os.name=='nt':
            import msvcrt
            handle.seek(0);handle.write(b' ');handle.flush();handle.seek(0)
            try: msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
            except OSError as error: raise RuntimeError('Another process owns this output') from error
        else:
            import fcntl
            try: fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as error: raise RuntimeError('Another process owns this output') from error
        yield
    finally: handle.close()


def bundle(out):
    import zipfile
    target=out.parent/(out.name+'_results.zip')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(out.rglob('*')):
            if path.is_file() and path.suffix not in {'.bin','.f64','.npz'} and path.name!='RUNNING.lock':
                archive.write(path,path.relative_to(out))
    print(target)


def main(argv=None):
    a=validate(parse(argv))
    if a.stage=='check':
        config=configuration(a)
        print(json.dumps(dict(weight_counts={k:len(grid_for(v)) for k,v in config['indices'].items()},
                              native_operations=core.cost.FEATURES),indent=2));return
    if a.stage=='report': report(a.out);return
    if a.stage=='bundle': bundle(a.out);return
    if a.stage=='measure':
        a=saved_arguments(a.out)
        with lock(a.out): run_measurement(a);report(a.out)
        return
    with lock(a.out):
        if a.stage=='plan': plan(a);return
        run_search(a)
        if a.stage=='run': run_measurement(a)
        report(a.out)


if __name__=='__main__': main()
