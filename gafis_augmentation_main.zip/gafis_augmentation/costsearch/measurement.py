"""Independent full-build confirmation of already frozen candidate endpoints.

The timing-only replay creates a fresh original/candidate worker set in every
build directory. It never searches keys, refits a cost model, or selects weights.
"""
import hashlib
import json
import math
import random
import re
import time
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

from .weights import net_space_efficiency


def geometric_mean(values):
    values = [float(v) for v in values]
    if not values or any(not math.isfinite(v) or v <= 0 for v in values):
        raise ValueError("Positive finite measurements required")
    return math.exp(math.fsum(math.log(v) for v in values)/len(values))


def cluster_ratio_interval(build_ratios, seed=1729):
    """Descriptive bootstrap across independent builds, never across blocks."""
    ratios = [geometric_mean(values) for _, values in sorted(build_ratios.items())]
    if len(ratios) < 3:
        return None, None
    rng = random.Random(seed)
    logs = [math.log(v) for v in ratios]
    draws = sorted(math.exp(math.fsum(rng.choice(logs) for _ in logs)/len(logs))
                   for _ in range(4000))
    return draws[99], draws[3899]


def summarize_records(states, build_records, builds, repeats):
    """Pure analysis used by tests and native replay; rejects incomplete blocks."""
    if builds < 1 or repeats < 1:
        raise ValueError("Positive build/repeat counts required")
    by_hash = defaultdict(list)
    for state in states:
        by_hash[state["physical_sha256"]].append(state)
    base = next((s for s in states if s.get("role") == "original" or int(s["k"]) == 0), None)
    if base is None:
        raise ValueError("Frozen endpoint pool lacks original state")
    base_hash = base["physical_sha256"]
    raw_by_hash = defaultdict(dict)
    for build_id in range(builds):
        records = build_records.get(build_id, [])
        for record in records:
            if record.get("status") != "ok":
                continue
            physical = record.get("physical_sha256")
            if physical not in by_hash:
                raise ValueError("Unplanned physical state in timing")
            kind = record.get("kind")
            if kind not in ("original_baseline", "variant_pair"):
                continue
            if (kind == "original_baseline") != (physical == base_hash):
                raise ValueError("Original/candidate identity mismatch")
            repeat = int(record["repeat"])
            if repeat < 0 or repeat >= repeats:
                raise ValueError("Timing repeat outside declared range")
            key = build_id, repeat
            if key in raw_by_hash[physical]:
                raise ValueError("Duplicate successful build/repeat")
            if record.get("full_dataset_indexed") is not True:
                raise ValueError("Timing did not index complete original population")
            raw_by_hash[physical][key] = record
    expected = {(b, r) for b in range(builds) for r in range(repeats)}
    latencies, normalized_latencies, output = {}, {}, []
    for physical, aliases in sorted(by_hash.items()):
        records = raw_by_hash[physical]
        if set(records) != expected:
            raise ValueError("Incomplete independent timing for "+physical)
        raw_rates, raw_ratios, paired_ratios, drifts = [], [], [], []
        grouped_ratios = defaultdict(list)
        latency_rows, ratio_rows = [], []
        queries = {}
        for (build_id, repeat), record in sorted(records.items()):
            if physical == base_hash:
                rate = float(record["raw_original_throughput"])
                raw_ratio = ratio = 1.
            else:
                rate = float(record["raw_throughput"])
                raw_ratio = float(record.get("raw_original_gain_ratio",
                                             rate/float(record["original_raw_throughput"])))
                ratio = float(record["paired_original_gain_ratio"])
            if min(rate, raw_ratio, ratio) <= 0 or not all(math.isfinite(v) for v in (rate, raw_ratio, ratio)):
                raise ValueError("Invalid measured rate or ratio")
            raw_rates.append(rate)
            raw_ratios.append(raw_ratio)
            paired_ratios.append(ratio)
            grouped_ratios[build_id].append(ratio)
            drifts.append(float(record.get("reference_drift", 0.)))
            query_hash = record.get("queries_sha256")
            if build_id in queries and queries[build_id] != query_hash:
                raise ValueError("Query corpus changed within an independent build")
            queries[build_id] = query_hash
            latency_rows.append(dict(latency_ns=1e9/rate, build_id=build_id,
                                     repeat=repeat, queries_sha256=query_hash))
            ratio_rows.append(dict(latency_ns=1/ratio, build_id=build_id,
                                   repeat=repeat, unit="paired_latency_ratio"))
        space_ratio = float(aliases[0]["total_bytes"])/float(base["total_bytes"])
        mean_ratio = geometric_mean(paired_ratios)
        efficiency = net_space_efficiency(mean_ratio, space_ratio)
        low, high = cluster_ratio_interval(grouped_ratios)
        for state in aliases:
            if int(state["total_bytes"]) != int(aliases[0]["total_bytes"]):
                raise ValueError("Physical aliases disagree on measured space")
            sid = str(state["state_id"])
            latencies[sid] = list(latency_rows)
            normalized_latencies[sid] = list(ratio_rows)
            output.append(dict(
                state_id=sid, physical_sha256=physical, k=int(state["k"]),
                independent_builds=builds, repeats_per_build=repeats,
                total_timing_blocks=builds*repeats,
                raw_throughput_geomean=geometric_mean(raw_rates),
                throughput_mops=geometric_mean(raw_rates)/1e6,
                raw_original_gain_ratio=geometric_mean(raw_ratios),
                paired_original_gain_ratio=mean_ratio,
                paired_gain_pct=100*(mean_ratio-1),
                raw_gain_pct=100*(geometric_mean(raw_ratios)-1),
                space_ratio=space_ratio, extra_space_ratio=space_ratio-1,
                extra_space_pct=100*(space_ratio-1),
                extra_space_bytes=int(state['total_bytes'])-int(base['total_bytes']),
                negligible_positive_space_change=0<space_ratio-1<1e-6,
                normalized_extra_space_efficiency=efficiency["value"],
                efficiency_unavailable_reason=efficiency["reason"],
                faster_and_no_larger=efficiency["faster_and_no_larger"],
                max_reference_drift=max(drifts),
                paired_build_cluster_ci95_low=low,
                paired_build_cluster_ci95_high=high,
                interval_scope="descriptive bootstrap over independent build means; no selection/multiplicity correction",
                query_sha256_by_build={str(k): v for k, v in queries.items()},
                all_repeats_retained=True, full_population_indexed=True))
    return dict(latencies=latencies, normalized_latencies=normalized_latencies,
                summary=output, independent_builds=builds, repeats_per_build=repeats)


def _verify_all(engine, a, states, root):
    from finalopt import driver as core
    from multi_sse_v5 import driver as d
    if not bool(getattr(a, "validate_all", True)):
        return dict(scope="query_corpus_and_physical_sample_only", complete=True,
                    all_original_keys_verified=False, native_builds=0)
    root.mkdir(parents=True, exist_ok=True)
    query = root/"one_original_query.bin"
    with Path(engine.case["real_path"]).open("rb") as stream:
        key = stream.read(8)
    if len(key) != 8:
        raise ValueError("Empty original input during full correctness verification")
    if query.exists() and query.read_bytes() != key:
        raise ValueError("Full-validation original query changed")
    query.write_bytes(key)
    verify_args = SimpleNamespace(**vars(engine.a))
    verify_args.structural_features = False
    expected_binary = d.digest(core.executable("finalopt_"+engine.case["index"]))
    unique = {row["physical_sha256"]: row for row in states}
    output = []
    for physical, row in sorted(unique.items()):
        folder = root/physical
        status_path = folder/"full_correctness.json"
        declaration = dict(physical_sha256=physical, original_sha256=engine.case["real_sha256"],
                           index=engine.case["index"], native_sha256=expected_binary,
                           protocol="all_physical_payloads_v1")
        if status_path.exists():
            status = d.read(status_path)
            if any(status.get(k) != v for k, v in declaration.items()) or status.get("complete") is not True:
                raise ValueError("Full-validation source or protocol changed; use NEW OUT")
        else:
            points = engine.ensure_points(row)
            started = time.monotonic()
            with core.physical(verify_args, engine.case, points) as merged:
                if d.digest(merged) != physical:
                    raise ValueError("Regenerated final validation candidate hash differs")
                native, features, regions = core.native(
                    verify_args, engine.case, merged, query, folder, all_keys=True)
            if (native.get("all_physical_validated") is not True or
                    int(native["validated_physical_records"]) != int(native["physical_count"])):
                raise ValueError("Full original/auxiliary correctness verification incomplete")
            status = dict(declaration, complete=True, all_original_keys_verified=True,
                          all_auxiliary_keys_verified=True, native_summary=native,
                          elapsed_seconds=time.monotonic()-started,
                          counted_as_search_evaluation=False)
            d.write(status_path, status)
            # Only this module's one-query feature dump is disposable.
            if features.parent.resolve() != folder.resolve():
                raise ValueError("Refuse validation feature cleanup outside owned folder")
            features.unlink()
        output.append(status)
    return dict(scope="all_original_and_auxiliary_keys", complete=True,
                all_original_keys_verified=True, native_builds=len(unique),
                states=output, cost_accounting="post-selection validation, separate from search budget")


def freeze_and_measure(engine, a, states, policies, stop, label="timing"):
    """Freeze, validate, and independently rebuild every endpoint per build.

    Leave all frozen shadow arrays in place. The outer dataset runner owns
    packaging/cleanup after every build and analysis have completed.
    """
    from finalopt import driver as core
    from multi_sse_v5 import driver as d, fast_measurement as timing
    if not re.fullmatch(r"[A-Za-z0-9_-]+", label):
        raise ValueError("Timing label must be a simple directory name")
    builds = int(getattr(a, "builds", 3))
    repeats = int(a.repeats)
    if builds < 1 or repeats < 1:
        raise ValueError("Positive independent builds/repeats required")
    states = list(states)
    states.sort(key=lambda row: (int(row["k"]) != 0, str(row["state_id"])))
    if not states or int(states[0]["k"]) != 0:
        raise ValueError("Timing endpoint pool needs an original state")
    selection = engine.folder/"selection"
    freeze_path = selection/"frozen_manifest.json"
    if freeze_path.exists():
        frozen = d.read(freeze_path)
        actual = {(row["state_id"], row["physical_sha256"]) for row in frozen["variants"]}
        expected = {(row["state_id"], row["physical_sha256"]) for row in states}
        if actual != expected or not frozen.get("frozen_before_timing"):
            raise ValueError("Final endpoint selection changed; use NEW OUT")
        # Restore all artifacts before replay verifies the frozen hashes.
        for row in states:
            engine.ensure_points(row)
    else:
        core.freeze(engine.a, engine, states, policies, stop)
    root = engine.folder/label
    root.mkdir(parents=True, exist_ok=True)
    declaration = dict(schema="gafis_independent_build_confirmation_v1", builds=builds,
                       repeats_per_build=repeats, query_count=int(a.query_count),
                       seconds=float(a.seconds), warmup=float(a.warmup),
                       cpu=str(a.cpu), timeout=float(a.timeout), seed=int(a.seed),
                       source_frozen_manifest_sha256=d.digest(freeze_path),
                       query_seed_offset=104729, query_seed_build_gap=1000003,
                       all_original_validation=bool(getattr(a, "validate_all", True)),
                       no_timing_import=True, selection_or_weights_changed=False)
    protocol_path = root/"independent_build_protocol.json"
    if protocol_path.exists() and d.read(protocol_path) != declaration:
        raise ValueError("Independent measurement protocol changed; use NEW OUT")
    d.write(protocol_path, declaration)
    verification = _verify_all(engine, a, states, root/"full_correctness")
    build_records = {}
    for build_id in range(builds):
        out = root/("build_%03d" % build_id)
        arguments = timing.parse([
            "--source-out", str(selection), "--out", str(out),
            "--query-count", str(a.query_count),
            "--seed", str(a.seed+104729+build_id*1000003),
            "--repeats", str(repeats), "--seconds", str(a.seconds),
            "--warmup", str(a.warmup), "--cpu", str(a.cpu),
            "--scratch-dir", str(a.scratch_dir), "--timeout", str(a.timeout),
            "--heartbeat", str(getattr(a, "heartbeat", 30.))])
        status_path = out/"fast_measurement_status.json"
        # measure() verifies source/queries/settings even when all repeats are
        # complete; resume therefore cannot silently accept changed artifacts.
        timing.measure(arguments)
        status = d.read(status_path)
        if status.get("complete") is not True:
            d.write(root/"INCOMPLETE.json", dict(build_id=build_id, status=status))
            raise RuntimeError("Independent timing incomplete; preserve all artifacts and resume")
        build_records[build_id] = d.lines(out/"timing_raw.jsonl")
    result = summarize_records(states, build_records, builds, repeats)
    result.update(protocol=declaration, full_validation=verification,
                  all_builds_complete=True,
                  timing_native_builds_per_state=builds,
                  post_selection_validation_native_builds=verification["native_builds"])
    d.write(root/"independent_build_summary.json", result)
    d.csvwrite(root/"independent_build_summary.csv", result["summary"])
    incomplete = root/"INCOMPLETE.json"
    if incomplete.is_file():
        incomplete.unlink()
    return result


# Small compatibility alias for an outer runner that already calls it this way.
measure_engine = freeze_and_measure
