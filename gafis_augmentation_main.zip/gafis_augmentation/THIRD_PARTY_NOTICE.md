# Third-party source notices

The artifact includes pinned source dependencies for ALEX, LIPP, PGM, and the
Google cpp-btree timing reference. Their original licenses, copyright notices,
and upstream attribution are preserved with the corresponding source files.
Those third-party notices are independent of the artifact authors' identities.

Index construction and lookup algorithms are retained. Passive operation
counters and read-only routing accessors support profiling and candidate regions;
timing workers disable the operation instrumentation.
