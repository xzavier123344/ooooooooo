"""Build the upload package on Linux or Windows; no datasets or experiments run."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build(indices="alex,lipp,pgm", compiler=None):
    names = [s.strip() for s in indices.split(",") if s.strip()]
    if not names or len(set(names)) != len(names) or set(names)-{"alex","lipp","pgm"}:
        raise ValueError("indices must be a distinct subset of alex,lipp,pgm")
    cxx = compiler or os.environ.get("CXX") or shutil.which("g++")
    if not cxx:
        raise FileNotFoundError("Install g++ or set CXX/--compiler")
    env = os.environ.copy()
    env["PATH"] = str(Path(cxx).resolve().parent) + os.pathsep + env.get("PATH","")
    suffix = ".exe" if os.name == "nt" else ""
    for relative in ("population/bin","finalopt/bin","multi_sse_v5/bin","costsearch/bin","build_logs"):
        (ROOT/relative).mkdir(parents=True,exist_ok=True)
    records = []

    def run(command, label):
        log = ROOT/"build_logs"/(label+".log")
        started = time.monotonic()
        with log.open("w",encoding="utf-8") as stream:
            stream.write(json.dumps(command)+"\n")
            stream.flush()
            completed = subprocess.run(command,cwd=str(ROOT),env=env,stdout=stream,stderr=subprocess.STDOUT)
        item = dict(label=label,command=command,seconds=time.monotonic()-started,
                    returncode=completed.returncode,log=str(log.relative_to(ROOT)))
        records.append(item)
        print("[BUILD]",label,"exit="+str(completed.returncode),flush=True)
        if completed.returncode:
            raise RuntimeError("Build failed: "+str(log))

    common = ["-std=c++17","-O3","-DNDEBUG","-march=native","-pthread"]
    if os.name == "nt":
        common += ["-static"]
    includes = ["-Imulti_sse_v5","-Imulti_sse_v5/vendor","-Imulti_sse_v5/vendor/lipp",
                "-Imulti_sse_v5/vendor/pgm"]

    def compile_one(source, target, flags, label):
        command = [str(cxx)]+common+flags+[source,"-o",target+suffix]
        run(command,label)
        path = ROOT/(target+suffix)
        records[-1].update(binary=str(path.relative_to(ROOT)),sha256=digest(path),bytes=path.stat().st_size)

    # Timing preparation may reset vendor accessors. Do it before finalopt's
    # additional read-only structural interfaces are installed.
    for script in ("multi_sse_v5/prepare_native.py","multi_sse_v5/prepare_reference.py",
                   "multi_sse_v5/prepare_fast_native.py"):
        run([sys.executable,script],Path(script).stem)
    for name in names:
        compile_one("multi_sse_v5/bin/fast_generated/fast_native.cpp",
                    "multi_sse_v5/bin/fast_"+name+"_resident",includes+["-DOP_"+name.upper()],
                    "fast_"+name)
    compile_one("multi_sse_v5/fast_reference.cpp","multi_sse_v5/bin/fast_google_btree_resident",
                includes,"fast_btree")
    run([sys.executable,"finalopt/prepare_native.py"],"prepare_finalopt")
    for name in names:
        compile_one("finalopt/native.cpp","finalopt/bin/finalopt_"+name,
                    includes+["-DOP_INSPECT","-DMI_TRACE","-DFA_TRACE","-DOP_"+name.upper()],
                    "finalopt_"+name)
    compile_one("population/stream.cpp","population/bin/population_stream",[],"population_stream")
    compile_one("finalopt/proposal_stream.cpp","finalopt/bin/proposal_stream",[],"proposal_stream")
    compile_one("finalopt/calibrate.cpp","finalopt/bin/operation_calibration",[],"operation_calibration")
    manifest = dict(schema="gafis_augmentation_build_v1",compiler=str(cxx),
                    indices=names,commands=records,construction_and_lookup_algorithms_unchanged=True)
    (ROOT/"build_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    return manifest


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--indices",default="alex,lipp,pgm")
    parser.add_argument("--compiler")
    options=parser.parse_args()
    build(options.indices,options.compiler)
