#pragma once
#include <cstdint>
#include <cstddef>
#include <cmath>
#include <unordered_set>

// Untimed structural tracing only. Native timing builds inline all hooks away.
namespace fa {
struct Metrics {
 double route_models=0, local_models=0, route_metadata=0, local_metadata=0;
 double route_pointers=0, local_bitmaps=0, route_keys=0, local_keys=0;
 double local_slots=0, payloads=0, exp_comparisons=0, binary_comparisons=0, final_comparisons=0;
 double route_accesses=0, local_accesses=0, route_lines=0, local_lines=0, total_lines=0;
 double hit_error=0, physical_hits=0, leaf_capacity=0, leaf_keys=0, visited_capacity=0;
 double route_ops() const { return route_models+route_metadata+route_pointers+route_keys; }
 double local_ops() const { return local_models+local_metadata+local_bitmaps+local_keys+payloads; }
};
inline Metrics current{};
#ifdef FA_TRACE
inline bool active=false, routing=true;
inline int search_phase=0;
inline size_t line_bytes=64;
inline std::unordered_set<uintptr_t> route_set,local_set,total_set;
inline void reset(size_t bytes=64) {
 current=Metrics{}; routing=true; search_phase=0; line_bytes=bytes;
 route_set.clear(); local_set.clear(); total_set.clear(); active=true;
}
inline void touch(const void* address,size_t size) {
 if(!active || !size) return;
 auto first=reinterpret_cast<uintptr_t>(address)/line_bytes;
 auto last=(reinterpret_cast<uintptr_t>(address)+size-1)/line_bytes;
 auto& set=routing?route_set:local_set;
 for(auto line=first;line<=last;++line) { set.insert(line); total_set.insert(line); }
 if(routing) ++current.route_accesses; else ++current.local_accesses;
}
inline void stage(bool route) { if(active) routing=route; }
inline void phase(int value) { if(active) search_phase=value; }
inline void model(const void* p,size_t size) {
 if(!active) return; touch(p,size); if(routing) ++current.route_models; else ++current.local_models;
}
inline void pointer(const void* p,size_t size) { if(active) { touch(p,size); ++current.route_pointers; } }
inline void leaf(double capacity,double keys) { if(active) { current.leaf_capacity=capacity; current.leaf_keys=keys; } }
inline void capacity(double slots) { if(active) current.visited_capacity+=slots; }
inline void hit(int actual,int predicted) {
 if(active && actual>=0) { current.hit_error=std::abs(double(actual)-predicted); current.physical_hits=1; }
}
inline Metrics finish() {
 current.route_lines=route_set.size(); current.local_lines=local_set.size(); current.total_lines=total_set.size();
 active=false; return current;
}
#else
inline void reset(size_t=64) {} inline void touch(const void*,size_t) {}
inline void stage(bool) {} inline void phase(int) {} inline void model(const void*,size_t) {}
inline void pointer(const void*,size_t) {} inline void leaf(double,double) {}
inline void capacity(double) {} inline void hit(int,int) {}
inline Metrics finish() { return {}; }
#endif
template<class T> inline T& meta_read(T& value) {
#ifdef FA_TRACE
 if(active) { touch(&value,sizeof(T)); if(routing) ++current.route_metadata; else ++current.local_metadata; }
#endif
 return value;
}
template<class T> inline T& bitmap_read(T& value) {
#ifdef FA_TRACE
 if(active) { touch(&value,sizeof(T)); ++current.local_bitmaps; }
#endif
 return value;
}
template<class T> inline T& key_read(T& value) {
#ifdef FA_TRACE
 if(active) {
  touch(&value,sizeof(T));
  if(routing) ++current.route_keys;
  else {
   ++current.local_slots; ++current.local_keys;
   if(search_phase==1) ++current.exp_comparisons;
   else if(search_phase==2) ++current.binary_comparisons;
   else if(search_phase==3) ++current.final_comparisons;
  }
 }
#endif
 return value;
}
template<class T> inline T& payload_read(T& value) {
#ifdef FA_TRACE
 if(active) { touch(&value,sizeof(T)); ++current.payloads; }
#endif
 return value;
}
}
