"""Checks for the ordered shared-pool search described in the method."""
import hashlib
from contextlib import contextmanager
import json
import math
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from costsearch import search, weights


def state(identity, count=0, cost=100.0, space=100, raw_sum=98.0,
          generator="gap", role="candidate"):
    return {
        "state_id": identity,
        "physical_sha256": identity,
        "n0": 100,
        "k": count,
        "estimated_cost_ns": cost,
        "total_bytes": space,
        "gafis_u": raw_sum,
        "role": role,
        "recipe": {"generator": generator},
        "native_summary": {},
    }


class WeightGridTests(unittest.TestCase):
    def test_declared_cartesian_grids(self):
        expected = {
            "alex": ([0, .025, .05, .1, .5],
                     [0, .005, .025, .05, .1, .2, .4, 1, 1.5]),
            "lipp": ([0, .025, .05, .1, .5],
                     [0, .005, .025, .05, .1, .2, .4, 1, 1.5]),
            "pgm": ([0, .025, .05, .1, .5],
                    [0, .005, .025, .05, .1, .2, .4, 1, 1.5]),
        }
        for name, (spaces, distributions) in expected.items():
            with self.subTest(index=name):
                pairs = search.grid_for(search.PRESETS[name])
                self.assertEqual(pairs, [(s, g) for s in spaces for g in distributions])
                self.assertEqual(len(pairs), 45)
                self.assertIn(tuple(search.PRESETS[name]['primary']), pairs)

    def test_config_and_python_presets_are_identical(self):
        config = json.loads((search.ROOT / 'config.json').read_text(encoding='utf-8'))
        self.assertEqual(config['indices'], search.PRESETS)

    def test_priority_is_fixed_and_contains_each_pair_once(self):
        pairs = search.grid_for(search.PRESETS["alex"])
        ordered = search.priority_weights(pairs, (.1, .2))
        self.assertEqual(ordered[:3], [(.1, .2), (.1, 0.), (0., 0.)])
        self.assertEqual(len(ordered), len(pairs))
        self.assertEqual(set(ordered), set(pairs))


class ObjectiveTests(unittest.TestCase):
    def test_original_objective_is_zero_for_every_declared_weight(self):
        base = state("original", role="original")
        for preset in search.PRESETS.values():
            for pair in search.grid_for(preset):
                self.assertEqual(weights.score(base, base, *pair)["J"], 0.)

    def test_distribution_denominator_is_original_population_size(self):
        base = state("original", role="original")
        candidate = state("augmented", count=50)
        self.assertEqual(weights.score(candidate, base, 0., 1.)["J"], 0.)
        candidate["gafis_u"] = 196.
        self.assertAlmostEqual(weights.score(candidate, base, 0., 1.)["J"], math.log(1.5))

    def test_calibrated_mean_space_and_distribution_are_log_ratios(self):
        base = state("original", role="original")
        candidate = state("augmented", 10, cost=80., space=150, raw_sum=49.)
        value = weights.score(candidate, base, .1, .2)["J"]
        expected = math.log(.8) + .1 * math.log(1.5) + .2 * math.log(147./196.)
        self.assertAlmostEqual(value, expected)

    def test_objective_ties_prefer_space_then_count_then_identity(self):
        base = state("original", role="original")
        rows = [state("z", 5, space=101), state("b", 4),
                state("a", 4), state("c", 5)]
        self.assertEqual(weights.choose(rows, base, 0., 0.)["state_id"], "a")


class ParentSelectionTests(unittest.TestCase):
    def setUp(self):
        self.base = state("base", role="original")
        self.fast = state("fast", 10, cost=70., space=130, raw_sum=500.)
        self.smooth = state("smooth", 20, cost=95., space=110, raw_sum=0.)
        self.rows = [self.base, self.fast, self.smooth]

    def test_expanded_champion_does_not_fall_back_to_runner_up(self):
        parents, _ = search.select_parents(
            self.rows, self.base, [(.1, 1.)], (.1, 1.), {"smooth"}, 3)
        self.assertEqual(parents, [])

    def test_parent_limit_deduplication_and_selecting_weight(self):
        pairs = [(0., 0.), (.1, 0.), (.1, 1.)]
        parents, _ = search.select_parents(
            self.rows, self.base, pairs, (.1, 1.), set(), 3)
        self.assertEqual([p["state_id"] for p in parents], ["smooth", "fast"])
        self.assertEqual(tuple(parents[0]["weights"]), (.1, 1.))
        self.assertEqual(tuple(parents[1]["weights"]), (.1, 0.))
        limited, _ = search.select_parents(
            self.rows, self.base, pairs, (.1, 1.), set(), 1)
        self.assertEqual([p["state_id"] for p in limited], ["smooth"])

    def test_parent_selection_is_independent_of_throughput_fields(self):
        pairs = [(0., 0.), (.1, 1.)]
        before, _ = search.select_parents(
            self.rows, self.base, pairs, (.1, 1.), set(), 3)
        self.base["throughput"] = 1.e9
        self.fast["throughput"] = .001
        self.smooth["throughput"] = .01
        after, _ = search.select_parents(
            self.rows, self.base, pairs, (.1, 1.), set(), 3)
        self.assertEqual(before, after)


class ProposalRecipeTests(unittest.TestCase):
    def test_count_moves_use_total_candidate_size(self):
        parent = state("parent", 10)
        recipes = search.proposal_recipes(parent, 100, 50, 7)
        additions = [r for r in recipes if r["action"] == "add"]
        removals = [r for r in recipes if r["action"] == "remove"]
        self.assertEqual({r["target_k"] for r in additions}, {15, 20})
        self.assertEqual({r["target_k"] for r in removals}, {5})
        self.assertTrue(all(r["target_k"] <= 50 for r in recipes))
        self.assertTrue(all(r["parent"] == "parent" for r in recipes))

    def test_same_count_operations_have_distinct_semantics(self):
        recipes = search.proposal_recipes(state("parent", 10), 100, 50, 7)
        relocate = next(r for r in recipes if r["action"] == "relocate")
        reallocate = next(r for r in recipes if r["action"] == "reallocate")
        self.assertEqual(relocate["target_k"], 10)
        self.assertEqual(relocate["generator"], "sse")
        self.assertEqual(relocate["allocation"], "parent")
        self.assertTrue(relocate["preserve_regional_counts"])
        self.assertEqual(reallocate["target_k"], 10)
        self.assertEqual(reallocate["generator"], "gap")
        self.assertEqual(reallocate["allocation"], "equal")

    def test_zero_parent_does_not_have_same_count_coordinate_moves(self):
        recipes = search.proposal_recipes(state("base"), 100, 50, 7)
        self.assertTrue(recipes)
        self.assertFalse(any(r["action"] in ("relocate", "reallocate", "remove") for r in recipes))
        self.assertTrue(all(r["target_k"] > 0 for r in recipes))

    def test_ceiling_and_duplicate_targets_are_respected(self):
        recipes = search.proposal_recipes(state("parent", 45), 100, 50, 7)
        additions = [r for r in recipes if r["action"] == "add"]
        self.assertEqual(len(additions), 1)
        self.assertEqual(additions[0]["target_k"], 50)
        full = search.proposal_recipes(state("full", 50), 100, 50, 7)
        self.assertFalse(any(r["action"] == "add" for r in full))

    def test_remove_can_return_the_original_state(self):
        recipes = search.proposal_recipes(state("one", 1), 100, 50, 7)
        removals = [r for r in recipes if r["action"] == "remove"]
        self.assertEqual(len(removals), 1)
        self.assertEqual(removals[0]["target_k"], 0)


class SimulatedInterruption(Exception):
    pass


class FakeEngine:
    """A native-build stand-in that has no preview or score-admission API."""
    def __init__(self, folder, rows=None, child_cost=120., reject=False,
                 cap=1000, interrupt=False):
        self.folder = Path(folder)
        self.rows = list(rows or [state("base", role="original"),
                                 state("seed", 10, cost=90.)])
        self.by_id = {r["state_id"]: r for r in self.rows}
        self.case = {"n0": 100}
        self.child_cost = child_cost
        self.reject = reject
        self.cap = cap
        self.interrupt = interrupt
        self.attempts = 0
        self.prior_elapsed = 0.
        self.started = time.monotonic()
        self.built = []
        self.built_parents = []

    def allowed(self):
        return self.attempts < self.cap

    def trial(self, recipe, role):
        identity = hashlib.sha256(json.dumps(recipe, sort_keys=True).encode()).hexdigest()[:24]
        if identity in self.by_id:
            return self.by_id[identity]
        if self.reject:
            return None
        row = state(identity, recipe["target_k"], cost=self.child_cost, role=role)
        row["recipe"] = recipe
        self.rows.append(row)
        self.by_id[identity] = row
        self.attempts += 1
        self.built.append(identity)
        self.built_parents.append(recipe["parent"])
        if self.interrupt:
            self.interrupt = False
            raise SimulatedInterruption()
        return row


def search_args(rounds=3, parents=2):
    return SimpleNamespace(rounds=rounds, parents=parents, max_fraction=.5, seed=7)


class AdaptiveSearchTests(unittest.TestCase):
    def test_valid_nonimproving_states_do_not_trigger_an_improvement_stop(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder, child_cost=120.)
            status = search.adaptive_search(engine, search_args(), [(0., 0.)], (0., 0.))
            self.assertEqual(status["stop"], "no_unexpanded_weight_champion")
            self.assertEqual(status["rounds_completed"], 1)
            self.assertGreater(status["evaluated_states"], 2)
            self.assertEqual(weights.choose(engine.rows, engine.rows[0], 0., 0.)["state_id"], "seed")
            trace = search.io.read(Path(folder)/"search_trace.json")
            self.assertGreater(trace[0]["new_valid_states"], 0)

    def test_completed_empty_round_stops_and_marks_completed_parent(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder, reject=True)
            status = search.adaptive_search(engine, search_args(), [(0., 0.)], (0., 0.))
            self.assertEqual(status["stop"], "no_new_valid_evaluated_state")
            self.assertEqual(status["expanded_states"], ["seed"])
            self.assertEqual(status["rounds_completed"], 1)

    def test_new_best_child_does_not_change_this_rounds_parent_batch(self):
        rows = [state("base", role="original"),
                state("fast", 10, cost=70., space=130, raw_sum=500.),
                state("smooth", 20, cost=95., space=110, raw_sum=0.)]
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder, rows=rows, child_cost=10.)
            pairs = [(0., 0.), (.1, 1.)]
            status = search.adaptive_search(engine, search_args(rounds=1), pairs, (.1, 1.))
            trace = search.io.read(Path(folder)/"search_trace.json")
            self.assertEqual([p["state_id"] for p in trace[0]["parents"]], ["smooth", "fast"])
            self.assertEqual(set(engine.built_parents), {"smooth", "fast"})
            self.assertEqual(engine.built_parents, sorted(engine.built_parents, key=lambda p: p == "fast"))
            self.assertEqual(set(status["expanded_states"]), {"smooth", "fast"})

    def test_resource_interruption_does_not_mark_a_partial_parent_completed(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder, cap=1)
            status = search.adaptive_search(engine, search_args(), [(0., 0.)], (0., 0.))
            self.assertEqual(status["stop"], "resource_limit")
            self.assertEqual(status["expanded_states"], [])
            checkpoint = search.io.read(Path(folder)/"search_checkpoint.json")
            self.assertIsNotNone(checkpoint["current"])
            self.assertEqual(checkpoint["current"]["recipe_index"], 1)
            self.assertEqual(len(engine.built), 1)

    def test_resume_reuses_a_build_completed_before_the_recipe_checkpoint(self):
        with tempfile.TemporaryDirectory() as folder:
            args = search_args(rounds=1)
            engine = FakeEngine(folder, interrupt=True)
            with self.assertRaises(SimulatedInterruption):
                search.adaptive_search(engine, args, [(0., 0.)], (0., 0.))
            first_built = engine.built[0]
            checkpoint = search.io.read(Path(folder)/"search_checkpoint.json")
            self.assertEqual(checkpoint["expanded"], [])
            self.assertEqual(checkpoint["current"]["recipe_index"], 0)
            resumed = FakeEngine(folder, rows=engine.rows)
            resumed.attempts = engine.attempts
            status = search.adaptive_search(resumed, args, [(0., 0.)], (0., 0.))
            self.assertNotIn(first_built, resumed.built)
            self.assertEqual(status["stop"], "round_limit")
            self.assertEqual(status["expanded_states"], ["seed"])

    def test_finished_checkpoint_is_idempotent(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder)
            args = search_args(rounds=1)
            first = search.adaptive_search(engine, args, [(0., 0.)], (0., 0.))
            build_count = len(engine.built)
            second = search.adaptive_search(engine, args, [(0., 0.)], (0., 0.))
            self.assertEqual(first, second)
            self.assertEqual(len(engine.built), build_count)

    def test_changed_weight_grid_cannot_reuse_checkpoint(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder)
            args = search_args(rounds=0)
            search.adaptive_search(engine, args, [(0., 0.)], (0., 0.))
            with self.assertRaisesRegex(ValueError, "settings changed"):
                search.adaptive_search(engine, args, [(0., 0.), (.1, .2)], (0., 0.))

    def test_final_per_weight_choices_are_no_worse_than_retained_original(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = FakeEngine(folder)
            preset = search.PRESETS["pgm"]
            grid = search.grid_for(preset)
            search.adaptive_search(engine, search_args(rounds=1), grid, preset["primary"])
            base = engine.by_id["base"]
            for gs, gg in grid:
                chosen = weights.choose(engine.rows, base, gs, gg)
                self.assertLessEqual(weights.score(chosen, base, gs, gg)["J"], 0.)


class CandidateCacheTests(unittest.TestCase):
    def engine(self, folder):
        folder = Path(folder)
        instance = search.core.CaseSearch.__new__(search.core.CaseSearch)
        instance.folder = folder
        instance.case = {"case_id": "example.alex", "n0": 100}
        instance.a = SimpleNamespace(native_cap=5)
        instance.started = time.monotonic()
        instance.prior_elapsed = 0.
        instance.deadline = instance.started + 60.
        instance.cap_hit = False
        instance.attempts = 0
        instance.failures = []
        instance.aliases = {}
        instance.alias_path = folder/"candidate_aliases.json"
        instance.release_shadows = Mock()
        instance.generate = Mock(side_effect=lambda recipe, dest: self.point_file(dest))
        return instance

    @staticmethod
    def point_file(dest):
        path = Path(dest)/"shadows.bin"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((7).to_bytes(8, "little"))
        return path

    def test_equal_physical_candidates_reuse_before_native_construction(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = self.engine(folder)
            merged = Path(folder)/"merged.bin"
            merged.write_bytes(b"same sorted augmented population")
            cached = state("cached", 1)
            cached["physical_sha256"] = search.io.digest(merged)
            engine.rows = [cached]
            engine.by_id = {"cached": cached}
            recipe = {"action": "reallocate", "parent": "cached", "target_k": 1}

            @contextmanager
            def physical(args, case, points, metrics):
                search.io.write(metrics, {})
                yield merged

            with patch.object(search.core, "physical", physical), patch.object(search.core, "native") as native:
                self.assertIs(engine.trial(recipe, "candidate"), cached)
                self.assertIs(engine.trial(recipe, "candidate"), cached)
                native.assert_not_called()
            self.assertEqual(engine.generate.call_count, 1)
            self.assertEqual(engine.attempts, 0)
            self.assertEqual(len(engine.rows), 1)
            self.assertEqual(engine.aliases[engine.recipe_id(recipe)], "cached")

    def test_exhausted_native_budget_prevents_uncached_generation(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = self.engine(folder)
            engine.rows = []
            engine.by_id = {}
            engine.attempts = engine.a.native_cap
            recipe = {"action": "add", "parent": "parent", "target_k": 1}
            self.assertIsNone(engine.trial(recipe, "candidate"))
            engine.generate.assert_not_called()

    def test_failed_feasibility_merge_does_not_consume_native_build_budget(self):
        with tempfile.TemporaryDirectory() as folder:
            engine = self.engine(folder)
            engine.rows = []
            engine.by_id = {}
            recipe = {"action": "add", "parent": "parent", "target_k": 1}

            @contextmanager
            def physical(args, case, points, metrics):
                raise ValueError("auxiliary key overlaps an original key")
                yield  # pragma: no cover

            with patch.object(search.core, "physical", physical), patch.object(search.core, "native") as native:
                self.assertIsNone(engine.trial(recipe, "candidate"))
                native.assert_not_called()
            self.assertEqual(engine.attempts, 0)
            self.assertEqual(len(engine.failures), 1)




class MainMeasurementScopeTests(unittest.TestCase):
    def test_original_champion_does_not_fall_back_to_another_weight(self):
        base = state("original", role="original")
        other = state("other", 10, cost=90., space=1000, raw_sum=98.)
        self.assertEqual(search.measurement_endpoints([base, other], base, (1., 0.)), [base])

    def test_only_original_and_designated_endpoint_are_timed(self):
        base = state("original", role="original")
        fast = state("fast", 10, cost=70., space=130, raw_sum=500.)
        smooth = state("smooth", 20, cost=95., space=110, raw_sum=0.)
        self.assertEqual(search.measurement_endpoints([base, fast, smooth], base, (.1, 1.)), [base, smooth])


if __name__ == "__main__":
    unittest.main()
