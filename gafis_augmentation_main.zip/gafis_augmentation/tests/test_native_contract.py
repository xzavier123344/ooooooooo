"""Check operation-cost and proposal contracts without native index builds."""
from contextlib import contextmanager
import copy
import csv
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from costsearch import search
from finalopt import cost, driver, proposals, sampling
from multi_sse_v5 import driver as io


class SamplingContractTests(unittest.TestCase):
    def test_stratum_population_shares_define_the_global_mean(self):
        mean, se = sampling.estimate([10., 10., 20., 20.], [0, 1, 2, 4], [0, 2, 8])
        self.assertAlmostEqual(mean, 17.5)
        self.assertAlmostEqual(se, 0.)
        self.assertNotEqual(mean, 15.)

    def test_fixed_sample_is_reused_and_excludes_validation_ranks(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            original = folder / 'keys.bin'
            (np.arange(1000, dtype='<u8') * 17 + 5).tofile(original)
            before = sampling.prepare(original, folder/'sample', 200, 100, 20, 17)
            after = sampling.prepare(original, folder/'sample', 200, 100, 20, 17)
            self.assertEqual(before, after)
            search_ranks = np.fromfile(before['search_ranks'], dtype='<u8')
            heldout_ranks = np.fromfile(before['validation_ranks'], dtype='<u8')
            self.assertEqual(len(np.intersect1d(search_ranks, heldout_ranks)), 0)
            self.assertEqual(len(np.unique(search_ranks)), 200)


class RegionalContractTests(unittest.TestCase):
    def test_every_gap_is_owned_once_including_the_boundary_gap(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'keys.bin'
            np.asarray([10, 20, 30, 40, 50], dtype='<u8').tofile(path)
            regions = [dict(begin=0, end=2, mean_cost=2.),
                       dict(begin=2, end=5, mean_cost=3.)]
            parts = proposals.segments(path, regions)
            self.assertEqual([(p['gap_begin'], p['gap_end']) for p in parts], [(0, 2), (2, 4)])
            self.assertEqual([p['original_count'] for p in parts], [2, 2])
            owners = {gap: p['region_id'] for p in parts
                      for gap in range(p['gap_begin'], p['gap_end'])}
            self.assertEqual(owners, {0: 0, 1: 0, 2: 1, 3: 1})
            self.assertEqual(sum(p['capacity'] for p in parts), 36)

    def test_allocation_preserves_exact_count_and_respects_capacities(self):
        parts = [dict(original_count=4, capacity=0, mean_cost=1.),
                 dict(original_count=2, capacity=3, mean_cost=20.),
                 dict(original_count=3, capacity=11, mean_cost=2.)]
        for mode in ('equal', 'marginal'):
            for requested in range(15):
                with self.subTest(mode=mode, requested=requested):
                    counts = proposals.allocate(parts, requested, mode)
                    self.assertEqual(sum(counts), requested)
                    self.assertTrue(all(isinstance(x, int) and 0 <= x <= p['capacity']
                                        for x, p in zip(counts, parts)))
        with self.assertRaises(ValueError):
            proposals.allocate(parts, 15)

    def test_empty_region_uses_the_global_work_estimate(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'regions.csv'
            fields = ['begin', 'end', 'sample_count'] + ['feature_mass_'+str(i) for i in range(8)]
            rows = [dict(begin=0, end=2, sample_count=0), dict(begin=2, end=5, sample_count=2)]
            for row in rows:
                row.update({'feature_mass_'+str(i): 0 for i in range(8)})
            rows[1]['feature_mass_1'] = 8
            with path.open('w', newline='', encoding='utf-8') as stream:
                writer = csv.DictWriter(stream, fields)
                writer.writeheader()
                writer.writerows(rows)
            result = driver.attach_region_costs(path, {name: 1. for name in cost.FEATURES}, 7.)
            self.assertEqual([r['mean_cost'] for r in result], [7., 4.])

    def test_relocate_preserves_parent_counts_including_boundary_insertions(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            original, old = folder/'keys.bin', folder/'parent.bin'
            np.asarray([10, 20, 30, 40, 50], dtype='<u8').tofile(original)
            np.asarray([15, 25, 35, 45], dtype='<u8').tofile(old)
            regions_path = folder/'regions.json'
            io.write(regions_path, [dict(begin=0, end=2, mean_cost=2.),
                                    dict(begin=2, end=5, mean_cost=3.)])
            engine = search.OperationEngine.__new__(search.OperationEngine)
            engine.case = dict(real_path=str(original))
            engine.by_id = {'parent': dict(regions_path=str(regions_path))}
            engine.a = SimpleNamespace(proposal_timeout=1)
            engine.ensure_points = Mock(return_value=old)
            destination = folder/'candidate'
            destination.mkdir()

            def generate(*args, **kwargs):
                self.assertEqual(kwargs['regional_counts'], [2, 2])
                output = Path(args[3])/'shadows.bin'
                output.parent.mkdir(parents=True)
                np.asarray([16, 26, 36, 46], dtype='<u8').tofile(output)
                return dict(points_path=str(output))

            recipe = dict(parent='parent', action='relocate', target_k=4,
                          generator='sse', proposal_seed=17, preserve_regional_counts=True)
            with patch.object(proposals, 'generate', side_effect=generate):
                output = engine.generate(recipe, destination)
            np.testing.assert_array_equal(np.fromfile(output, dtype='<u8'), [16, 26, 36, 46])


class FrozenCoefficientContractTests(unittest.TestCase):
    def test_all_eight_operation_counts_use_the_frozen_positive_prices(self):
        coefficients = dict(zip(cost.FEATURES, range(1, 9)))
        calibration = dict(coefficients_ns=coefficients)
        features = np.asarray([[1., 2., 3., 4., 5., 6., 7., 8.], [0., 0., 0., 0., 0., 0., 0., 1.]])
        before = copy.deepcopy(calibration)
        np.testing.assert_array_equal(cost.query_cost(features, calibration), [204., 8.])
        self.assertEqual(calibration, before)

    def test_candidate_evaluation_never_refits_original_index_prices(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            original = folder/'keys.bin'
            np.asarray([10, 20, 30, 40, 50], dtype='<u8').tofile(original)
            ranks = folder/'ranks.bin'
            np.asarray([0, 1, 2, 3], dtype='<u8').tofile(ranks)
            query = folder/'queries.bin'
            np.asarray([10, 20, 30, 40], dtype='<u8').tofile(query)
            sample = dict(search_queries=str(query), search_ranks=str(ranks), search_count=4,
                          bounds=[0, 2, 5], declaration=dict(strata=2))
            calibration = dict(coefficients_ns=dict(zip(cost.FEATURES, range(1, 9))))
            before = copy.deepcopy(calibration)
            args = SimpleNamespace(native_cap=10, case_seconds=60, scratch_dir=folder,
                                   timeout=1, proposal_timeout=1)
            case = dict(case_id='fixture.alex', index='alex', n0=5, real_path=str(original))
            engine = search.OperationEngine(args, case, folder, sample, calibration)

            def generate(recipe, destination):
                output = Path(destination)/'shadows.bin'
                np.asarray([15], dtype='<u8').tofile(output)
                return output

            @contextmanager
            def physical(args, case, points, metrics_destination):
                merged = folder/'merged.bin'
                np.asarray([10, 15, 20, 30, 40, 50], dtype='<u8').tofile(merged)
                io.write(metrics_destination, dict(gafis_u=3., plafi_raw_fixed=1., plafi_raw_total=3.))
                yield merged

            def native(args, case, merged, queries, destination, all_keys=False, calibration=False):
                self.assertFalse(calibration)
                destination = Path(destination)
                features_path = destination/'features.f64'
                features = np.zeros((4, 8), dtype='<f8')
                features[:, 0] = 1
                features[:, 1] = [1, 2, 3, 4]
                features[:, 7] = 1
                features.tofile(features_path)
                region_path = destination/'regions.csv'
                masses = features.sum(axis=0)
                row = dict(begin=0, end=5, sample_count=4)
                row.update({'feature_mass_'+str(i): value for i, value in enumerate(masses)})
                io.csvwrite(region_path, [row])
                return dict(total_bytes=123), features_path, region_path

            with patch.object(engine, 'generate', side_effect=generate), \
                    patch.object(driver, 'physical', side_effect=physical), \
                    patch.object(driver, 'native', side_effect=native), \
                    patch('finalopt.calibration.fit') as fit:
                row = engine.trial(dict(action='add', parent='parent', target_k=1), 'candidate')
            fit.assert_not_called()
            self.assertIsNotNone(row)
            self.assertAlmostEqual(row['estimated_cost_ns'], 14.4)
            self.assertEqual(engine.calibration, before)


if __name__ == '__main__':
    unittest.main()
